#include <stdio.h>
#include <string.h>
#include <openssl/sha.h>
#include "module3.h"

static uint64_t      g_total_hashes = 0;
static unsigned char g_last_hash[SHA256_DIGEST_LENGTH];

int module3_init(void)
{
    g_total_hashes = 0;
    memset(g_last_hash, 0, sizeof(g_last_hash));
    return 0;
}

void module3_compute_hash(const uint8_t *data, uint32_t size,
                           uint8_t *hash_out)
{
    // sha256 nikal ke last hash bhi save karo, debug me kaam aata hai
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, data, size);
    SHA256_Final(hash_out, &ctx);
    memcpy(g_last_hash, hash_out, SHA256_DIGEST_LENGTH);
    g_total_hashes++;
}
