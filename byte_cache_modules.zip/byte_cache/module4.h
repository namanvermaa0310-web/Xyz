#ifndef MODULE4_H
#define MODULE4_H

#include <stdint.h>
#include "TCP/mbuf.h"
#include "module1.h"

struct socket;

#define MODULE4_HASH_SIZE   32
#define MODULE4_CHUNK_SIZE  CHUNK_SIZE
#define MODULE4_CID_SIZE     4
#define MODULE4_GEN_SIZE     4

#define TLV_TYPE_HIT     0xfd
#define TLV_TYPE_MISS    0xbf   // value = [sender_cid 4B BE][data]
#define TLV_TYPE_NAK     0xfb
#define TLV_TYPE_HELLO   0xfe   // value = generation 4B BE
#define TLV_TYPE_CONFIRM 0xfc   // value = N x sender_cid (4B BE)
#define TLV_TYPE_RAW     0xba   // conf_min_cache_size se chote chunk dedup skip karke seedha ye TLV pe chad jaate hai
#define TLV_HDR_SIZE     3

// decode side length bound: full size MISS = 4B cid + CHUNK_SIZE data, rx->val[TLV_RX_VAL_MAX + 8] ke andar hi rehta hai
#define MODULE4_MAX_TLV_VAL (TLV_RX_VAL_MAX + MODULE4_CID_SIZE)

#define MODULE4_MAX_PEERS       16
#define MODULE4_NAK_COLD_THRESHOLD 5
// confirmed bitmap 1..MODULE4_CID_SPACE cover karta hai, 4x headroom rakha hai turnover ke liye
// space ke bahar wale cids hamesha MISS jaayenge, safe hai bas dedup nahi milega
#include "module2.h"
#define MODULE4_CID_SPACE   (4U * MODULE2_MAX_CHUNKS)
#define MODULE4_BITMAP_BYTES ((MODULE4_CID_SPACE + 7U) / 8U)

// stall-at-gap: connection ke queued records pe hard cap, cap cross hote hi force drain
#define MODULE4_REORDER_MAX  1024

struct module4_state {
    uint32_t total_hits;
    uint32_t total_misses;
    uint32_t total_lookups;
    uint32_t total_nak_sent;
    uint32_t total_nak_received;
    uint32_t total_nak_unsatisfiable;
    uint32_t total_hello_sent;
    uint32_t total_hello_received;
    uint32_t total_cold_transitions;
    uint32_t forced_miss_cold;
    uint32_t forced_miss_unconfirmed;   // peer bit clear tha
    uint32_t confirms_sent;
    uint32_t confirms_received;
    uint32_t reorder_held;
    uint32_t reorder_filled;
    uint32_t reorder_overflow;          // data loss hua yaha
    uint32_t total_raws;
};

void         module4_init(void);

// peer_key se module4 cold flag aur confirmed bitmap dono nikal leta hai
struct mbuf *module4_lookup_and_build_tlv(uint8_t *hash, uint8_t *data,
                                           uint32_t data_len, uint32_t peer_key);

void         module4_decode_tlv_chain(struct mbuf *top, struct socket *so1,
                                       struct socket *so2,
                                       struct module1_state *ms);

struct mbuf *module4_build_hello(void);
void         module4_conn_reset(struct module1_state *ms);
void         module4_print_stats(void);

// health snapshot na_log ke liye, koi printf nahi bas data
struct m4_health {
    uint32_t lookups, hits, misses, raws, dedup_pct;
    uint32_t nak_sent, nak_recv, nak_unsat;
    uint32_t hello_sent, hello_recv, cold_transitions;
    uint32_t fmiss_cold, fmiss_unconf;
    uint32_t confirms_sent, confirms_recv;
    uint32_t ro_held, ro_filled, ro_overflow;
};
void         module4_get_health(struct m4_health *out);

#endif
