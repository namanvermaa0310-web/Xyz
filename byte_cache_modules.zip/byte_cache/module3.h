#ifndef MODULE3_H
#define MODULE3_H

#include <stdint.h>

int  module3_init(void);
void module3_compute_hash(const uint8_t *data, uint32_t size,
                           uint8_t *hash_out); // hash_out ka size hamesha 32 bytes rakhna
void module3_stats(void);

#endif
