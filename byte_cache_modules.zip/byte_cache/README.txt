BYTE CACHE - README
====================

WHAT IT DOES
------------
- This box sits in the middle of a TCP connection, acting as a proxy between the LAN side and a WAN/tunnel side.
- Data coming in from the LAN side gets cut into chunks (CDC does this).
- Each chunk gets hashed with SHA256.
- If the other appliance already has this exact chunk and has confirmed it -> we just send the hash (called a HIT), only 32 bytes.
- If the other side doesn't have it -> we send the full chunk (called a MISS), other side stores it and sends back a confirm so next time it's a HIT.
- If a chunk is too small (below conf_min_cache_size) -> we don't even bother hashing/storing it, just send it raw (called RAW).
- End result: repeated data becomes very cheap to send over the WAN link, only new/unique data actually goes across in full.


BIG PICTURE - WHERE THIS SITS IN THE STACK
--------------------------------------------
Two of these appliances usually sit at each end of a slow/expensive link (think satellite, VSAT, congested WAN). Each one looks like this internally:

   +----------------------------------------------------------+
   |                    THIS APPLIANCE                        |
   |                                                            |
   |   LAN side (real client/server traffic)                  |
   |        |                                                  |
   |        v                                                  |
   |   NIC -> DPDK rx queue -> IP layer -> TCP layer            |
   |        (this app's own mini TCP/IP stack, not the OS one) |
   |        |                                                  |
   |        v                                                  |
   |   socket layer (so1)                                     |
   |        |                                                  |
   |        v                                                  |
   |   TCP PROXY layer (uipc_socket.c)                         |
   |     - bridges so1 (LAN) and so2 (tunnel)                  |
   |     - decides: byte caching on or off (ENABLE_BYTE_CACHING)|
   |        |                                                  |
   |        v                                                  |
   |   BYTE CACHE layer (module1, module2, module3, module4)   |
   |     - chunk it, hash it, dedup it, frame it as TLV         |
   |        |                                                  |
   |        v                                                  |
   |   socket layer (so2) -> TCP layer -> IP layer -> DPDK tx  |
   |        |                                                  |
   +--------|---------------------------------------------------+
            v
      WAN / tunnel link (slow, expensive, this is what we're saving)
            |
            v
   +--------|---------------------------------------------------+
   |        v                          MIRROR APPLIANCE          |
   |   same stack in reverse: decode TLVs back into real bytes  |
   |   and hand them to the real server/client on its LAN side  |
   +----------------------------------------------------------+

So every byte on the LAN side is real application data (like a normal file transfer or web request). Every byte that goes out on the WAN side is either a HIT (32 byte hash), a MISS (real data + a small header), or RAW (real data, no dedup attempted).


TCP PROXY LAYER - HOW so1 AND so2 ARE BRIDGED
-------------------------------------------------
This appliance doesn't just forward packets, it terminates TWO separate TCP connections and glues them together:

   Client                 THIS APPLIANCE                  Server
     |                    (proxy, 2 sockets)                 |
     |                                                        |
     |------ TCP connection A (so1) -------->|                |
     |                                       |---- TCP connection B (so2) ---->|
     |                                       |                                 |
     |          data from so1's receive buffer is read, chunked,               |
     |          byte-cached, and written into so2's send buffer                |
     |          (and the same thing happens in reverse)                       |

Basic socket call sequence for each side, same as any normal TCP:

     server                          client
   --------------------------------------------------------
   socket()  - PRU_ATTACH          socket() - PRU_ATTACH
   bind()    - PRU_BIND
   listen()  - PRU_LISTEN
   accept()  - PRU_ACCEPT          connect() - PRU_CONNECT
   recv()    - PRU_RCVD            send()    - PRU_SEND
   send()    - PRU_SEND            recv()    - PRU_RCVD
   close()   - PRU_SHUTDOWN        close()   - PRU_SHUTDOWN
   --------------------------------------------------------

The important part for us: every time data lands in so1's receive path, that's the hook point where module1_add_data() gets called (if this connection is on the LAN side) or module4_decode_tlv_chain() gets called (if this connection is on the tunnel side). Look for the ENABLE_BYTE_CACHING check and the lanif == LAN_IF_ID check in uipc_socket.c, that's the fork in the road.

When either side sends a FIN or a RST, the proxy has to be careful: it can't close its own side until it knows the other side is done too, since the appliance isn't the original sender of the data, only a relay. That logic lives in uipc_socket.c as well, separate from the byte cache stuff, but worth knowing it's there if a connection seems to hang around after one side closes.


ENCODE SIDE FLOW (LAN data going out to the tunnel)
------------------------------------------------------

  bytes in from LAN
        |
        v
  [ module1_add_data(): feed bytes one at a time into the chunker ]
        |
        v
  [ CDC decides where to cut a chunk boundary ]
        |
        v
  [ module3_compute_hash(): SHA256 the chunk ]
        |
        v
  [ module4_lookup_and_build_tlv(): decide what to send ]
        |
        +---- chunk too small ------> RAW  (full chunk, no hash lookup)
        |
        +---- seen before AND peer confirmed it ------> HIT  (32 byte hash)
        |
        +---- not seen, or peer hasn't confirmed ------> MISS (full chunk + our chunk id)
        |
        v
  [ TLV framed and appended to tlv_pending chain ]
        |
        v
  sent out over so2 (tunnel socket) to the other appliance


DECODE SIDE FLOW (tunnel TLVs coming in, turning back into real bytes)
--------------------------------------------------------------------------

  TLV bytes in from tunnel
        |
        v
  [ module4_decode_tlv_chain(): read TLV header, figure out the type ]
        |
        +--- HELLO   --> peer says hi with its generation number.
        |                if generation changed, wipe what we know about that peer
        |                (they lost their store), start fresh
        |
        +--- CONFIRM --> peer tells us which of OUR chunk ids it safely stored,
        |                so future HITs for those ids are now safe to send
        |
        +--- RAW     --> just forward the data straight to the LAN side
        |
        +--- HIT     --> look up the chunk by hash in our local store,
        |                if we have it, forward the real data to LAN
        |                if we don't (shouldn't normally happen), queue a
        |                hole and send a NAK asking the sender to resend it
        |
        +--- MISS    --> store the new chunk locally, send a CONFIRM back,
        |                forward the real data to LAN
        |
        +--- NAK     --> sender is telling us it couldn't resolve a HIT we sent,
                         look the chunk up again and resend it as a MISS
        |
        v
  data handed to so1 (LAN socket) in the correct order
  (a reorder queue makes sure nothing goes out of order while a NAK is pending)


PACKET / CHUNK LIFETIME (ENCODE SIDE, STEP BY STEP)
-------------------------------------------------------
1. Bytes arrive on so1 (LAN receive buffer).
2. module1_add_data() walks the bytes one by one, copying them into a chunk buffer (from a preallocated mempool, not malloc).
3. The rolling hash (CDC) is fed one byte at a time. It signals a boundary when it sees a good cut point, or when the chunk hits CHUNK_SIZE, or when the timer says the chunk has been idle too long.
4. On a boundary, process_chunk() runs: hash the chunk, ask module4 what to send (HIT/MISS/RAW), and append the resulting TLV mbuf onto tlv_pending.
5. Once all the LAN bytes for this pass are consumed, whatever built up in tlv_pending gets sent out over so2 in one shot.
6. The chunk buffer is freed back to the mempool, ready for the next chunk.


TUNING KNOBS
--------------
- conf_min_cache_size (in profile.cfg)
  Chunks smaller than this go out as RAW instead of being hashed and stored. Default is 512 bytes.
  Raise it if small chunks are wasting store space for no real benefit.
  Lower it if you want small repeated chunks (like heartbeats) to get deduped too.

- CDC_MIN_CHUNK, CDC_TARGET_AVG, CDC_MAX_CHUNK (in cdc_engine.h)
  These control how big the chunks are on average.
  Bigger average = fewer chunks, less overhead, but one changed byte wastes a whole bigger chunk.
  Smaller average = better dedup but more CPU work and more index entries.

- INACTIVITY_TICKS (in module1.h)
  How long to wait with no new data before flushing a half-built chunk.
  Lower it if traffic is bursty and data feels stuck. Raise it if chunks are getting cut too early.

- conf_log_level (in profile.cfg)
  0 = DEBUG, 1 = INFO, 2 = WARN, 3 = ERROR. Only filters the event log, health log always logs everything.
  Use WARN or ERROR in production, use DEBUG when hunting a bug.

- conf_log_events / conf_log_health (in profile.cfg)
  File paths for the two logs. Leave empty to turn that log off.
  Files rotate at 32MB and keep one backup copy.

- MODULE2_EVICT_GRACE (in module2.h)
  How many accesses a slot is protected from eviction, so a chunk that was just sent as a HIT doesn't get evicted before the other side asks for it.
  Raise it if you're seeing eviction problems on a high latency link.

- MODULE4_NAK_COLD_THRESHOLD (in module4.h)
  How many NAKs in a row before a peer is marked cold (meaning: stop sending HITs, go MISS-only until they confirm again).
  Lower it to fail safe faster, raise it if peers are going cold too easily.

- MODULE4_REORDER_MAX (in module4.h)
  Max number of records that can wait in the decode queue while a hole is unresolved.
  Raise it if your link is slow or lossy and repairs take a while, but remember this is also your worst case memory usage, so don't raise it blindly.


WHICH na_log FUNCTION TO CALL, AND WHEN
-----------------------------------------
- Everything is a no-op until na_log_init() runs (it runs by itself inside module1_init()), so no need to check if logging is on before calling anything.

- na_log(level, message) -- use this only for things worth reading later: NAK bursts, a peer going cold, reorder overflow, generation changes, malloc failures, and so on. This writes to na_events.log, one line per call. Never call this per packet or per chunk, it will slow things down a lot.

- na_log_health_tick() -- call this once per second from the housekeeping timer (already wired up in app_thread.c). It writes one JSON line to na_health.jsonl with pool, store, dedup and reorder numbers. After a crash, check the last few lines of this file to see what state things were in.

- na_log_set_pools() -- call this right before or together with na_log_health_tick(), so the health snapshot has fresh mbuf pool numbers. module2 and module4 don't touch the memory pool directly, so this function is what feeds those numbers in.

- na_log_close() -- call this once on a clean shutdown if you have one. Not required since every write is flushed anyway, it just writes a clean "stop" line at the end.

Easy way to remember it: na_log() is like writing in a diary, na_log_health_tick() is like taking a photo of the dashboard, and na_log_set_pools() is handing the camera the missing numbers right before it takes the photo.


WHAT TO LOOK AT IN na_health.jsonl
------------------------------------
- mb_free / rx_free / tx_free and their fail counters -- pool health. A free count that keeps dropping, or a fail count that keeps rising, means a leak or a pool that's too small.
- store_used / store_max / store_mb -- how full the chunk store is.
- evict / evict_forced -- evict is normal eviction, evict_forced is the rare case where the eviction hand gave up and just took a slot anyway. evict_forced should stay near zero, if it's climbing the store is under real pressure.
- lookups / hits / miss / raw / dedup_pct -- how well dedup is actually working.
- nak_s / nak_r / nak_unsat -- nak_unsat going up means neither side has the chunk, which usually means real data loss upstream or a wiped store on one side.
- hello_s / hello_r / cold -- cold going up more than expected means peers are dropping into MISS-only mode too often.
- fmiss_cold / fmiss_unconf -- both mean we sent a MISS even though we already had the chunk. fmiss_cold is because the peer was cold, fmiss_unconf is because the peer was warm but hadn't confirmed this particular chunk yet. High right after startup is normal (bitmap still filling up), high in steady state means something is wrong with CONFIRM.
- ro_held / ro_filled / ro_ovf -- reorder queue stats. ro_ovf above zero means data loss happened, worth checking the event log for when.


WHERE THIS IS WIRED IN THE CODE
--------------------------------
- uipc_socket.c: checks ENABLE_BYTE_CACHING. LAN data goes into module1_add_data() (the encode/chunking side). Tunnel data goes into module4_decode_tlv_chain() (the decode side).
- app_thread.c: the housekeeping timer calls byte_caching_timer_check() for every connection, every tick. This makes sure a half-built chunk gets flushed out after INACTIVITY_TICKS if no new data shows up.
- Same timer loop also calls na_log_set_pools() and na_log_health_tick() every 1000 ticks, and module2_print_stats() / module4_print_stats() every 10000 ticks (console only, not the log files).
- module1_init() needs to run once at startup. It loads profile.cfg and also starts na_log internally. This call was not found in uipc_socket.c or app_thread.c, so it must be somewhere else (probably main.c).
- module1_state_init() should run whenever a new connection is created, because it resets the state including hello_sent, so the connection sends a fresh HELLO. Also not found in these two files.


THINGS TO REMEMBER
--------------------
- RAW chunks still go through the reorder queue to keep order correct, but they can never fill a hole since they have no hash. So if a RAW chunk shows up while a NAK repair is pending, it just queues up normally, it won't fix the hole.
- A brand new peer is NOT marked cold on its first HELLO. It starts warm with an empty confirm list, which naturally forces MISS until confirms start coming in. This is intentional, don't "fix" it or the old bug will come back (there's a comment explaining this in handle_record()).
- A generation mismatch in a HELLO means the peer's store got wiped. This causes a full cold reset and clears the confirm bitmap, it's not just a minor warning.
- fmiss_cold and fmiss_unconf look similar but mean different things: cold means the peer itself is cold, unconf means the peer is warm but hasn't confirmed this specific chunk id yet. Check both whenever you're wondering why MISS count looks high.
- This appliance keeps its own TCP/IP stack (DPDK based), it's not just using the OS network stack, so behavior can differ a bit from a normal Linux box, especially around retransmits and window scaling.
