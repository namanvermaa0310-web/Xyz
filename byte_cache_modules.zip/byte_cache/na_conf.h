#ifndef NA_CONF_H
#define NA_CONF_H

#include <stdint.h>

// na_conf reads the [na_params] block from profile.cfg
// apna khud ka chota INI reader hai, cfg_file.c ko touch nahi karna pada
// chaho to na_conf_load() ki jagah rte_cfgfile_get_entry() use kar sakte ho

#define NA_DEFAULT_MIN_CACHE_SIZE  512U

void        na_conf_load(const char *profile_path);
uint32_t    na_conf_min_cache_size(void);
const char *na_conf_log_events(void);
const char *na_conf_log_health(void);
int         na_conf_log_level(void);

#endif
