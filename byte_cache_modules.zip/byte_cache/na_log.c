#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "na_log.h"
#include "module2.h"
#include "module4.h"

static FILE          *g_ev;
static FILE          *g_hl;
static char           g_ev_path[256];
static char           g_hl_path[256];
static na_log_level_t g_min = NA_LOG_INFO;
static unsigned long  g_ev_bytes, g_hl_bytes;

// pools app_thread.c se aate hai, na_log ko TCP/ layer pe depend nahi karna
static unsigned long p_mb, p_rx, p_tx, p_mbf, p_rxf, p_txf;

static const char *lvl_str(na_log_level_t l)
{
    switch (l) {
    case NA_LOG_DEBUG: return "DEBUG";
    case NA_LOG_INFO:  return "INFO";
    case NA_LOG_WARN:  return "WARN";
    default:           return "ERROR";
    }
}

static void rotate(FILE **fp, char *path, unsigned long *bytes)
{
    char old[300];
    if (*bytes < NA_LOG_MAX_BYTES) return;
    fclose(*fp);
    snprintf(old, sizeof(old), "%s.1", path);
    rename(path, old);
    *fp = fopen(path, "w");
    *bytes = 0;
}

void na_log_init(const char *event_path, const char *health_path,
                 na_log_level_t min_level)
{
    g_min = min_level;

    if (event_path && event_path[0]) {
        snprintf(g_ev_path, sizeof(g_ev_path), "%s", event_path);
        g_ev = fopen(g_ev_path, "a");
        if (g_ev) {
            g_ev_bytes = (unsigned long)ftell(g_ev);
            na_log(NA_LOG_INFO, "=== na_log start, generation=%u ===", module2_get_generation());
        }
    }
    if (health_path && health_path[0]) {
        snprintf(g_hl_path, sizeof(g_hl_path), "%s", health_path);
        g_hl = fopen(g_hl_path, "a");
        if (g_hl) g_hl_bytes = (unsigned long)ftell(g_hl);
    }
}

void na_log(na_log_level_t lvl, const char *fmt, ...)
{
    va_list ap;
    char    ts[32];
    time_t  now;
    struct tm tmv;
    int     n;

    if (!g_ev || lvl < g_min) return;

    now = time(NULL);
    localtime_r(&now, &tmv);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);

    n = fprintf(g_ev, "%s [%-5s] ", ts, lvl_str(lvl));
    va_start(ap, fmt);
    n += vfprintf(g_ev, fmt, ap);
    va_end(ap);
    n += fprintf(g_ev, "\n");
    fflush(g_ev);

    if (n > 0) g_ev_bytes += (unsigned long)n;
    rotate(&g_ev, g_ev_path, &g_ev_bytes);
}

void na_log_set_pools(unsigned long mb_free, unsigned long rx_free,
                      unsigned long tx_free, unsigned long mb_fail,
                      unsigned long rx_fail, unsigned long tx_fail)
{
    p_mb = mb_free; p_rx = rx_free; p_tx = tx_free;
    p_mbf = mb_fail; p_rxf = rx_fail; p_txf = tx_fail;
}

void na_log_health_tick(void)
{
    struct m2_health h2;
    struct m4_health h4;
    int n;

    if (!g_hl) return;

    module2_get_health(&h2);
    module4_get_health(&h4);

    // ek hi line me pura json dump kar do, alag alag lines me split karne ki zarurat nahi
    n = fprintf(g_hl, "{\"t\":%ld,\"mb_free\":%lu,\"rx_free\":%lu,\"tx_free\":%lu,\"mb_fail\":%lu,\"rx_fail\":%lu,\"tx_fail\":%lu,\"store_used\":%u,\"store_max\":%u,\"store_mb\":%u,\"evict\":%u,\"evict_forced\":%u,\"gen\":%u,\"lookups\":%u,\"hits\":%u,\"miss\":%u,\"raw\":%u,\"dedup_pct\":%u,\"nak_s\":%u,\"nak_r\":%u,\"nak_unsat\":%u,\"hello_s\":%u,\"hello_r\":%u,\"cold\":%u,\"fmiss_cold\":%u,\"fmiss_unconf\":%u,\"conf_s\":%u,\"conf_r\":%u,\"ro_held\":%u,\"ro_filled\":%u,\"ro_ovf\":%u}\n",
        (long)time(NULL), p_mb, p_rx, p_tx, p_mbf, p_rxf, p_txf, h2.used, h2.max, h2.mb_stored, h2.evictions, h2.evict_forced, h2.generation, h4.lookups, h4.hits, h4.misses, h4.raws, h4.dedup_pct, h4.nak_sent, h4.nak_recv, h4.nak_unsat, h4.hello_sent, h4.hello_recv, h4.cold_transitions, h4.fmiss_cold, h4.fmiss_unconf, h4.confirms_sent, h4.confirms_recv, h4.ro_held, h4.ro_filled, h4.ro_overflow);
    fflush(g_hl);

    if (n > 0) g_hl_bytes += (unsigned long)n;
    rotate(&g_hl, g_hl_path, &g_hl_bytes);
}

void na_log_close(void)
{
    if (g_ev) { na_log(NA_LOG_INFO, "=== na_log stop ==="); fclose(g_ev); g_ev = NULL; }
    if (g_hl) { fclose(g_hl); g_hl = NULL; }
}
