#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "na_conf.h"

static uint32_t g_min_cache = NA_DEFAULT_MIN_CACHE_SIZE;
static char     g_ev[256]   = "na_events.log";
static char     g_hl[256]   = "na_health.jsonl";
static int      g_level     = 1;

static void trim(char *s)
{
    char *p = s;
    size_t n;
    while (*p == ' ' || *p == '\t') p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
    n = strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r' ||
                     s[n-1] == ' '  || s[n-1] == '\t')) s[--n] = '\0';
}

void na_conf_load(const char *profile_path)
{
    FILE *f;
    char  line[512];
    int   in_na = 0;

    if (!profile_path) return;
    f = fopen(profile_path, "r");
    if (!f) {
        printf("na_conf: cannot open %s -- using defaults (min_cache_size=%u)\n", profile_path, g_min_cache);
        return;
    }

    while (fgets(line, sizeof(line), f)) {
        char *semi = strchr(line, ';');
        char *eq;
        if (semi) *semi = '\0';
        trim(line);
        if (line[0] == '\0' || line[0] == '#') continue;

        if (line[0] == '[') { in_na = (strncmp(line, "[na_params]", 11) == 0); continue; }
        if (!in_na) continue;

        eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        trim(line); trim(eq + 1);

        // bas key match karo aur global me daal do, kuch fancy nahi
        if      (!strcmp(line, "conf_min_cache_size")) g_min_cache = (uint32_t)strtoul(eq + 1, NULL, 10);
        else if (!strcmp(line, "conf_log_events"))     snprintf(g_ev, sizeof(g_ev), "%s", eq + 1);
        else if (!strcmp(line, "conf_log_health"))     snprintf(g_hl, sizeof(g_hl), "%s", eq + 1);
        else if (!strcmp(line, "conf_log_level"))      g_level = atoi(eq + 1);
    }
    fclose(f);

    printf("na_conf: min_cache_size=%u events=%s health=%s level=%d\n", g_min_cache, g_ev[0] ? g_ev : "(off)", g_hl[0] ? g_hl : "(off)", g_level);
}

uint32_t    na_conf_min_cache_size(void) { return g_min_cache; }
const char *na_conf_log_events(void)     { return g_ev; }
const char *na_conf_log_health(void)     { return g_hl; }
int         na_conf_log_level(void)      { return g_level; }
