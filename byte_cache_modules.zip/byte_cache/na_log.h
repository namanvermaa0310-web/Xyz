#ifndef NA_LOG_H
#define NA_LOG_H

#include <stdint.h>

// na_log -- fault log + har second ka health snapshot, do alag files hai jaan bujh ke
// events log = kya kharab hua, health jsonl = kis condition me hua (black box jaisa)
// dono NA_LOG_MAX_BYTES pe rotate hote hai, aur agar init hi nahi kiya to sab no-op hai

#define NA_LOG_MAX_BYTES   (32U * 1024U * 1024U)

typedef enum {
    NA_LOG_DEBUG = 0,
    NA_LOG_INFO,
    NA_LOG_WARN,
    NA_LOG_ERROR
} na_log_level_t;

// event_path / health_path NULL de do to wo stream disable ho jaayega
void na_log_init(const char *event_path, const char *health_path,
                 na_log_level_t min_level);

void na_log(na_log_level_t lvl, const char *fmt, ...)
     __attribute__((format(printf, 2, 3)));

// housekeeping timer se hi call karna, per packet mat karna isko
void na_log_health_tick(void);

// pool figures TCP/MemPool layer se aate hai, app_thread.c push karta hai tick se pehle
void na_log_set_pools(unsigned long mb_free, unsigned long rx_free,
                      unsigned long tx_free, unsigned long mb_fail,
                      unsigned long rx_fail, unsigned long tx_fail);

void na_log_close(void);

#endif
