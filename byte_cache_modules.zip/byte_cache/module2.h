#ifndef MODULE2_H
#define MODULE2_H

#include <stdint.h>
#include <stdio.h>
#include <rte_hash.h>

// 8gb slot store + clock eviction, koi linear scan nahi kisi hot path pe

#define MODULE2_MAX_CHUNKS     2097152U        // 8gb / 4096
#define MODULE2_HASH_SIZE           32
#define MODULE2_CHUNK_MAX         4096U
#define MODULE2_HDR_SIZE            40
#define MODULE2_SLOT_SIZE      (MODULE2_HDR_SIZE + MODULE2_CHUNK_MAX)
#define MODULE2_STORE_FILE   "Chunk_store.dat"
#define MODULE2_GEN_FILE     "Chunk_store.gen"
#define MODULE2_HASH_TABLE_SZ  4194304U        // 2x keys rakhe hai
#define MODULE2_EVICT_GRACE     262144U        // access count wala window

struct chunk_index {
    uint32_t chunk_id;
    uint8_t  hash[MODULE2_HASH_SIZE];
    uint32_t data_len;
    uint32_t ref_count;
    uint64_t last_use;      // grace window ke liye stamp
    uint8_t  ref_bit;       // clock ka reference bit
    uint8_t  is_used;
};

struct module2_state {
    struct chunk_index  index[MODULE2_MAX_CHUNKS];
    uint32_t            total_stored;
    uint32_t            next_chunk_id;    // monotonic hai, kabhi reuse nahi hota
    uint64_t            use_clock;
    uint32_t            clock_hand;
    uint32_t            evictions;
    uint32_t            evict_forced;     // jab hand ne grace/ref pe haar maan li
    uint32_t            total_bytes_stored;
    uint32_t            duplicate_count;
    FILE               *fp;
    struct rte_hash    *hash_table;
    uint32_t            generation;
};

void     module2_init(void);
uint32_t module2_store_chunk(uint8_t *data, uint32_t data_len, uint8_t *hash);
uint32_t module2_find_by_hash(uint8_t *hash);
uint32_t module2_read_chunk(uint32_t chunk_id, uint8_t *buf, uint32_t buf_size);
void     module2_print_stats(void);
void     module2_increment_ref(uint32_t chunk_id);
void     module2_close(void);
uint32_t module2_get_generation(void);

// na_log ke liye health snapshot, pure data hai koi printf nahi
struct m2_health {
    uint32_t used, max, mb_stored, evictions, evict_forced, generation;
};
void     module2_get_health(struct m2_health *out);

#endif
