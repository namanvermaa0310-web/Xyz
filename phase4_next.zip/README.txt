Phase 4 -- next stage: sequencer connected to datapath
======================================================

WHAT CHANGED

1. kpke_engine.sv -- ByteEncode loop fixed.
   It issued ONE encode per key. For ML-KEM-512 each key is TWO polynomials,
   so ek and dk were only ever half written. Now runs 2*K times.
   KeyGen is 21 service calls, not 19.

2. kpke_engine.sv -- new byte_base output.
   Only the sequencer knows which polynomial of which key is being encoded,
   so it now drives the destination offset (ek at 0, dk at 1024) instead of
   a testbench setting it by hand.

3. kpke_engine.sv -- `done` was asserted too early.
   The old code raised done at the moment the LAST service call was ISSUED,
   so a caller could observe done while the final encode was still running.
   All three algorithms now route through a terminal ST_FINISH state entered
   only after that last call completes.

4. kpke_engine.sv -- state register widened to 6 bits.
   Values 0..31 were fully used; ST_FINISH collided with ST_EN_MVU at 5'd17.

5. kpke_system.sv -- NEW. Wires kpke_engine to kpke_top.
   Until now those two had never been connected: the engine was verified
   against behavioural stubs (call order) and the datapath against a
   testbench issuing calls by hand (data). This closes that gap.

RESULT

    [TB] engine started, running KeyGen unaided...
    [TB] engine reported done
    [TB] ek: 768/768 encoded bytes match
    [TB] ek: rho tail matches -> full 800 B ek
    [TB] dk: 768/768 encoded bytes match
    PASS -- sequencer + datapath produce a correct key pair

The testbench asserts start/op and waits. It issues NO service calls -- all
21 come from the FSM.

RUN

    bash run.sh

STILL TO DO

  * Encrypt needs ops kpke_datapath does not implement yet: Compress /
    Decompress with byte packing, add-message, and matvec's TRANSPOSED
    addressing (mat_base steps by 1 rather than by k). The call sequence is
    already correct in kpke_engine -- only the datapath side is missing.
  * Decrypt needs Compress_1 (poly -> 32-byte message). OP_SUB already works.
  * Then mlkem_fo_ctrl on top, with its hash instances at
    MAX_MSG_BYTES >= 800 (H(ek) and J(z||c) are both 800 bytes; the 512
    default would silently truncate).
  * Then full KeyGen -> Encaps -> Decaps against golden_mlkem.py.

NOTE ON SYNTHESIS
  kpke_engine changed in this drop, so if you have already synthesised
  kpke_top the result still stands -- kpke_top itself is untouched. Only
  synthesise kpke_system once the Phase 4 timing numbers from kpke_top are
  known and understood.
