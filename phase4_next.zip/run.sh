#!/bin/bash
set -e
echo "########## kpke_engine call sequences (Algs 13/14/15) ##########"
iverilog -g2012 -o eng.vvp mlkem_pkg.sv kpke_engine.sv tb_kpke_engine.sv
vvp eng.vvp
echo ""
echo "########## kpke_engine DRIVING kpke_top: full KeyGen ##########"
iverilog -g2012 -o sys.vvp mlkem_pkg.sv keccak_pkg.sv twiddle_rom.sv ntt_engine.sv \
  basemul.sv poly_basemul.sv matvec_mul.sv poly_slots.sv kpke_datapath.sv \
  keccak_round.sv keccak_f1600.sv sha3_512.sv shake128.sv shake256.sv sample_ntt.sv \
  cbd_sampler.sv cbd_sampler_eta3.sv kpke_seed_unit.sv kpke_top.sv kpke_engine.sv \
  kpke_system.sv tb_kpke_system.sv
vvp sys.vvp
rm -f *.vvp
