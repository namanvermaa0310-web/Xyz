`timescale 1ns/1ps
// Measure where KeyGen's cycles actually go, by counting time spent with
// each service unit active.
module tb_cycles;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start; wire busy,done,serr,reject;
  wire [5:0] d_ra; reg [7:0] d_rd;
  wire [12:0] br_a,br2_a,bw_a; wire [7:0] bw_d; wire bw_en; reg [7:0] br_d,br2_d;
  wire [255:0] rho_out; wire [4:0] dbg;
  mlkem_system #(.K_PARAM(2),.ADDR_W(13)) dut(.clk(clk),.rst_n(rst_n),.op(op),
    .start(start),.busy(busy),.done(done),.d_rd_data(d_rd),.d_rd_addr(d_ra),
    .byte_rd_addr(br_a),.byte_rd_data(br_d),.byte_rd2_addr(br2_a),.byte_rd2_data(br2_d),
    .byte_wr_addr(bw_a),.byte_wr_data(bw_d),.byte_wr_en(bw_en),
    .rho_out(rho_out),.sample_error(serr),.reject(reject),.dbg_state(dbg));
  reg [7:0] bmem[0:8191], dmem[0:63];
  always @(posedge clk) begin br_d<=bmem[br_a]; br2_d<=bmem[br2_a]; d_rd<=dmem[d_ra];
    if(bw_en) bmem[bw_a]<=bw_d; end

  integer total, c_ntt, c_xof, c_prf, c_mv, c_hash, c_other, i;
  wire [2:0] usel = dut.u_kpke.u_engine.unit_sel;
  wire kbusy = dut.u_kpke.busy;
  wire hbusy = dut.u_hash.busy;
  wire ntt_b = dut.u_kpke.u_kpke.u_dp.u_ntt.busy;
  wire sn_b  = dut.u_kpke.u_kpke.u_su.u_sn.busy;
  wire mv_b  = dut.u_kpke.u_kpke.u_dp.u_mv.busy;
  wire c3_b  = dut.u_kpke.u_kpke.u_su.u_c3.busy;
  wire x_b   = dut.u_kpke.u_kpke.u_su.u_x.busy;
  wire p_b   = dut.u_kpke.u_kpke.u_su.u_p.busy;
  wire g_b   = dut.u_kpke.u_kpke.u_su.u_g.busy;

  initial begin
    for(i=0;i<64;i=i+1) dmem[i]=i;
    for(i=0;i<8192;i=i+1) bmem[i]=8'h00;
    total=0;c_ntt=0;c_xof=0;c_prf=0;c_mv=0;c_hash=0;c_other=0;
    rst_n=0;start=0;op=0; repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);
    @(negedge clk); op=2'd0; start=1; @(negedge clk); start=0;
    while(!busy) @(posedge clk);
    while(busy) begin
      @(posedge clk);
      total = total+1;
      if (ntt_b)       c_ntt  = c_ntt+1;
      else if (x_b||sn_b) c_xof = c_xof+1;
      else if (p_b||c3_b) c_prf = c_prf+1;
      else if (mv_b)   c_mv   = c_mv+1;
      else if (g_b||hbusy) c_hash = c_hash+1;
      else             c_other= c_other+1;
    end
    $display("=== KeyGen cycle breakdown (100 MHz) ===");
    $display("  NTT engine      %7d cycles  %5.1f%%", c_ntt,  100.0*c_ntt/total);
    $display("  XOF+SampleNTT   %7d cycles  %5.1f%%", c_xof,  100.0*c_xof/total);
    $display("  PRF+CBD         %7d cycles  %5.1f%%", c_prf,  100.0*c_prf/total);
    $display("  matvec          %7d cycles  %5.1f%%", c_mv,   100.0*c_mv/total);
    $display("  G / H hashes    %7d cycles  %5.1f%%", c_hash, 100.0*c_hash/total);
    $display("  other/overhead  %7d cycles  %5.1f%%", c_other,100.0*c_other/total);
    $display("  --------------------------------");
    $display("  TOTAL           %7d cycles  = %0.1f us at 100 MHz",
             total, total/100.0);
    $finish;
  end
  initial begin #400_000_000; $display("TIMEOUT"); $finish; end
endmodule
