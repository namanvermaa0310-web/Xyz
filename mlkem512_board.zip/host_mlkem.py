#!/usr/bin/env python3
"""
host_mlkem.py -- bench driver and interoperability demo for the KC705
                 ML-KEM-512 accelerator.

Three modes:

  selftest   FPGA does KeyGen, Encaps and Decaps entirely on its own, and the
             two shared secrets are compared. Proves the hardware works.

  interop    *** THE DEMONSTRATION ***
             FPGA generates a keypair and does Decaps. kyber-py -- an
             INDEPENDENT software implementation written by someone else --
             does Encaps against the FPGA's public key. Both sides print
             their 32-byte shared secret. They match.

             This is what convinces a sceptical reviewer: two independent
             implementations, one of them not yours, agreeing on a secret.
             A self-test only shows your design agrees with your model.

  reject     Corrupts one ciphertext bit and shows Decaps returns a DIFFERENT
             secret rather than the real one -- the implicit-rejection path
             that makes ML-KEM CCA-secure.

Usage (Windows):
    py -m pip install pyserial kyber-py
    py host_mlkem.py COM6 interop

Usage (Linux):
    python3 host_mlkem.py /dev/ttyUSB0 interop
"""

import sys
import time

try:
    import serial
except ImportError:
    sys.exit("pyserial not installed.  Run:  py -m pip install pyserial")

BAUD = 115200

C_PING, PING_R = 0xA5, 0x5A
C_WR, C_RD, C_SEED = 0x10, 0x11, 0x12
C_KG, C_EN, C_DE = 0x20, 0x21, 0x22
C_STAT = 0x30

# Byte map -- must match mlkem_system.sv exactly.
CT_BASE, DK_BASE, MSG_BASE = 0, 1024, 1868
EK_BASE, HEK_BASE, Z_BASE, SS_BASE = 2048, 2900, 3100, 3900


class Board:
    def __init__(self, port):
        self.ser = serial.Serial(port, BAUD, timeout=3.0)
        time.sleep(0.2)
        self.ser.reset_input_buffer()

    def _expect(self, want, what):
        got = self.ser.read(1)
        if not got:
            raise TimeoutError(f"{what}: no reply (timeout)")
        if got[0] != want:
            raise ValueError(f"{what}: got 0x{got[0]:02X}, expected 0x{want:02X}")

    def ping(self, retries=3):
        # Opening a COM port toggles DTR/RTS on many USB-UART bridges, so the
        # first byte can be lost while the link settles. Retry rather than
        # fail the run on a benign first miss.
        for attempt in range(retries):
            try:
                self.ser.reset_input_buffer()
                self.ser.write(bytes([C_PING]))
                self._expect(PING_R, "PING")
                return attempt
            except (TimeoutError, ValueError):
                if attempt == retries - 1:
                    raise
                time.sleep(0.3)

    def wr(self, addr, b):
        self.ser.write(bytes([C_WR, addr & 0xFF, (addr >> 8) & 0xFF, b]))
        self._expect(C_WR, f"WRITE[{addr}]")

    def rd(self, addr):
        self.ser.write(bytes([C_RD, addr & 0xFF, (addr >> 8) & 0xFF]))
        b = self.ser.read(1)
        if not b:
            raise TimeoutError(f"READ[{addr}]: no reply")
        return b[0]

    def wr_block(self, addr, data):
        for i, b in enumerate(data):
            self.wr(addr + i, b)

    def rd_block(self, addr, n):
        return bytes(self.rd(addr + i) for i in range(n))

    def seed(self, data):
        for i, b in enumerate(data):
            self.ser.write(bytes([C_SEED, i, b]))
            self._expect(C_SEED, f"SEED[{i}]")

    def status(self):
        self.ser.write(bytes([C_STAT]))
        b = self.ser.read(1)
        if not b:
            raise TimeoutError("STATUS: no reply")
        return {"busy": bool(b[0] & 1), "done": bool(b[0] & 2),
                "reject": bool(b[0] & 4)}

    def run(self, cmd, name, timeout_s=30.0):
        self.ser.write(bytes([cmd]))
        self._expect(cmd, f"START {name}")
        t0 = time.time()
        # Wait for busy to RISE, then to FALL. Polling `done` alone would see
        # the previous operation's completion -- the same level-held-done trap
        # that bit this design seven times in RTL.
        while time.time() - t0 < timeout_s:
            if self.status()["busy"]:
                break
        while time.time() - t0 < timeout_s:
            st = self.status()
            if not st["busy"]:
                return time.time() - t0, st
        raise TimeoutError(f"{name} never completed")


def hexs(b):
    return b.hex()


# ---------------------------------------------------------------------------
def mode_selftest(bd):
    print("\n=== SELF-TEST: FPGA does KeyGen, Encaps and Decaps ===\n")
    d = bytes(range(32))
    z = bytes(range(32, 64))
    m = bytes(range(64, 96))

    bd.seed(d)
    bd.wr_block(Z_BASE, z)
    bd.wr_block(MSG_BASE, m)

    dt, _ = bd.run(C_KG, "KeyGen")
    print(f"KeyGen  : {dt*1000:7.1f} ms")
    ek = bd.rd_block(EK_BASE, 800)
    print(f"  ek    : {hexs(ek[:16])}...  ({len(ek)} bytes)")

    # ek must be staged where Encaps expects it, and H(ek) alongside.
    import hashlib
    bd.wr_block(HEK_BASE, hashlib.sha3_256(ek).digest())
    bd.wr_block(Z_BASE + 32, bytes(768))     # placeholder, filled after Encaps

    dt, _ = bd.run(C_EN, "Encaps")
    print(f"Encaps  : {dt*1000:7.1f} ms")
    ct = bd.rd_block(CT_BASE, 768)
    k_enc = bd.rd_block(SS_BASE, 32)
    print(f"  ct    : {hexs(ct[:16])}...  ({len(ct)} bytes)")
    print(f"  K     : {hexs(k_enc)}")

    bd.wr_block(Z_BASE + 32, ct)             # J hashes z || c
    dt, st = bd.run(C_DE, "Decaps")
    k_dec = bd.rd_block(SS_BASE, 32)
    print(f"Decaps  : {dt*1000:7.1f} ms   reject={st['reject']}")
    print(f"  K'    : {hexs(k_dec)}")

    print()
    if k_enc == k_dec:
        print("  PASS -- both sides derived the SAME shared secret")
        return 0
    print("  FAIL -- shared secrets differ")
    return 1


def mode_interop(bd):
    """The demonstration: FPGA Decaps against software Encaps."""
    try:
        from kyber_py.ml_kem import ML_KEM_512
    except ImportError:
        sys.exit("kyber-py not installed.  Run:  py -m pip install kyber-py")
    import hashlib

    print("\n=== INTEROPERABILITY: FPGA <-> kyber-py (independent software) ===\n")

    d = bytes(range(32))
    z = bytes(range(32, 64))
    bd.seed(d)
    bd.wr_block(Z_BASE, z)

    dt, _ = bd.run(C_KG, "KeyGen")
    ek = bd.rd_block(EK_BASE, 800)
    dk_pke = bd.rd_block(DK_BASE, 768)
    print(f"[FPGA]  KeyGen in {dt*1000:.1f} ms")
    print(f"[FPGA]  public key ek = {hexs(ek[:24])}...")

    # --- software side: Encaps against the FPGA's public key ---
    dk = dk_pke + ek + hashlib.sha3_256(ek).digest() + z
    m = bytes(range(96, 128))
    k_sw, ct = ML_KEM_512._encaps_internal(ek, m)
    print(f"\n[kyber-py] Encaps against that key")
    print(f"[kyber-py] ciphertext = {hexs(ct[:24])}...")
    print(f"[kyber-py] shared secret = {hexs(k_sw)}")

    # --- FPGA side: Decaps that ciphertext ---
    bd.wr_block(CT_BASE, ct)
    bd.wr_block(HEK_BASE, hashlib.sha3_256(ek).digest())
    bd.wr_block(Z_BASE + 32, ct)
    dt, st = bd.run(C_DE, "Decaps")
    k_hw = bd.rd_block(SS_BASE, 32)
    print(f"\n[FPGA]  Decaps in {dt*1000:.1f} ms   reject={st['reject']}")
    print(f"[FPGA]  shared secret = {hexs(k_hw)}")

    print("\n" + "=" * 62)
    if k_hw == k_sw:
        print("  PASS -- FPGA and independent software agree on the secret")
        print("  Two implementations, one not ours, same 32 bytes.")
        print("=" * 62)
        return 0
    print("  FAIL -- secrets differ")
    print("=" * 62)
    return 1


def mode_reject(bd):
    """Show the implicit-rejection path with a corrupted ciphertext."""
    import hashlib
    print("\n=== IMPLICIT REJECTION: corrupted ciphertext ===\n")

    d = bytes(range(32)); z = bytes(range(32, 64)); m = bytes(range(64, 96))
    bd.seed(d); bd.wr_block(Z_BASE, z); bd.wr_block(MSG_BASE, m)
    bd.run(C_KG, "KeyGen")
    ek = bd.rd_block(EK_BASE, 800)
    bd.wr_block(HEK_BASE, hashlib.sha3_256(ek).digest())
    bd.run(C_EN, "Encaps")
    ct = bd.rd_block(CT_BASE, 768)
    k_good = bd.rd_block(SS_BASE, 32)

    bd.wr_block(Z_BASE + 32, ct)
    bd.run(C_DE, "Decaps (valid)")
    k_valid = bd.rd_block(SS_BASE, 32)
    print(f"valid ciphertext   -> K  = {hexs(k_valid)}")

    bad = bytearray(ct); bad[100] ^= 0x01
    bd.wr_block(CT_BASE, bytes(bad))
    bd.wr_block(Z_BASE + 32, bytes(bad))
    _, st = bd.run(C_DE, "Decaps (corrupted)")
    k_bad = bd.rd_block(SS_BASE, 32)
    print(f"one bit flipped    -> K' = {hexs(k_bad)}   reject={st['reject']}")

    print()
    ok = (k_valid == k_good) and (k_bad != k_good) and st["reject"]
    if ok:
        print("  PASS -- corruption produced a DIFFERENT secret, not the real one")
        print("  That is the CCA-security property of the FO transform.")
        return 0
    print("  FAIL -- rejection path did not behave correctly")
    return 1


def main():
    if len(sys.argv) < 2:
        sys.exit(f"usage: {sys.argv[0]} <serial-port> [selftest|interop|reject]")
    port = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else "selftest"

    print(f"Opening {port} at {BAUD} baud...")
    bd = Board(port)
    print("PING...", end=" ", flush=True)
    tries = bd.ping()
    print("ok, link alive" + (f" (after {tries} retries)" if tries else ""))

    if mode == "selftest":
        return mode_selftest(bd)
    if mode == "interop":
        return mode_interop(bd)
    if mode == "reject":
        return mode_reject(bd)
    sys.exit(f"unknown mode: {mode}")


if __name__ == "__main__":
    sys.exit(main())
