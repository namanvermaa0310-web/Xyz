# Adding an ILA to the ML-KEM board build

The RTL now carries `MARK_DEBUG` on the signals that matter. Vivado still
needs to be told to instantiate the ILA.

## Signals already marked

    sys_op      [1:0]   which operation was requested
    sys_start           the kick pulse
    sys_busy            engine running
    sys_done            completion (LEVEL-HELD -- see note)
    sys_reject          FO verdict
    sys_err             SampleNTT stream exhaustion
    state       [3:0]   UART command FSM
    host_owns           byte-memory arbitration

Every bug found on the bench would have been visible here:
  * host_owns and sys_busy together show the arbitration race
  * state stuck outside ST_CMD shows the UART TX desync
  * sys_done staying high across operations shows the level-held-done trap

## Method 1 -- Set Up Debug wizard (easiest)

    Open Synthesized Design
    -> Tools -> Set Up Debug
    -> the MARK_DEBUG nets appear automatically
    -> sample depth 4096, trigger on sys_start rising
    -> Save constraints (writes debug nets into the XDC)
    -> re-run Implementation and Generate Bitstream

## Method 2 -- Tcl, if you want it repeatable

    create_debug_core u_ila_0 ila
    set_property C_DATA_DEPTH 4096 [get_debug_cores u_ila_0]
    set_property C_TRIGIN_EN false [get_debug_cores u_ila_0]
    connect_debug_port u_ila_0/clk [get_nets clk100]
    # then connect each marked net as a probe

## Cost

An ILA with 4096-deep capture on ~15 bits costs roughly 1-2 BRAM tiles and a
few hundred LUTs. The design currently uses 11.5 of 445 BRAM and 34% of LUTs,
so there is ample room.

## WATCH THE TIMING

WNS on the board build is thin. An ILA adds routing and capture logic on the
probed nets. CHECK WNS AFTER ADDING IT -- if it goes negative, either probe
fewer signals or drop the core clock to 83 MHz (CLKOUT0_DIVIDE_F 12.000,
CLKS_PER_BIT 723).

## Cheaper alternative: the cycle counter

For pure timing questions the ILA is overkill -- command 0x31 returns the
exact cycle count of the last operation, four bytes LSB first, and
host_nist.py already prints it. That is how the 1.2 ms figure was traced to
UART polling rather than compute.
