## =============================================================================
## kc705_mlkem.xdc -- KC705 pin + timing constraints for kc705_mlkem_top
## Target: xc7k325tffg900-2.  THIS one produces a real bitstream.
## =============================================================================
## Only 6 pins. Every one is a documented KC705 net (UG810 Appendix C), and the
## same four used by the hardware-proven Phase 1-3 wrappers.

## 200 MHz differential oscillator, bank 33
set_property PACKAGE_PIN AD12 [get_ports sysclk_p]
set_property PACKAGE_PIN AD11 [get_ports sysclk_n]
set_property IOSTANDARD LVDS  [get_ports sysclk_p]
set_property IOSTANDARD LVDS  [get_ports sysclk_n]
## GOTCHA: bank 33 is 1.5 V. UG810 says LVDS; some Vivado versions demand
## DIFF_SSTL15 instead. If synthesis errors on the IOSTANDARD, comment the two
## lines above and use these:
#set_property IOSTANDARD DIFF_SSTL15 [get_ports sysclk_p]
#set_property IOSTANDARD DIFF_SSTL15 [get_ports sysclk_n]
create_clock -period 5.000 -name sysclk -waveform {0.000 2.500} [get_ports sysclk_p]

## CPU_RESET pushbutton, bank 34 (1.5 V), ACTIVE HIGH
set_property PACKAGE_PIN AB7     [get_ports cpu_reset]
set_property IOSTANDARD LVCMOS15 [get_ports cpu_reset]

## USB-UART bridge (Silicon Labs CP2103), bank 15 (2.5 V).
## Direction is from the FPGA's point of view.
set_property PACKAGE_PIN M19     [get_ports uart_rx]
set_property IOSTANDARD LVCMOS25 [get_ports uart_rx]
set_property PACKAGE_PIN K24     [get_ports uart_tx]
set_property IOSTANDARD LVCMOS25 [get_ports uart_tx]
## NOTE (Xilinx AR 45934): UG810's K24/M19 do not match Vivado's
## part0_pins.xml. These follow UG810 and are what Phases 1-2 ran with on this
## board. If the port does not respond, swapping them is the first thing to try.

## Status LEDs, bank 33 (1.5 V)
set_property PACKAGE_PIN AB8     [get_ports led_busy]
set_property IOSTANDARD LVCMOS15 [get_ports led_busy]
set_property PACKAGE_PIN AA8     [get_ports led_reject]
set_property IOSTANDARD LVCMOS15 [get_ports led_reject]

## Asynchronous inputs: double-flopped internally, nothing to constrain.
set_false_path -from [get_ports uart_rx]
set_false_path -to   [get_ports uart_tx]
set_false_path -from [get_ports cpu_reset]
set_false_path -to   [get_ports led_busy]
set_false_path -to   [get_ports led_reject]

set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 2.5 [current_design]

## =============================================================================
## TIMING EXPECTATION
## mlkem_system alone closed at WNS = +0.233 ns -- only 2.3% of the 10 ns
## period. This wrapper adds the UART core and an 8 KB byte memory on top, so
## CHECK WNS BEFORE GENERATING THE BITSTREAM. If it goes negative, the cheapest
## fix is dropping the core clock: set CLKOUT0_DIVIDE_F to 12.000 (83 MHz) in
## kc705_mlkem_top.sv and CLKS_PER_BIT to 723 to keep 115200 baud.
## A design with negative slack programs fine and computes silently wrong
## values -- which is exactly what host_mlkem.py's staged checks are built to
## catch.
## =============================================================================
