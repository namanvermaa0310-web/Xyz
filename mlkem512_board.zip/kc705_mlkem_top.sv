// =============================================================================
// kc705_mlkem_top.sv -- KC705 board wrapper for the complete ML-KEM-512
// -----------------------------------------------------------------------------
// The ONLY board-specific file. Identical clocking and reset scheme to the
// Phase 1-3 wrappers, which are hardware-proven on this board:
//   IBUFDS        200 MHz differential oscillator -> single ended
//   MMCME2_BASE   200 MHz -> 100 MHz core clock
//   reset sync    assert asynchronously, release synchronously
//
// Four board pins, all cross-checked against the KC705 master XDC:
//   SYSCLK_P/N  AD12 / AD11
//   CPU_RESET   AB7
//   USB_UART    M19 (into FPGA) / K24 (out of FPGA)
// plus two LEDs for at-a-glance status.
//
// Everything else lives in mlkem_uart_core, which is board-independent and
// fully simulatable -- this file instantiates Xilinx primitives and cannot be.
// =============================================================================
module kc705_mlkem_top (
  input  wire sysclk_p,
  input  wire sysclk_n,
  input  wire cpu_reset,
  input  wire uart_rx,
  output wire uart_tx,
  output wire led_busy,
  output wire led_reject
);
  wire sysclk_ibuf;
  IBUFDS #(.DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE")) u_ibufds (
    .I(sysclk_p), .IB(sysclk_n), .O(sysclk_ibuf));

  wire clk_fb, clk_fb_buf, clk100_raw, clk100, mmcm_locked;
  MMCME2_BASE #(
    .BANDWIDTH("OPTIMIZED"), .CLKIN1_PERIOD(5.000),
    .DIVCLK_DIVIDE(1), .CLKFBOUT_MULT_F(5.000),      // VCO = 1000 MHz
    .CLKOUT0_DIVIDE_F(10.000),                        // 100 MHz
    .CLKOUT0_DUTY_CYCLE(0.500), .CLKOUT0_PHASE(0.000),
    .STARTUP_WAIT("FALSE")
  ) u_mmcm (
    .CLKIN1(sysclk_ibuf), .CLKFBIN(clk_fb_buf), .CLKFBOUT(clk_fb),
    .CLKOUT0(clk100_raw),
    .CLKOUT1(), .CLKOUT2(), .CLKOUT3(), .CLKOUT4(), .CLKOUT5(), .CLKOUT6(),
    .CLKOUT0B(), .CLKOUT1B(), .CLKOUT2B(), .CLKOUT3B(), .CLKFBOUTB(),
    .LOCKED(mmcm_locked), .PWRDWN(1'b0), .RST(cpu_reset));

  BUFG u_bufg_fb  (.I(clk_fb),     .O(clk_fb_buf));
  BUFG u_bufg_clk (.I(clk100_raw), .O(clk100));

  // Assert asynchronously, release synchronously. Held in reset until the
  // MMCM locks so nothing runs on an unstable clock.
  wire async_rst = cpu_reset | ~mmcm_locked;
  (* ASYNC_REG = "TRUE" *) reg rst_meta, rst_sync;
  always @(posedge clk100 or posedge async_rst) begin
    if (async_rst) begin rst_meta <= 1'b1; rst_sync <= 1'b1; end
    else           begin rst_meta <= 1'b0; rst_sync <= rst_meta; end
  end
  wire rst_n = ~rst_sync;

  mlkem_uart_core #(.CLKS_PER_BIT(868)) u_core (
    .clk(clk100), .rst_n(rst_n),
    .uart_rx_i(uart_rx), .uart_tx_o(uart_tx),
    .busy_led(led_busy), .reject_led(led_reject));

endmodule : kc705_mlkem_top
