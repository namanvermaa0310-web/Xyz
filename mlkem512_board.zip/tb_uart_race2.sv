`timescale 1ns/1ps
// Same as before, but reads back seed_mem and Z_BASE after writing, BEFORE
// kicking KeyGen -- to catch a write that didn't land rather than inferring
// it from the final wrong ek.
module tb_uart_race2;
  localparam CPB = 4;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg tx_bit; wire rx_bit;
  mlkem_uart_core #(.CLKS_PER_BIT(CPB)) dut(
    .clk(clk), .rst_n(rst_n), .uart_rx_i(tx_bit), .uart_tx_o(rx_bit),
    .busy_led(), .reject_led());

  task send_byte(input [7:0] b);
    integer i;
    begin
      tx_bit=0; repeat(CPB)@(posedge clk);
      for(i=0;i<8;i=i+1) begin tx_bit=b[i]; repeat(CPB)@(posedge clk); end
      tx_bit=1; repeat(CPB)@(posedge clk);
    end
  endtask
  reg [7:0] got_byte;
  task recv_byte;
    begin
      wait(rx_bit===1'b0);
      repeat(CPB+CPB/2)@(posedge clk);
      got_byte[0]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[1]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[2]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[3]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[4]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[5]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[6]=rx_bit; repeat(CPB)@(posedge clk);
      got_byte[7]=rx_bit; repeat(CPB)@(posedge clk);
    end
  endtask
  task wr(input [12:0] a, input [7:0] d);
    begin send_byte(8'h10); send_byte(a[7:0]); send_byte(a[12:8]); send_byte(d); recv_byte(); end
  endtask
  task rd(input [12:0] a, output [7:0] d);
    begin send_byte(8'h11); send_byte(a[7:0]); send_byte(a[12:8]); recv_byte(); d=got_byte; end
  endtask
  task seedb(input [5:0] i, input [7:0] b);
    begin send_byte(8'h12); send_byte({2'd0,i}); send_byte(b); recv_byte(); end
  endtask
  task kick_keygen; begin send_byte(8'h20); recv_byte(); end endtask
  task soft_reset; begin send_byte(8'h40); recv_byte(); repeat(30)@(posedge clk); end endtask
  task wait_done;
    reg [7:0] st;
    begin st=8'h01; while(st[0]) begin send_byte(8'h30); recv_byte(); st=got_byte;
      repeat(50)@(posedge clk); end end
  endtask

  localparam EK=2048;
  reg [7:0] ek1[0:7], ek2[0:7], seedback[0:31];
  integer i;

  initial begin
    tx_bit=1; rst_n=0; repeat(10)@(posedge clk); rst_n=1; repeat(10)@(posedge clk);
    fork
      begin : wmon0
        integer n; n=0;
        forever begin
          @(posedge clk);
          if (dut.u_kem.u_kpke.u_kpke.u_slots.w_en &&
              dut.u_kem.u_kpke.u_kpke.u_slots.w_addr == 13'd0 && n<6) begin
            $display("  [WR0] t=%0t slot0 <= %0d  su_active=%b",
                     $time, dut.u_kem.u_kpke.u_kpke.u_slots.w_data,
                     dut.u_kem.u_kpke.u_kpke.su_active);
            n=n+1;
          end
        end
      end
    join_none
    $display("=== op1: seed 0x00..0x1F ===");
    for(i=0;i<32;i=i+1) seedb(i[5:0], i[7:0]);
    kick_keygen(); wait_done();
    for(i=0;i<8;i=i+1) rd(EK+i, ek1[i]);
    $display("op1 ek[0:8] = %02h%02h%02h%02h%02h%02h%02h%02h",
      ek1[0],ek1[1],ek1[2],ek1[3],ek1[4],ek1[5],ek1[6],ek1[7]);

    $display("op1 rho_reg[255:224] = %08h", dut.u_kem.u_kpke.u_kpke.u_su.rho_reg[255:224]);
    $display("op1 sigma_reg[255:224] = %08h", dut.u_kem.u_kpke.u_kpke.u_su.sigma_reg[255:224]);
    $display("op1 slot0(A_hat[0][0]) coeff0 = %0d", dut.u_kem.u_kpke.u_kpke.u_slots.mem[0]);
    $display("op1 slot8(s[0]) coeff0        = %0d", dut.u_kem.u_kpke.u_kpke.u_slots.mem[8*256]);

    $display("=== (monitor now armed) ===");
    fork
      begin : wmon
        reg [5:0] ps; ps=6'h3f;
        forever begin
          @(posedge clk);
          if (dut.u_kem.u_kpke.u_kpke.u_slots.w_en &&
              dut.u_kem.u_kpke.u_kpke.u_slots.w_addr == 13'd0)
            $display("  [WR] t=%0t slot0 written: data=%0d",
                     $time, dut.u_kem.u_kpke.u_kpke.u_slots.w_data);
          if (dut.u_kem.u_kpke.u_engine.state !== ps) begin
            $display("  [ENG] t=%0t state=%0d cnt=%0d unit_sel=%0d unit_a2=%0d",
                     $time, dut.u_kem.u_kpke.u_engine.state,
                     dut.u_kem.u_kpke.u_engine.cnt,
                     dut.u_kem.u_kpke.u_engine.unit_sel,
                     dut.u_kem.u_kpke.u_engine.unit_a2);
            ps = dut.u_kem.u_kpke.u_engine.state;
          end
        end
      end
    join_none
    for(i=0;i<32;i=i+1) seedb(i[5:0], 8'hA0+i[7:0]);
    // READ BACK seed_mem via the UART bridge before kicking, through
    // dut.seed_mem directly (hierarchical, simulation-only) to confirm the
    // writes actually landed.
    begin : chkseed
      integer bad; bad=0;
      for(i=0;i<32;i=i+1)
        if (dut.seed_mem[i] !== (8'hA0+i[7:0])) begin
          if(bad<4) $display("  seed_mem[%0d] = %02h, expected %02h",
                             i, dut.seed_mem[i], 8'hA0+i[7:0]);
          bad=bad+1;
        end
      if(bad==0) $display("  seed_mem: all 32 bytes landed correctly before kick");
      else $display("  seed_mem: %0d byte(s) WRONG before kick", bad);
    end
    kick_keygen(); wait_done();
    $display("op2 sample_error = %b  sn_error=%b sn_j=%0d",
      dut.u_kem.sample_error, dut.u_kem.u_kpke.u_kpke.u_su.u_sn.error,
      dut.u_kem.u_kpke.u_kpke.u_su.u_sn.j);
    $display("op2 rho_reg[255:224] = %08h", dut.u_kem.u_kpke.u_kpke.u_su.rho_reg[255:224]);
    $display("op2 sigma_reg[255:224] = %08h", dut.u_kem.u_kpke.u_kpke.u_su.sigma_reg[255:224]);
    $display("op2 slot0(A_hat[0][0]) coeff0 = %0d", dut.u_kem.u_kpke.u_kpke.u_slots.mem[0]);
    $display("op2 slot8(s[0]) coeff0        = %0d", dut.u_kem.u_kpke.u_kpke.u_slots.mem[8*256]);
    for(i=0;i<8;i=i+1) rd(EK+i, ek2[i]);
    $display("op2 ek[0:8] = %02h%02h%02h%02h%02h%02h%02h%02h",
      ek2[0],ek2[1],ek2[2],ek2[3],ek2[4],ek2[5],ek2[6],ek2[7]);
    $display("(expected 13 d9 94 04 4b a3 ...)");
    $finish;
  end
  initial begin #50_000_000; $display("TIMEOUT"); $finish; end
endmodule
