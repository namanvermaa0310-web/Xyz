// =============================================================================
// mlkem_uart_core.sv -- UART command bridge for the complete ML-KEM-512
// -----------------------------------------------------------------------------
// Board-INDEPENDENT (plain clk/rst_n plus one UART rx and one tx pin), so it
// simulates in full. All KC705 glue lives in kc705_mlkem_top.sv.
//
// Owns the two memories mlkem_system expects the caller to provide:
//   byte_mem  8192 x 8  -- ek, dk, ciphertext, message, seeds, working space
//   seed_mem    64 x 8  -- the 32-byte d handed to K-PKE KeyGen
//
// byte_mem needs TWO read ports: verify_cmov compares the received ciphertext
// against the re-encrypted one in the same cycle. A real BRAM has two, so this
// costs nothing.
//
// COMMAND PROTOCOL (host -> FPGA), 8N1, LSB first:
//
//   0xA5                          PING              -> 0x5A
//   0x10 <a_lo> <a_hi> <data>     write byte_mem    -> 0x10
//   0x11 <a_lo> <a_hi>            read  byte_mem    -> <data>
//   0x12 <addr> <data>            write seed_mem    -> 0x12
//   0x20                          run KeyGen        -> 0x20
//   0x21                          run Encaps        -> 0x21
//   0x22                          run Decaps        -> 0x22
//   0x30                          status            -> {5'b0,reject,done,busy}
//
// Addresses are 13-bit little-endian on the wire (low byte first).
//
// The host stages inputs with 0x10, kicks an operation, polls 0x30 until
// busy clears, then reads results back with 0x11. That is enough to drive
// the entire KEM from a PC and to interoperate with a software
// implementation -- see host_mlkem.py.
// =============================================================================
module mlkem_uart_core #(
  parameter integer CLKS_PER_BIT = 868   // 100 MHz / 115200 baud
)(
  input  wire clk,
  input  wire rst_n,
  input  wire uart_rx_i,
  output wire uart_tx_o,
  output wire busy_led,
  output wire reject_led
);

  // ---------------------------------------------------------------------------
  // UART physical layer (unchanged from Phases 1-3)
  // ---------------------------------------------------------------------------
  wire [7:0] rx_data;
  wire       rx_valid;
  uart_rx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_rx (
    .clk(clk), .rst_n(rst_n), .rx(uart_rx_i),
    .data(rx_data), .valid(rx_valid));

  reg        tx_send;
  reg  [7:0] tx_data;
  wire       tx_busy;
  uart_tx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_tx (
    .clk(clk), .rst_n(rst_n), .send(tx_send), .data(tx_data),
    .tx(uart_tx_o), .busy(tx_busy));

  // ---------------------------------------------------------------------------
  // Byte buffer: 1 write port + 2 read ports, forced to block RAM.
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [7:0] byte_mem [0:8191];

  wire [12:0] sys_rd_addr, sys_rd2_addr, sys_wr_addr;
  wire [7:0]  sys_wr_data;
  wire        sys_wr_en;

  reg  [12:0] host_addr;
  reg  [7:0]  host_wdata;
  reg         host_we;
  (* MARK_DEBUG = "TRUE" *) reg host_owns;  // host owns memory while idle
  // Latched the instant a KEM op is kicked, cleared only once busy has been
  // OBSERVED HIGH and then falls. Without this, host_owns returned to the
  // host for one cycle between sys_start dropping and sys_busy rising --
  // right as the KEM began reading its inputs -- corrupting every operation
  // after the first. This is the same shape as the level-held-done hazard:
  // an edge assumed to be instantaneous that in RTL takes a cycle to occur.
  reg         op_pending;
  reg         op_started;
  reg  [31:0] cyc_run;      // free-running while busy
  reg  [31:0] cyc_last;     // latched at completion
  reg         busy_d;
  reg  [1:0]  cyc_byte;     // which byte of cyc_last is being returned
  reg  [3:0]  soft_rst_cnt;   // holds the KEM in reset for a few cycles
  wire        kem_rst_n = rst_n & ~(|soft_rst_cnt);

  // MARK_DEBUG on the byte write bus. This is the bus the SHARED SECRET
  // travels on: verify_cmov (Decaps) or the G-output copy (Encaps) writes 32
  // bytes to SS_BASE = 3900. Triggering an ILA on bm_wr_addr == 3900 captures
  // the secret being produced INSIDE the FPGA, with no host involvement in the
  // observation path -- which is the point of showing it this way.
  (* MARK_DEBUG = "TRUE" *) wire [12:0] bm_wr_addr = host_owns ? host_addr  : sys_wr_addr;
  (* MARK_DEBUG = "TRUE" *) wire [7:0]  bm_wr_data = host_owns ? host_wdata : sys_wr_data;
  (* MARK_DEBUG = "TRUE" *) wire        bm_wr_en   = host_owns ? host_we    : sys_wr_en;
  wire [12:0] bm_rd_addr = host_owns ? host_addr : sys_rd_addr;

  reg [7:0] bm_rd_data, bm_rd2_data;
  always @(posedge clk) begin
    if (bm_wr_en) byte_mem[bm_wr_addr] <= bm_wr_data;
    bm_rd_data  <= byte_mem[bm_rd_addr];
    bm_rd2_data <= byte_mem[sys_rd2_addr];
  end

  // ---------------------------------------------------------------------------
  // Seed memory (d)
  // ---------------------------------------------------------------------------
  reg [7:0] seed_mem [0:63];
  wire [5:0] sys_d_addr;
  reg  [7:0] sys_d_data;
  reg  [5:0] seed_wr_addr;
  reg  [7:0] seed_wr_data;
  reg        seed_we;
  always @(posedge clk) begin
    if (seed_we) seed_mem[seed_wr_addr] <= seed_wr_data;
    sys_d_data <= seed_mem[sys_d_addr];
  end

  // ---------------------------------------------------------------------------
  // The KEM
  // ---------------------------------------------------------------------------
  // MARK_DEBUG so these appear in the ILA net list. Every bug found on the
  // bench this week was diagnosed by inference from UART output; an ILA on
  // these would have shown each of them directly.
  (* MARK_DEBUG = "TRUE" *) reg  [1:0] sys_op;
  (* MARK_DEBUG = "TRUE" *) reg        sys_start;
  (* MARK_DEBUG = "TRUE" *) wire sys_busy;
  (* MARK_DEBUG = "TRUE" *) wire sys_done;
  (* MARK_DEBUG = "TRUE" *) wire sys_reject;
  (* MARK_DEBUG = "TRUE" *) wire sys_err;

  mlkem_system #(.K_PARAM(2), .ADDR_W(13)) u_kem (
    .clk(clk), .rst_n(kem_rst_n),
    .op(sys_op), .start(sys_start), .busy(sys_busy), .done(sys_done),
    .d_rd_data(sys_d_data), .d_rd_addr(sys_d_addr),
    .byte_rd_addr(sys_rd_addr),  .byte_rd_data(bm_rd_data),
    .byte_rd2_addr(sys_rd2_addr), .byte_rd2_data(bm_rd2_data),
    .byte_wr_addr(sys_wr_addr), .byte_wr_data(sys_wr_data),
    .byte_wr_en(sys_wr_en),
    .rho_out(), .sample_error(sys_err), .reject(sys_reject), .dbg_state());

  assign busy_led   = sys_busy;
  assign reject_led = sys_reject;

  // ---------------------------------------------------------------------------
  // Command FSM
  // ---------------------------------------------------------------------------
  localparam [7:0] C_PING  = 8'hA5, PING_R = 8'h5A;
  localparam [7:0] C_WR    = 8'h10, C_RD   = 8'h11, C_SEED = 8'h12;
  localparam [7:0] C_KG    = 8'h20, C_EN   = 8'h21, C_DE   = 8'h22;
  localparam [7:0] C_STAT  = 8'h30;
  // Soft reset. The KEM's sub-blocks were only ever reset by the board's
  // power-on/CPU_RESET, so a SECOND operation inherited state from the first
  // -- on the bench this showed up as A_hat not being regenerated, giving a
  // correct first KeyGen and wrong ones after. Rather than hunt every
  // register that needs clearing on start, give the host an explicit way to
  // return the engine to a known state between operations.
  localparam [7:0] C_RST   = 8'h40;
  // Read the cycle count of the LAST completed operation, 4 bytes LSB first.
  // Timing over the UART link measures the link, not the engine: each status
  // poll is a byte each way at 115200 baud, about 174 us round trip, so a
  // handful of polls dominates the ~1.2 ms that was being reported. This
  // counts core clocks between busy rising and falling, which is the real
  // hardware latency.
  localparam [7:0] C_CYCLES = 8'h31;

  localparam ST_CMD    = 4'd0;
  localparam ST_WR_A0  = 4'd1, ST_WR_A1 = 4'd2, ST_WR_D = 4'd3;
  localparam ST_RD_A0  = 4'd4, ST_RD_A1 = 4'd5, ST_RD_W = 4'd6, ST_RD_W2 = 4'd7;
  localparam ST_SD_A   = 4'd8, ST_SD_D  = 4'd9;
  localparam ST_REPLY  = 4'd10, ST_TXW  = 4'd11;
  // Wait for the transmitter to actually START before waiting for it to
  // finish. Checking "!tx_busy && !tx_send" alone returns to ST_CMD in the
  // window before tx_busy has risen, so the reply byte is never sent, the
  // host misses it and the protocol desyncs into a hang. Same edge-assumed-
  // instantaneous hazard as the level-held `done` pattern.
  localparam ST_TXARM  = 4'd12;

  (* MARK_DEBUG = "TRUE" *) reg [3:0] state;
  reg [7:0] pending, tmp_lo;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_CMD; tx_send <= 1'b0; tx_data <= 8'd0;
      pending <= 8'd0; tmp_lo <= 8'd0;
      host_addr <= 13'd0; host_wdata <= 8'd0; host_we <= 1'b0;
      host_owns <= 1'b1; op_pending <= 1'b0; op_started <= 1'b0;
      soft_rst_cnt <= 4'd0;
      cyc_run <= 32'd0; cyc_last <= 32'd0; busy_d <= 1'b0; cyc_byte <= 2'd0;
      seed_wr_addr <= 6'd0; seed_wr_data <= 8'd0; seed_we <= 1'b0;
      sys_op <= 2'd0; sys_start <= 1'b0;
    end else begin
      tx_send <= 1'b0; host_we <= 1'b0; seed_we <= 1'b0; sys_start <= 1'b0;
      if (|soft_rst_cnt) soft_rst_cnt <= soft_rst_cnt - 4'd1;

      // Cycle counter: reset on the rising edge of busy, latch on the falling.
      busy_d <= sys_busy;
      if (sys_busy && !busy_d)      cyc_run  <= 32'd1;   // just started
      else if (sys_busy)            cyc_run  <= cyc_run + 32'd1;
      else if (!sys_busy && busy_d) cyc_last <= cyc_run; // just finished

      // The host owns the byte memory except while an operation is running.
      // op_pending covers the gap between kicking the op and busy actually
      // rising; op_started confirms busy really did rise, so the fall
      // that returns ownership is this operation's real completion, not a
      // one-cycle glitch between sys_start dropping and sys_busy rising.
      if (sys_start) begin
        op_pending <= 1'b1;
        host_owns  <= 1'b0;
      end else if (sys_busy) begin
        op_started <= 1'b1;
        op_pending <= 1'b0;
        host_owns  <= 1'b0;
      end else if (op_pending) begin
        host_owns <= 1'b0;               // start pulsed, busy not up yet
      end else if (op_started) begin
        op_started <= 1'b0;              // busy just fell: op truly done
        host_owns  <= 1'b1;
      end

      case (state)
        ST_CMD: if (rx_valid) begin
          case (rx_data)
            C_WR:   state <= ST_WR_A0;
            C_RD:   state <= ST_RD_A0;
            C_SEED: state <= ST_SD_A;
            C_KG:   begin sys_op<=2'd0; sys_start<=1'b1; host_owns<=1'b0;
                          pending<=C_KG; state<=ST_REPLY; end
            C_EN:   begin sys_op<=2'd1; sys_start<=1'b1; host_owns<=1'b0;
                          pending<=C_EN; state<=ST_REPLY; end
            C_DE:   begin sys_op<=2'd2; sys_start<=1'b1; host_owns<=1'b0;
                          pending<=C_DE; state<=ST_REPLY; end
            C_STAT: begin pending <= {5'd0, sys_reject, sys_done, sys_busy};
                          state <= ST_REPLY; end
            C_CYCLES: begin
              // Return byte cyc_byte of cyc_last, then advance. Four
              // consecutive 0x31 commands read the whole 32-bit count.
              case (cyc_byte)
                2'd0: pending <= cyc_last[7:0];
                2'd1: pending <= cyc_last[15:8];
                2'd2: pending <= cyc_last[23:16];
                default: pending <= cyc_last[31:24];
              endcase
              cyc_byte <= cyc_byte + 2'd1;
              state <= ST_REPLY;
            end
            C_PING: begin pending <= PING_R; state <= ST_REPLY; end
            C_RST:  begin
              // Hold the KEM in reset for 8 cycles. The byte memory and seed
              // memory live in THIS module and are untouched, so staged
              // inputs survive the reset.
              soft_rst_cnt <= 4'd8;
              op_pending <= 1'b0; op_started <= 1'b0; host_owns <= 1'b1;
              pending <= C_RST; state <= ST_REPLY;
            end
            default: state <= ST_CMD;
          endcase
        end

        // ---- write a byte into byte_mem ----
        ST_WR_A0: if (rx_valid) begin tmp_lo <= rx_data; state <= ST_WR_A1; end
        ST_WR_A1: if (rx_valid) begin
          host_addr <= {rx_data[4:0], tmp_lo};
          state <= ST_WR_D;
        end
        ST_WR_D: if (rx_valid) begin
          host_wdata <= rx_data; host_we <= 1'b1;
          pending <= C_WR; state <= ST_REPLY;
        end

        // ---- read a byte back ----
        ST_RD_A0: if (rx_valid) begin tmp_lo <= rx_data; state <= ST_RD_A1; end
        ST_RD_A1: if (rx_valid) begin
          host_addr <= {rx_data[4:0], tmp_lo};
          state <= ST_RD_W;
        end
        // byte_mem is registered: one settle cycle before the data is valid.
        ST_RD_W:  state <= ST_RD_W2;
        ST_RD_W2: begin pending <= bm_rd_data; state <= ST_REPLY; end

        // ---- write the seed ----
        ST_SD_A: if (rx_valid) begin seed_wr_addr <= rx_data[5:0]; state <= ST_SD_D; end
        ST_SD_D: if (rx_valid) begin
          seed_wr_data <= rx_data; seed_we <= 1'b1;
          pending <= C_SEED; state <= ST_REPLY;
        end

        ST_REPLY: if (!tx_busy && !tx_send) begin
          tx_data <= pending; tx_send <= 1'b1; state <= ST_TXARM;
        end
        ST_TXARM: if (tx_busy) state <= ST_TXW;   // transmitter has started
        ST_TXW:   if (!tx_busy) state <= ST_CMD;  // ...and has finished

        default: state <= ST_CMD;
      endcase
    end
  end
endmodule : mlkem_uart_core
