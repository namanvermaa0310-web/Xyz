`timescale 1ns/1ps
// KeyGen against an OFFICIAL NIST ACVP vector, checking the FULL 800-byte ek
// including the 32-byte rho tail that the board was leaving as zeros.
module tb_nist_kg;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start; wire busy,done,serr,reject;
  wire [5:0] d_ra; reg [7:0] d_rd;
  wire [12:0] br_a,br2_a,bw_a; wire [7:0] bw_d; wire bw_en; reg [7:0] br_d,br2_d;
  wire [255:0] rho_out; wire [4:0] dbg;

  mlkem_system #(.K_PARAM(2),.ADDR_W(13)) dut(.clk(clk),.rst_n(rst_n),.op(op),
    .start(start),.busy(busy),.done(done),.d_rd_data(d_rd),.d_rd_addr(d_ra),
    .byte_rd_addr(br_a),.byte_rd_data(br_d),
    .byte_rd2_addr(br2_a),.byte_rd2_data(br2_d),
    .byte_wr_addr(bw_a),.byte_wr_data(bw_d),.byte_wr_en(bw_en),
    .rho_out(rho_out),.sample_error(serr),.reject(reject),.dbg_state(dbg));

  reg [7:0] bmem[0:8191], dmem[0:63];
  always @(posedge clk) begin
    br_d<=bmem[br_a]; br2_d<=bmem[br2_a]; d_rd<=dmem[d_ra];
    if(bw_en) bmem[bw_a]<=bw_d;
  end

  localparam EK=2048, DKB=1024, HEK=2900, ZB=3100;
  reg [7:0] g_ek[0:799], g_dk[0:1631], g_z[0:31];
  integer errors=0, i;

  initial begin
    $readmemh("nv_d.hex",  dmem);
    $readmemh("nv_ek.hex", g_ek);
    $readmemh("nv_dk.hex", g_dk);
    $readmemh("nv_z.hex",  g_z);
    for(i=0;i<8192;i=i+1) bmem[i]=8'h00;
    for(i=0;i<32;i=i+1)   bmem[ZB+i]=g_z[i];

    $display("=== NIST ACVP keyGen vector, full 800-byte ek check ===");
    rst_n=0; start=0; op=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);
    @(negedge clk); op=2'd0; start=1'b1;
    @(negedge clk); start=1'b0;
    while(!busy) @(negedge clk);
    while(busy)  @(negedge clk);
    repeat(4)@(posedge clk);

    for(i=0;i<768;i=i+1)
      if (bmem[EK+i]!==g_ek[i]) begin
        if(errors<4) $display("[TB] FAIL ek[%0d] got %02h want %02h",i,bmem[EK+i],g_ek[i]);
        errors=errors+1;
      end
    if(errors==0) $display("[TB] ek[0:768]  (encoded t_hat): 768/768 match NIST");

    begin : tail
      integer terr; terr=0;
      for(i=768;i<800;i=i+1)
        if (bmem[EK+i]!==g_ek[i]) begin
          if(terr<4) $display("[TB] FAIL ek[%0d] (rho tail) got %02h want %02h",
                              i,bmem[EK+i],g_ek[i]);
          terr=terr+1;
        end
      errors=errors+terr;
      if(terr==0) $display("[TB] ek[768:800] (rho tail):     32/32  match NIST");
    end

    // dk = dk_pke || ek || H(ek) || z
    begin : dkchk
      integer derr; derr=0;
      for(i=0;i<768;i=i+1)
        if (bmem[DKB+i]!==g_dk[i]) derr=derr+1;
      for(i=0;i<32;i=i+1)
        if (bmem[HEK+i]!==g_dk[1568+i]) derr=derr+1;
      errors=errors+derr;
      if(derr==0) $display("[TB] dk_pke and H(ek):           match NIST");
      else $display("[TB] FAIL dk: %0d byte(s) wrong", derr);
    end

    $display("============================================================");
    if(errors==0)
      $display("  PASS -- board-path KeyGen reproduces the NIST vector exactly");
    else
      $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #400_000_000; $display("TIMEOUT st=%0d",dbg); $finish; end
endmodule
