# ML-KEM-512 Hardware Accelerator — Complete Technical Reference

**Target:** Xilinx Kintex-7 `xc7k325tffg900-2` (KC705 evaluation board)
**Standard:** NIST FIPS 203, ML-KEM-512 (Category 1)
**Clock:** 100 MHz (10 ns period)
**Toolchain:** Vivado 2019.2 (synthesis/implementation), Icarus Verilog (simulation)

---

## 1. What this design is, and what it is not

**It is** a hardware implementation of the three ML-KEM-512 algorithms:

| Algorithm | FIPS 203 | Function |
|---|---|---|
| `ML-KEM.KeyGen_internal(d,z)` | Alg 16 | produce a keypair |
| `ML-KEM.Encaps_internal(ek,m)` | Alg 17 | produce (shared secret, ciphertext) |
| `ML-KEM.Decaps_internal(dk,c)` | Alg 18 | recover the shared secret |

**It is not:**

* **An encryption engine.** ML-KEM is a *Key Encapsulation Mechanism*: it agrees a
  32-byte secret. Bulk data encryption is AES-GCM keyed by that secret. ML-KEM
  replaces the ECDH half of a TLS handshake, not AES.
* **A random number generator.** FIPS 203 splits each operation into a
  deterministic `_internal` function plus a wrapper that draws randomness. This
  implements the deterministic internal functions; `d`, `z` and `m` are supplied
  by the caller. That is the standard boundary for a crypto core, and it is
  precisely what makes ACVP conformance testing possible — if the device chose
  its own `d`, no published test vector could ever match.
* **CAVP-certified.** It passes NIST's *published* ACVP vectors, which is
  conformance evidence. A certificate requires submission through an accredited
  laboratory.

---

## 2. Parameter set

ML-KEM-512 (`K_PARAM = 2`). All parameters are RTL `parameter`s, so the design
is re-targetable to ML-KEM-768/1024 by changing them and regenerating vectors.

| Symbol | Value | Meaning |
|---|---|---|
| `n` | 256 | coefficients per polynomial |
| `q` | 3329 | prime modulus |
| `k` | 2 | polynomials per vector; matrix is k x k |
| `eta1` | 3 | CBD parameter for the secret `s` and the Encaps randomness `y` |
| `eta2` | 2 | CBD parameter for the error terms `e`, `e1`, `e2` |
| `du` | 10 | compression bits for ciphertext component `u` |
| `dv` | 4 | compression bits for ciphertext component `v` |

Two easy mistakes worth noting, both of which this design gets right and both of
which are asserted in the testbenches:

* **`eta1 = 3` for ML-KEM-512 only.** ML-KEM-768 and 1024 use `eta1 = 2`. The
  512 parameter set is the exception.
* **Within Encaps, `y` uses `eta1` but `e1`/`e2` use `eta2`.** Using one value
  throughout produces a self-consistent but non-conformant scheme.

---

## 3. Field sizes — every byte accounted for

### 3.1 Derivation

A polynomial is 256 coefficients mod 3329, so 12 bits each:

```
256 coefficients x 12 bits = 3072 bits = 384 bytes per polynomial
```

Everything else follows from that.

### 3.2 Complete table

| Field | Size | Composition |
|---|---|---|
| **Shared secret K** | **32 B** | 256 bits, first half of a SHA3-512 digest |
| Seed `d` | 32 B | KeyGen randomness (matrix + secret) |
| Seed `z` | 32 B | KeyGen rejection secret |
| Message `m` | 32 B | Encaps randomness |
| `rho` | 32 B | matrix seed, from G |
| `sigma` | 32 B | noise seed, from G |
| Coins `r` | 32 B | Encaps PRF key, from G |
| **Public key `ek`** | **800 B** | `ByteEncode12(t_hat)` 768 B + `rho` 32 B |
| **Ciphertext `c`** | **768 B** | `c1` 640 B + `c2` 128 B |
| — `c1` (compressed u) | 640 B | k x 256 x du/8 = 2 x 320 |
| — `c2` (compressed v) | 128 B | 256 x dv/8 |
| **Secret key `dk`** | **1632 B** | see below |
| — `dk_pke` | 768 B | `ByteEncode12(s_hat)`, k x 384 |
| — `ek` (embedded) | 800 B | needed for the FO re-encryption |
| — `H(ek)` | 32 B | precomputed, avoids re-hashing on every Decaps |
| — `z` | 32 B | implicit-rejection secret |

**Why `dk` embeds `ek` and `H(ek)`:** Decaps must re-encrypt and compare, so it
needs the public key; caching `H(ek)` saves an 800-byte SHA3-256 per
decapsulation.

**Why `c` is smaller than 2 x 384 + 384:** compression. `u` is stored at 10 bits
per coefficient instead of 12 and `v` at 4. That lossy compression is safe
because the decryption error tolerance absorbs it — and it is precisely why
Decaps can survive small perturbations, which the FO transform then catches.

### 3.3 Bandwidth in the exchange

```
Alice --------- ek (800 B) ---------> Bob
Alice <-------- c  (768 B) ---------- Bob
```
1568 bytes total. Neither secret is ever transmitted.

---

## 4. Memory organisation

Two distinct memories. Confusing them is the most common source of questions,
so the split is worth stating plainly:

* **Polynomial slot memory** — coefficients, 16 bits wide, inside `kpke_top`
* **Byte buffer** — keys/ciphertexts as bytes, 8 bits wide, inside
  `mlkem_uart_core`

### 4.1 Polynomial slot memory (`poly_slots.sv`)

```
24 slots x 256 coefficients x 16 bits = 98,304 bits = 96 Kbit = 12 KB
Address = {slot[4:0], coeff[7:0]}  -> 13 bits
```

One write port, **two** read ports. The second read port exists because
`matvec_mul` must read a matrix coefficient and a vector coefficient in the same
cycle. `(* ram_style = "block" *)` is forced — without it Vivado left arrays this
size in flip-flops, which is what caused the Phase 2 synthesis failure.

Coefficients are stored in **16 bits** although only 12 are significant. Padding
to a power of two costs 4 bits per coefficient (25% of this memory) and buys
trivially simple addressing. At 96 Kbit against 445 available BRAM tiles, that is
not a meaningful cost.

| Slot | Contents | KeyGen | Encaps | Decaps |
|---|---|---|---|---|
| 0–3 | `A_hat[i][j]`, index `i*k+j` | matrix | matrix | — |
| 8–9 | `s[i]` / `y[i]` | secret | randomness | — |
| 10–11 | `e[i]` / `e1[i]` | error | error | — |
| 12–13 | `s_hat[i]` / `y_hat[i]` | NTT(secret) | NTT(y) | NTT(u) |
| 14–15 | `e_hat[i]` | NTT(error) | — | — |
| 16–17 | `t_hat[i]` | public poly | decoded from ek | `s_hat` from dk |
| 18–19 | `u[i]` | — | ciphertext u | decompressed u |
| 20 | `v` | — | ciphertext v | decompressed v |
| 21 | `e2` | — | error | — |
| 22 | `w` | — | — | `v - s.u` |
| 23 | `acc` | matvec accumulator | matvec accumulator | matvec accumulator |

Slots are **reused across operations** — slot 12 holds `s_hat` in KeyGen,
`y_hat` in Encaps, and `u_hat` in Decaps. Decaps puts `s_hat` in slots 16–17
because `t_hat` is unused there.

### 4.2 Byte buffer (`mlkem_uart_core.sv`)

```
8192 x 8 bits = 8 KB, 13-bit address
```

Also two read ports — `verify_cmov` compares the received and re-encrypted
ciphertexts byte-by-byte in the same cycle.

| Offset | Size | Field | Written by |
|---|---|---|---|
| 0 | 768 | ciphertext `c` | host (Decaps) / Encaps |
| 1024 | 768 | `dk_pke` | KeyGen |
| 1868 | 32 | `m` / `m'` | host (Encaps) / Decaps |
| 1900 | 32 | coins `r` | copied from G output |
| 2048 | 800 | `ek` | KeyGen (768 encoded + 32 rho) |
| 2900 | 32 | `H(ek)` | KeyGen / Encaps |
| 2932 | 64 | G output = `K ‖ r` | Encaps / Decaps |
| 3000 | 32 | `Kbar = J(z‖c)` | Decaps |
| 3100 | 832 | `z` then `c` — J hashes `z‖c` contiguously | host + Decaps |
| **3900** | **32** | **shared secret K** | Encaps / verify_cmov |
| 3950 | 768 | saved copy of received `c` | Decaps |
| 4750 | 64 | staged `m ‖ H(ek)` for G | Encaps / Decaps |

Three of these placements are deliberate and were each the result of a bug:

* **`z` at 3100 with `c` immediately after** — `J(z‖c)` hashes an 832-byte
  contiguous string, so the two must be adjacent in memory.
* **`GIN_BASE` at 4750** — `G(m‖H(ek))` likewise needs its two 32-byte halves
  contiguous. `m` lives at 1868 and `H(ek)` at 2900, so both are *copied* here
  first. An earlier map assumed adjacency and hashed `m‖coins`.
* **`CSAVE_BASE` at 3950** — Decaps re-encrypts into `CT_BASE`, overwriting the
  very ciphertext it must compare against. The received copy is saved first.

**Field overlap is the hazard to watch.** An earlier map put `ek` at 1792, whose
800-byte span swallowed `m` at 1868 — `m` silently overwrote `ek[76..107]` and
`H(ek)` hashed a corrupted key while every upstream value still looked correct.
Moving `ek` to 2048 fixed it. Anyone modifying the map must re-check every span.

### 4.3 Other storage

| Memory | Size | Purpose |
|---|---|---|
| Seed memory | 64 x 8 | the 32-byte `d` |
| `ntt_engine.coeff_mem` | 256 x 16 | NTT working buffer (internal) |
| `matvec_mul.prod_mem` | 256 x 16 | one column product |
| `matvec_mul.acc_mem` | 256 x 16 | running accumulator |
| Keccak message buffers | up to 832 B each | absorb buffers |
| `twiddle_rom` | 128 x 16 | zeta table |
| `poly_basemul` zeta ROM | 64 x 16 | inline case statement |

**Measured total: 11.5 BRAM tiles of 445 (2.6%).**

---

## 5. The NTT — the mathematical core

### 5.1 Why an NTT at all

Polynomial multiplication in `Z_q[X]/(X^256+1)` is `O(n^2)` = 65,536
coefficient multiplies done naively. In the NTT domain it becomes pointwise, so:

```
a * b  =  INTT( NTT(a) o NTT(b) )
```

Better still, keys are *stored* in the NTT domain (`t_hat`, `s_hat`), so the
transform is often already paid for.

### 5.2 The structural fact that shapes everything

For q = 3329, `X^256+1` factors into **128 quadratic** factors, not 256 linear
ones — because 3329 has 256th roots of unity but no primitive 512th root.

Consequences, all visible in the RTL:

* The NTT runs **7 stages**, not 8.
* The pointwise product is **not** scalar multiplication — it is 128 independent
  degree-1 polynomial multiplications mod `X^2 - zeta`. That is `basemul`.
* The inverse scaling factor is **128^-1 mod q = 3303**, not `256^-1 = 3316`.

That last point is a genuine trap. `N_INV = 3303` in `mlkem_pkg.sv` is correct
and is independently corroborated by kyber-py.

### 5.3 Parameters

| Parameter | Value | Note |
|---|---|---|
| Primitive 256th root `zeta` | 17 | |
| Stages | 7 | 128 quadratic factors |
| Butterflies per stage | 128 | |
| Total butterflies | 896 | 7 x 128 |
| Twiddle table | 128 x 16 bits | bit-reversed order |
| `N_INV` | 3303 | 128^-1 mod 3329 |

The 128 twiddle constants in `twiddle_rom.sv` match the FIPS 203 Appendix A
table exactly, and also match the Kyber C reference after undoing its Montgomery
encoding (it stores `zeta * 2^16 mod q`).

### 5.4 Barrett reduction

Reduction mod 3329 without a divider:

```
t   = (x * 20159) >> 26          // quotient estimate
r   = x - t*3329                 // remainder
if (r < 0)    r += 3329          // correction
if (r >= 3329) r -= 3329
```

`20159 = floor((2^26 + q/2)/q)`. Identical to the C reference's constant and
shift. **Proven exact by exhaustive test over all 11,075,585 possible products** —
not sampled, every value.

A second divider-free identity is used in compression:

```
floor(n/3329) == (n * 2580335) >> 33
```
verified exhaustively over all n up to 3,409,536, the largest numerator any
`compress` call produces. Without it Vivado would infer a full divider.

### 5.5 Why the butterfly takes 6 cycles

The original single-cycle butterfly chained three multipliers combinationally
(`zeta*b`, `*20159`, `*3329`) and gave **WNS = -17.638 ns with 1391 failing
endpoints**. Splitting the normalisation out reached -5.13 ns — still failing.

The design now allows **at most one multiplier per pipeline stage**:

| State | Operation |
|---|---|
| `ST_READ` | fetch both coefficients |
| `ST_MUL` | multiply by zeta |
| `ST_R1` | Barrett estimate (x 20159) |
| `ST_R2` | Barrett correction (x 3329) |
| `ST_BFLY` | add/subtract |
| `ST_WRITE` | store |

Plus `ST_NM`/`ST_NR1`/`ST_NR2` for the `N_INV` scaling on the final INTT stage.

```
896 butterflies x 6 cycles = 5,376 cycles per transform = 53.8 us
```

**This is a deliberate latency-for-timing trade.** It is also the single largest
optimisation opportunity — butterflies within a stage are independent, so
overlapping them approaches 1 cycle each with no extra multipliers.

---

## 6. Hash functions

All four are the same Keccak-f[1600] permutation with different rate and domain
separation.

| Function | Primitive | Rate | Domain | Output | Used for |
|---|---|---|---|---|---|
| H | SHA3-256 | 136 B | 0x06 | 32 B | `H(ek)` |
| G | SHA3-512 | 72 B | 0x06 | 64 B | `(rho,sigma)=G(d‖k)`, `(K,r)=G(m‖H(ek))` |
| XOF | SHAKE-128 | 168 B | 0x1F | 672 B | matrix expansion |
| PRF | SHAKE-256 | 136 B | 0x1F | 128/192 B | noise sampling |
| J | SHAKE-256 | 136 B | 0x1F | 32 B | `Kbar = J(z‖c)` |

Keccak-f[1600] is **one shared 24-round permutation instance**, 24 cycles per
call, not unrolled.

**Sizing trap:** `H(ek)` and `J(z‖c)` are both 800+ bytes. The FO-layer cores are
instantiated at `MAX_MSG = 832`. The 512-byte default would silently truncate and
produce plausible-but-wrong keys.

**Rate 72 for SHA3-512** is unusual and easy to get wrong — it comes from
`(1600 - 2*512)/8`.

### 6.1 The synthesis lesson

The rate block was originally read with a generate loop of 136 concurrent
continuous assignments. Vivado cannot map that port count to BRAM, so it built
~4096 flip-flops plus enormous address muxes per module — **synthesis ran 1.5
hours without finishing.** The pattern had been adopted to work around an Icarus
`always @(*)` quirk: a simulator workaround that broke synthesis.

Fixed with a sequential block load (one byte per two cycles) giving single-port
memories. That fix costs throughput and is why hashing is 6.6% of KeyGen.

---

## 7. Module hierarchy

```
kc705_mlkem_top          IBUFDS + MMCM + reset sync   [board-specific]
└── mlkem_uart_core      UART bridge, 8 KB byte buffer, seed memory, cycle counter
    └── mlkem_system     FO layer (Algs 16/17/18), byte map, arbitration
        ├── kpke_system
        │   ├── kpke_engine     sequencer for Algs 13/14/15
        │   └── kpke_top
        │       ├── poly_slots       24 x 256 x 16
        │       ├── kpke_datapath    NTT, matvec, add/sub, codecs
        │       │   ├── ntt_engine
        │       │   └── matvec_mul -> poly_basemul -> basemul
        │       └── kpke_seed_unit   G, XOF+SampleNTT, PRF+CBD
        │           ├── sha3_512, shake128, shake256
        │           ├── sample_ntt
        │           └── cbd_sampler (eta2), cbd_sampler_eta3
        ├── mlkem_hash_unit    H, G, J at MAX_MSG=832
        └── verify_cmov        constant-time compare + select
```

**The service interface.** `kpke_engine` never touches memory directly. It issues
calls on a bus:

```
unit_sel[2:0]   which unit (HASH/XOF/PRF/NTT/MATVEC/POLY/CODEC)
unit_op[2:0]    operation within that unit
unit_a0..a2     arguments: indices, eta, source/destination slot
unit_start      one-cycle kick
unit_done       completion
byte_base       where byte-oriented ops read/write
```

This is why the same units serve all three algorithms without duplication, and
why control correctness could be verified separately from arithmetic.

Service-call counts: **KeyGen 21, Encrypt 28, Decrypt 11.**

---

## 8. Data flow

### 8.1 KeyGen (Algorithm 16)

```
d, z (host)
  │
  ├─ G(d ‖ k) ────────────► rho (32B), sigma (32B)
  │                          note: the k byte is FIPS 203; round-3 omits it
  │
  ├─ for i,j in 0..1:  A_hat[i][j] = SampleNTT(SHAKE128(rho ‖ j ‖ i))
  │      ► slots 0-3      (argument order is j,i — inverted vs the index)
  │
  ├─ for i: s[i] = CBD3(SHAKE256(sigma ‖ N++))   ► slots 8-9
  ├─ for i: e[i] = CBD3(SHAKE256(sigma ‖ N++))   ► slots 10-11
  │
  ├─ NTT: s ► 12-13,  e ► 14-15
  │
  ├─ for i: t_hat[i] = sum_j A_hat[i][j] o s_hat[j] + e_hat[i]  ► 16-17
  │
  ├─ ByteEncode12(t_hat) ► ek[0:768]
  ├─ rho                 ► ek[768:800]
  ├─ ByteEncode12(s_hat) ► dk_pke
  └─ H(ek)               ► HEK_BASE
```

**Cost: 68,526 cycles = 685 us.**

### 8.2 Encaps (Algorithm 17)

```
ek, m (host)
  │
  ├─ H(ek) ► HEK_BASE
  ├─ copy m ‖ H(ek) ► GIN_BASE          (must be contiguous for G)
  ├─ G(m ‖ H(ek)) ► K (32B) ‖ r (32B)
  ├─ K ► SS_BASE            r ► COINS_BASE
  │
  ├─ K-PKE.Encrypt(ek, m, r):
  │     LOAD_RHO   from ek[768:800]     (not from G — Encaps has no d)
  │     LOAD_PRFKEY from coins r        (not sigma)
  │     ByteDecode12(ek) ► t_hat (x k)
  │     regenerate A_hat
  │     y  = CBD3(PRF(r,0..1))          eta1
  │     e1 = CBD2(PRF(r,2..3))          eta2
  │     e2 = CBD2(PRF(r,4))             eta2
  │     u = INTT(A_hat^T o y_hat) + e1
  │     v = INTT(t_hat^T o y_hat) + e2 + Decompress1(m)
  │     c = Compress_du(u) ‖ Compress_dv(v)
  └─ outputs: K at SS_BASE, c at CT_BASE
```

Note `A_hat^T` — the **transpose**. Implemented purely by address rebasing
(base steps by 1 instead of k), so `matvec_mul` itself is unchanged.

### 8.3 Decaps (Algorithm 18)

```
dk, c (host)
  │
  ├─ save received c ► CSAVE_BASE       (re-encryption will overwrite CT_BASE)
  │
  ├─ K-PKE.Decrypt(dk_pke, c):
  │     ByteDecode12(dk_pke) ► s_hat ► slots 16-17
  │     u = Decompress_du(c1), v = Decompress_dv(c2)
  │     w = v - INTT(s_hat^T o NTT(u))
  │     m' = Compress1(w)                ► MSG_BASE
  │
  ├─ G(m' ‖ h) ► K' ‖ r'
  ├─ Kbar = J(z ‖ c)
  ├─ K-PKE.Encrypt(ek, m', r') ► c'      ◄── THE FO RE-ENCRYPTION
  │
  └─ verify_cmov: K = (c' == c_saved) ? K' : Kbar
```

**Cost: ~127,100 cycles = 1,271 us** — roughly 2x KeyGen, because the K-PKE work
is done twice (decrypt then re-encrypt) plus the 768-byte compare.

### 8.4 Why the re-encryption exists

Without it the scheme is only CPA-secure: an attacker submitting modified
ciphertexts and observing results can recover the secret key. The Fujisaki–Okamoto
transform re-derives what the ciphertext *should* have been and compares.

Crucially the failure path returns `Kbar = J(z‖c)` — a **deterministic** value
derived from the secret `z`. Not an error code, not a random value:

* an error code tells the attacker the ciphertext was invalid
* a random value is detectable by repeating the query

`Kbar` looks like a perfectly normal shared secret, is the same every time for a
given `c`, and is unpredictable without `z`. The attacker learns nothing.

`verify_cmov` is constant-time by construction: it OR-accumulates all 768 XOR
differences with **no early exit**, then selects with a mux evaluated every
cycle. Measured: **2401 cycles on both accept and reject.**

---

## 9. Interface and protocol

### 9.1 Board pins

Six, all cross-checked against the KC705 master XDC (UG810 Appendix C).

| Signal | Pin | Standard | Note |
|---|---|---|---|
| `sysclk_p/n` | AD12 / AD11 | LVDS | 200 MHz differential |
| `cpu_reset` | AB7 | LVCMOS15 | active high |
| `uart_rx` | M19 | LVCMOS25 | into FPGA |
| `uart_tx` | K24 | LVCMOS25 | out of FPGA |
| `led_busy` | AB8 | LVCMOS15 | |
| `led_reject` | AA8 | LVCMOS15 | FO verdict |

**Gotcha 1:** bank 33 is 1.5 V. UG810 says LVDS for the clock; some Vivado
versions demand `DIFF_SSTL15` (Xilinx AR 45934). Both are in the XDC, one
commented.

**Gotcha 2:** the USB-UART is a **Silicon Labs CP2103** needing the CP210x VCP
driver, on the mini-B connector. It is *not* the FTDI "USB Serial Converter A/B"
— those are JTAG.

### 9.2 Clocking

```
200 MHz differential  ──IBUFDS──►  MMCME2_BASE  ──►  100 MHz core clock
                                   M=5, D=1, VCO=1000 MHz, CLKOUT0_DIVIDE=10
```
Reset asserts asynchronously, releases synchronously, and is held until the MMCM
locks so nothing runs on an unstable clock.

### 9.3 UART protocol

115200 baud 8N1, `CLKS_PER_BIT = 868` (100 MHz / 115200).

| Cmd | Payload | Reply | Function |
|---|---|---|---|
| `0xA5` | — | `0x5A` | ping |
| `0x10` | addr_lo, addr_hi, data | `0x10` | write byte buffer |
| `0x11` | addr_lo, addr_hi | data | read byte buffer |
| `0x12` | addr, data | `0x12` | write seed memory |
| `0x20` | — | `0x20` | run KeyGen |
| `0x21` | — | `0x21` | run Encaps |
| `0x22` | — | `0x22` | run Decaps |
| `0x30` | — | status | `{5'b0, reject, done, busy}` |
| `0x31` | — | byte | cycle count of last op, 4 reads LSB first |
| `0x40` | — | `0x40` | soft reset (memories preserved) |

Addresses are 13-bit little-endian. Typical sequence: stage inputs with `0x10`,
kick with `0x20/21/22`, poll `0x30` until busy clears, read results with `0x11`.

---

## 10. Performance

### 10.1 Measured

| Operation | Cycles | Time @ 100 MHz |
|---|---|---|
| KeyGen | 68,526 | 685 us |
| Decaps | ~127,100 | 1,271 us |
| Full NTT | 5,376 | 53.8 us |
| Keccak-f[1600] | 24 | 0.24 us |
| basemul | ~20 | 0.2 us |
| verify_cmov | 2,401 | 24 us (identical either verdict) |

Run-to-run spread on KeyGen is 68,429–68,591 — deterministic, as expected.

**Measure with the cycle counter, not a stopwatch over the link.** Each status
poll is a byte each way at 115200 baud, ~174 us round trip; that is why timing
over the serial link reported ~1.2 ms for a 685 us operation.

### 10.2 KeyGen breakdown

| Unit | Cycles | Share |
|---|---|---|
| NTT engine | 21,504 | 31.4% |
| matvec | 18,966 | 27.7% |
| XOF + SampleNTT | 8,934 | 13.0% |
| PRF + CBD | 6,968 | 10.2% |
| G / H hashes | 4,489 | 6.6% |
| overhead | 7,665 | 11.2% |

### 10.3 Honest comparison

Optimised AVX2 software does ML-KEM-512 KeyGen in roughly 20–40 us. **This design
is around 20x slower than a CPU.** It is optimised for correctness, area and
timing closure — not throughput. Two documented improvements (basemul pipelining,
NTT butterfly overlap) would give about 2.1x, reaching ~320 us. Published
high-performance FPGA designs reach 10–50 us using parallel DSP arrays, which is
a different area/speed point.

### 10.4 Resources

| Resource | Used | Available | % |
|---|---|---|---|
| LUT | 68,749 | 203,800 | 34% |
| FF | 52,118 | 407,600 | 13% |
| BRAM | 11.5 | 445 | 2.6% |
| DSP | 17 | 840 | 2% |
| Power | 3.177 W | | |

**Timing: WNS +0.233 ns, TNS 0.000, 0 failing endpoints of 56,684; hold WHS
+0.051 ns.** That is only 2.3% of the 10 ns period — real, but thin. If more
margin is needed: DSP input/output pipelining (Vivado already advises this via
DPIP-1/DPOP-2), or drop to 83 MHz.

The low DSP and BRAM figures reflect the single-multiplier, single-Keccak
architecture — the same choice that makes it slow makes it small.

---

## 11. Verification

### 11.1 Evidence chain, strongest first

**1. Official NIST ACVP vectors** (usnistgov/ACVP-Server, FIPS203 revision).
NIST publishes inputs and expected outputs. The board receives **only the
inputs**, computes in hardware, and returns its answer — it is never told the
correct result.

| | On hardware | Against the model |
|---|---|---|
| keyGen | 25/25 | 25/25 |
| decapsulation | 10/10 | 10/10 |
| encapsulation | — (needs caller-staged `m`) | 25/25 |

**2. Third-party cross-check.** The reference model matches **kyber-py 1.2.0**
byte-for-byte on ek, dk, ciphertext, shared secret and the implicit-rejection
path.

**3. Component-level independent checks:**
* 128 twiddle constants match the FIPS 203 Appendix A table *and* the Kyber C
  reference after de-Montgomery
* Barrett reduction proven exact over all 11,075,585 possible products
* Compress/Decompress, ByteEncode/Decode, CBD3 match the C reference
* SHA3/SHAKE against FIPS 202 vectors including multi-block absorb and squeeze

**4. Simulation regression** — 6 suites in `mlkem512_complete.zip`, including
full KeyGen→Encaps→Decaps with shared-secret agreement and implicit rejection.

### 11.2 Correct wording

> "Passes the published NIST ACVP vectors for ML-KEM-512."

That is conformance evidence. It is **not** a CAVP certificate, which requires
submission through an accredited laboratory. Anyone in a defence review will know
the difference, so state it precisely.

---

## 12. Design decisions worth being able to defend

**Barrett, not Montgomery.** The C reference uses Montgomery (storing
`zeta*2^16 mod q`). Barrett was chosen for consistency across all phases and
verified equivalent — output is byte-identical.

**FIPS 203, not round-3 Kyber.** Two differences that change every output byte:
* seeds: FIPS 203 `G(d‖k)` with the parameter byte; round-3 `G(d)`
* round-3 ends Encaps/Decaps with `KDF(ss, H(c))`; **FIPS 203 removed it** — the
  shared secret is K straight out of G

Implementing the round-3 form gives a self-consistent KEM that matches no ACVP
vector and interoperates with nothing.

**One multiplier per pipeline stage.** Bought timing closure at 6 cycles per
butterfly. Deliberate, documented, and the main optimisation target.

**Sequential Keccak block load.** Cost throughput, but the parallel version could
not be synthesised at all.

**16-bit coefficient storage.** 4 wasted bits per coefficient for far simpler
addressing. Immaterial at 2.6% BRAM.

---

## 13. Bugs found, and what they teach

### 13.1 Level-held `done` — seven occurrences

The most recurrent defect in the project. A module asserts `done` and leaves it
high; a caller polls it, sees the **previous** operation's completion, skips the
current one, and produces plausible-but-wrong data rather than an obvious hang.

Occurrences: sha3_512 testbench, poly_basemul, ntt_engine, matvec_mul,
kpke_system, mlkem_system integration, and verify_cmov (whose `busy` output had
simply been left unconnected).

**Rule adopted: never poll `done`. Always gate on `busy` rising then falling.**

### 13.2 Three bugs simulation structurally could not catch

Found only on hardware — the concrete justification for board bring-up:

1. **`rho` never written into `ek`'s tail.** KeyGen produced 768 correct bytes
   then 32 stale ones. Simulation missed it because the testbench *preloaded*
   `ek` — the RTL was never asked to assemble it. The board diagnosed it exactly:
   `ek differs first at byte 768`.

2. **Stale `use_eta3` in the write mux.** The seed unit selected between
   SampleNTT and the CBD samplers using a flag only assigned on PRF calls.
   KeyGen ends with CBD3, leaving it set, so the *next* KeyGen's SampleNTT writes
   were misrouted and `A_hat` was never regenerated — first KeyGen after reset
   correct, all later ones wrong. No testbench had run two KeyGens back to back.

3. **UART reply race.** `tx_send` is a registered pulse; in the window after it
   drops but before `tx_busy` rises, both are low and the FSM returned to idle
   without transmitting — desyncing the host into an intermittent hang.

The general lesson: **each was invisible because no testbench exercised the
pattern the board did.** Preloading inputs, running one operation, and simulating
without real baud timing all hid real defects.

### 13.3 Read-latency discipline

Three different conventions coexist and mixing them shifted whole polynomials:

| Source | Latency |
|---|---|
| `poly_slots`, byte memory | **registered** — one settle cycle |
| `ntt_engine.rd_data` | continuous assign — no offset |
| `matvec_mul.acc_rd_data` | continuous assign — no offset |

---

## 14. Limitations — state these before being asked

* **ML-KEM-512.** TLS deployments use hybrid X25519MLKEM768. Moving to 768 is a
  re-parameterisation (k=3, eta1=2) plus new vectors, not a rewrite — but it also
  needs X25519 alongside.
* **Conformance-tested, not CAVP-certified.**
* **~685 us, unoptimised** — slower than software; ~2.1x documented and available.
* **No TRNG.** Randomness is caller-supplied. Deployment needs an SP 800-90B
  entropy source and SP 800-90A DRBG — a separate certification track.
* **Side channels unexamined** beyond `verify_cmov`'s constant-time compare. No
  DPA analysis, no masking.
* **Timing margin 2.3%.** Closed, but thin.
* **Bespoke UART interface**, not AXI. Not IP-packaged.

---

## 15. Quick answers

**Shared secret size?** 32 bytes, always — same for all ML-KEM parameter sets.

**Where is it stored?** Byte buffer offset 3900.

**Why is `dk` 1632 bytes?** 768 (`s_hat`) + 800 (`ek`) + 32 (`H(ek)`) + 32 (`z`).
It embeds the public key because Decaps must re-encrypt.

**Why 7 NTT stages, not 8?** `X^256+1` factors into 128 quadratics over
`Z_3329`, not 256 linears — so the transform stops one level early and the
pointwise step is `basemul`, not scalar multiply.

**Why `N_INV = 3303`?** It is `128^-1 mod 3329`, matching the 7 stages.
`256^-1 = 3316` would be wrong.

**Can it encrypt a packet?** No, and it is not meant to. It agrees a 32-byte key;
AES-GCM encrypts the data.

**Does the board know the expected answer during testing?** No. Only NIST's
inputs are sent. The comparison happens on the PC.

**What crosses the link in a key exchange?** `ek` (800 B) and `c` (768 B).
Neither secret is ever transmitted.

**What happens on a corrupted ciphertext?** Decaps returns `J(z‖c)` — a
deterministic value that looks like a normal secret and is unpredictable without
`z`. The attacker cannot distinguish it from success.

**Is it constant-time?** `verify_cmov` is, by construction and by measurement
(2401 cycles either verdict). The rest has not been analysed.
