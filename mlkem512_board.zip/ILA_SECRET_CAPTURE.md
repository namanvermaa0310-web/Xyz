# Showing the shared secret on an ILA waveform

Captures the 32-byte shared secret being written **inside the FPGA**, with the
PC nowhere in the observation path. Answers the "you are just sending it from
Python" objection directly.

## Why this works

Whatever produces the secret — `verify_cmov` in Decaps, or the G-output copy in
Encaps — writes 32 bytes to `SS_BASE = 3900` on the byte-write bus. Trigger on
that address and the capture IS the secret.

Confirmed in simulation: exactly 32 writes, addresses 3900..3931, first bytes
`14 ca ce 3e 48 77 1b 31` for the reference vector.

## 1. Rebuild with the probe

`mlkem_uart_core.sv` now carries `MARK_DEBUG` on `bm_wr_addr`, `bm_wr_data` and
`bm_wr_en`. Replace the file and re-synthesize.

## 2. Insert the ILA

    Open Synthesized Design -> Tools -> Set Up Debug

Select at minimum:

    bm_wr_addr [12:0]     where the byte is going
    bm_wr_data [7:0]      the byte itself
    bm_wr_en              write strobe
    sys_busy              engine running
    sys_reject            FO verdict

Sample depth 4096 (ample: only 32 samples matter). Clock domain `clk100`.
Finish, Save constraints, re-run Implementation, Generate Bitstream, reprogram.

**CHECK WNS.** It was +0.122 ns on the last build. An ILA adds capture logic on
every probed net. If WNS goes negative, probe only `bm_wr_addr`/`bm_wr_data`/
`bm_wr_en`, or drop to 83 MHz (`CLKOUT0_DIVIDE_F` 12.000, `CLKS_PER_BIT` 723).

## 3. Set the trigger

In Hardware Manager, on the ILA dashboard:

    Trigger condition:  bm_wr_en == 1  AND  bm_wr_addr == 3900

Enter 3900 as decimal, or `0xF3C` hex. Set trigger position to 0 so all 32
writes fall after the trigger point.

Arm it (the ">" run button). The core waits.

## 4. Run one operation

Any of these will fire it:

    py host_kex.py COM9 COM6          two-board exchange
    py host_nist.py COM6 decaps n=1   a single NIST vector

## 5. Read the waveform

The ILA fills. Expand `bm_wr_data` as hex. You will see 32 consecutive writes,
`bm_wr_addr` stepping 3900, 3901, ... 3931, and `bm_wr_data` carrying the
secret one byte per sample.

**That is the shared secret, captured on silicon.**

## What to say while showing it

> "The trigger is the FPGA's internal memory write bus at the shared-secret
> address. These 32 bytes were produced by the logic inside this chip. The PC
> supplied only the public key and the ciphertext, and it is not in this
> capture path at all -- the ILA reads directly out of the fabric over JTAG."

Then on the second board, capture the same way and show the two waveforms side
by side: identical 32 bytes, produced independently in two separate chips.

## Stronger variants

**Show the tamper case.** Capture with `--tamper`. `sys_reject` goes high and
the 32 bytes are different -- the implicit-rejection value. Same trigger, and it
demonstrates the security property, not just the happy path.

**Unplug the PC.** After the exchange completes, the secret stays in the byte
memory. Capture can be re-armed and a `0x11` read replayed later. The point is
that the PC is a courier, not a participant.

**Add ek and c to the capture.** Triggering on `bm_wr_addr == 2048` (ek) or
`== 0` (ciphertext) shows those being built too, if someone wants the whole
data flow rather than just the result.

## Honest note on what this proves

The ILA shows the secret is produced by fabric logic, which is the objection
being raised. It does not by itself prove the value is *cryptographically
correct* -- that is what the NIST vector run establishes, and the two pieces of
evidence are complementary:

    NIST vectors  -> the values are right (conformance)
    ILA capture   -> the hardware produced them (provenance)

Use both. Either alone leaves a gap a careful reviewer will find.
