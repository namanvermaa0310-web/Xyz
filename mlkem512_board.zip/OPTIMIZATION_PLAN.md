# ML-KEM-512 speed: measured baseline and where the cycles are

## The 1.2 ms figure was wrong

That number was measured over the serial link. Each status poll is one byte
out and one byte back at 115200 baud -- about 174 us round trip -- so a
handful of polls dominated the measurement.

The hardware cycle counter (UART command 0x31) reports the real latency
between busy rising and falling:

    KeyGen: 68,526 cycles = 685 us at 100 MHz

So roughly half the previously reported time was the measurement itself.
host_nist.py now prints both, e.g. "68526 cyc = 685 us (link 1.2 ms)".

## Where the 68,526 cycles go

    NTT engine       21,504   31.4%     4 forward NTTs
    matvec           18,966   27.7%     2 matrix-vector products
    XOF + SampleNTT   8,934   13.0%     4 matrix entries
    PRF + CBD         6,968   10.2%     4 noise polynomials
    G / H hashes      4,489    6.6%
    other/overhead    7,665   11.2%     copies, encodes, sequencing

NTT and matvec together are 59% of the time, and both bottleneck on the same
thing: multiply-then-Barrett-reduce run strictly sequentially.

## Target 1 -- basemul, the inner loop of matvec (~2x on 27.7%)

basemul computes five products, each as three sequential states
(MUL -> EST -> CORR), giving ~20 cycles. But only ONE of the five actually
depends on another:

    t1 = a1*b1     ---+
    t2 = t1*zeta   <--+   the only real dependency
    t3 = a0*b0     ---+
    t4 = a0*b1        |   these three are independent of everything
    t5 = a1*b0     ---+

The three-state Barrett sequence is a natural 3-stage PIPELINE. Pipelining it
allows a new product to be issued every cycle:

    cycle 0  issue a1*b1
    cycle 1  issue a0*b0
    cycle 2  issue a0*b1
    cycle 3  issue a1*b0 ; t1 available
    cycle 4  issue t1*zeta
    ...
    cycle ~9 both sums ready

~20 cycles -> ~10. Saves roughly 9,500 cycles (14% of total). No extra
multipliers: the same DSP is used every cycle instead of one cycle in three.

## Target 2 -- NTT butterfly overlap (~6x on 31.4%)

ntt_engine is 6 cycles per butterfly with no overlap: 896 butterflies x 6 =
5,376 cycles per transform, x4 transforms = 21,504.

The butterfly is one multiply plus a Barrett reduce plus an add/sub -- the
same three-stage shape. Overlapping consecutive butterflies (they are
independent within a stage) approaches 1 cycle per butterfly.

21,504 -> ~4,000. Saves roughly 17,500 cycles (26% of total).

## Combined

    now        68,526 cycles   685 us
    target 1   59,000          590 us
    target 2   41,500          415 us
    both       32,000          320 us     ~2.1x

Beyond that needs parallel DSPs (several butterflies at once), which is a
different design point -- more area, and the current 17 DSPs would grow.
Published FPGA ML-KEM designs reach 10-50 us using exactly that.

## Risk, stated plainly

Both targets are real redesigns of modules that are currently correct and
NIST-validated. ntt_engine in particular took three rounds of pipelining to
close timing in Phase 1, and board WNS is only +0.233 ns -- adding pipeline
registers may help timing (shorter paths) or hurt it (more routing).

Every change must re-pass:
    tb_nist_kg.sv        NIST keyGen vector
    tb_mlkem_full.sv     full KEM incl. implicit rejection
    the NIST vectors on the board

Recommended order: basemul first. It is smaller, self-contained, has its own
unit testbench, and delivers 14% before touching the module with the timing
history.
