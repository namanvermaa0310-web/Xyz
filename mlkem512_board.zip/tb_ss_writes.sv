`timescale 1ns/1ps
// Shows precisely what an ILA triggered on bm_wr_addr == SS_BASE will see.
module tb_ss_writes;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start; wire busy,done,serr,reject;
  wire [5:0] d_ra; reg [7:0] d_rd;
  wire [12:0] br_a,br2_a,bw_a; wire [7:0] bw_d; wire bw_en; reg [7:0] br_d,br2_d;
  wire [255:0] rho_out; wire [4:0] dbg;
  mlkem_system #(.K_PARAM(2),.ADDR_W(13)) dut(.clk(clk),.rst_n(rst_n),.op(op),
    .start(start),.busy(busy),.done(done),.d_rd_data(d_rd),.d_rd_addr(d_ra),
    .byte_rd_addr(br_a),.byte_rd_data(br_d),.byte_rd2_addr(br2_a),
    .byte_rd2_data(br2_d),.byte_wr_addr(bw_a),.byte_wr_data(bw_d),
    .byte_wr_en(bw_en),.rho_out(rho_out),.sample_error(serr),
    .reject(reject),.dbg_state(dbg));
  reg [7:0] bmem[0:8191], dmem[0:63];
  always @(posedge clk) begin br_d<=bmem[br_a]; br2_d<=bmem[br2_a];
    d_rd<=dmem[d_ra]; if(bw_en) bmem[bw_a]<=bw_d; end
  integer i, n;
  initial begin
    $readmemh("mk_init.hex", bmem); $readmemh("mk_d.hex", dmem);
    n=0;
    fork forever begin
      @(posedge clk);
      if (bw_en && bw_a>=13'd3900 && bw_a<13'd3932) begin
        if (n<8) $display("  ILA would capture: addr=%0d data=%02h", bw_a, bw_d);
        n=n+1;
      end
    end join_none
    rst_n=0;start=0;op=0; repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);
    @(negedge clk); op=2'd2; start=1; @(negedge clk); start=0;
    while(!busy) @(negedge clk); while(busy) @(negedge clk);
    repeat(20)@(posedge clk);
    $display("total writes to SS_BASE during Decaps: %0d (expect 32)", n);
    $finish;
  end
  initial begin #400_000_000; $display("TIMEOUT"); $finish; end
endmodule
