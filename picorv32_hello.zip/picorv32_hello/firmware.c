#define OUT  (*(volatile unsigned int*)0x10000000u)
#define HALT (*(volatile unsigned int*)0x10000004u)
void main(void){
    const char *s = "Hello from PicoRV32!\n";
    while(*s) OUT = (unsigned char)(*s++);
    HALT = 1u;
}
