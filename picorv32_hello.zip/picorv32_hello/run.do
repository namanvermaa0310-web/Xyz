# PicoRV32 minimal SoC - ModelSim run script
# Usage (GUI):    do run.do
# Usage (console): vsim -c -do run.do
vlib work
vlog picorv32.v tb_picosoc.v
vsim -voptargs=+acc tb_picosoc
run -all
