#ifndef NA_LOG_H
#define NA_LOG_H

#include <stdint.h>

/* =================================================================
 * na_log -- fault log + periodic health snapshot
 *
 * TWO outputs, deliberately separate:
 *
 *  1) EVENT LOG  (na_events.log)  -- "what went wrong"
 *     Human-readable, severity-tagged, timestamped. One line per
 *     abnormal event. This is what you read after a fault.
 *
 *  2) HEALTH SNAPSHOT (na_health.jsonl) -- "under what conditions"
 *     One JSON line per second: pools, dedup, sync, eviction, reorder.
 *     This is the black box -- after a crash the final lines show the
 *     machine state at the moment of death. Plot it to spot leaks
 *     (a monotonically falling pool count) in minutes, not weeks.
 *
 * Both rotate at NA_LOG_MAX_BYTES (file -> file.1, truncate).
 * Both are OPTIONAL: if na_log_init() is never called, every call
 * here is a no-op -- nothing breaks, nothing is written.
 *
 * DATAPATH RULE: na_log_health_tick() is called from the existing
 * 1-second housekeeping timer, NEVER per packet. na_log() itself is
 * for abnormal events only -- do not put it on a per-chunk path.
 * ================================================================= */

#define NA_LOG_MAX_BYTES   (32U * 1024U * 1024U)

typedef enum {
    NA_LOG_DEBUG = 0,
    NA_LOG_INFO,
    NA_LOG_WARN,
    NA_LOG_ERROR
} na_log_level_t;

/* event_path / health_path may be NULL to disable that stream.
 * min_level filters the event log (health is unfiltered). */
void na_log_init(const char *event_path, const char *health_path,
                 na_log_level_t min_level);

void na_log(na_log_level_t lvl, const char *fmt, ...)
     __attribute__((format(printf, 2, 3)));

/* Call once per second from the housekeeping timer block. */
void na_log_health_tick(void);

/* Pool figures come from the TCP/MemPool layer, which na_log must not
 * depend on directly. app_thread.c pushes them in before the tick. */
void na_log_set_pools(unsigned long mb_free, unsigned long rx_free,
                      unsigned long tx_free, unsigned long mb_fail,
                      unsigned long rx_fail, unsigned long tx_fail);

void na_log_close(void);

#endif /* NA_LOG_H */
