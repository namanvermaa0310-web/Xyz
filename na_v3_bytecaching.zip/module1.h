#ifndef MODULE1_H
#define MODULE1_H

#include <stdint.h>
#include <rte_mempool.h>
#include "TCP/mbuf.h"
#include "cdc_engine.h"

#define CHUNK_SIZE          CDC_MAX_CHUNK
#define INACTIVITY_TICKS    200
#define TIMER_RESOLUTION      1
#define TIMER_BYTE_CACHING  INACTIVITY_TICKS

#define CHUNK_POOL_COUNT    511U
#define CHUNK_POOL_CACHE    32U

/* V2: receiver batches sender_cids it stored; flushed as one CONFIRM
 * TLV at the end of every decode call. */
#define MODULE1_CONFIRM_BATCH 64

struct chunk {
    uint8_t  *data;
    uint32_t  bytes_used;
};

#define TLV_RX_VAL_MAX  CHUNK_SIZE

struct tlv_rx_state {
    int      active;
    uint8_t  hdr[3];
    uint8_t  hdr_got;
    uint8_t  val[TLV_RX_VAL_MAX + 8];   /* +8 covers 4B cid prefix     */
    uint32_t val_need;
    uint32_t val_got;
    uint8_t  piggy_buf[16];
    uint8_t  piggy_got;
    uint8_t  piggy_pending_dispatch;
};

struct reorder_rec;   /* defined in module4.c */

struct module1_state {
    struct chunk            current;
    uint32_t                chunk_to;
    struct mbuf            *tlv_pending;
    struct tlv_rx_state     rx;
    struct cdc_rabin_state  rabin;

    /* V2 (epoch + confirmed-set): the peer's tunnel IP, stamped by
     * uipc_socket.c before module1_add_data. module4 derives both the
     * cold flag AND the per-peer confirmed bitmap from this key. */
    uint32_t peer_key;
    uint8_t  hello_sent;

    /* V2 (stall-at-gap): per-connection ordered forward queue on the
     * DECODE side. Non-empty only while a NAK repair is outstanding. */
    struct reorder_rec *ro_head;
    struct reorder_rec *ro_tail;
    uint32_t            ro_count;
    uint32_t            ro_holes;

    /* V2 (CONFIRM): sender_cids stored this decode call, awaiting
     * batch send back to the sender. */
    uint32_t confirm_pending[MODULE1_CONFIRM_BATCH];
    uint8_t  confirm_count;

    uint32_t total_bytes_received;
    uint32_t full_chunks_sent;
    uint32_t partial_chunks_sent;
    uint32_t max_chunks_sent;
    uint32_t total_chunks_sent;
};

void     module1_init(void);
void     module1_state_init(struct module1_state *s);
uint32_t module1_add_data(struct module1_state *s, struct mbuf *m);
void     byte_caching_timer_check(struct module1_state *s);
void     module1_flush(struct module1_state *s);

#endif /* MODULE1_H */
