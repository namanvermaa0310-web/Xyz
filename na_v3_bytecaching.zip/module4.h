#ifndef MODULE4_H
#define MODULE4_H

#include <stdint.h>
#include "TCP/mbuf.h"
#include "module1.h"

struct socket;

#define MODULE4_HASH_SIZE   32
#define MODULE4_CHUNK_SIZE  CHUNK_SIZE
#define MODULE4_CID_SIZE     4
#define MODULE4_GEN_SIZE     4

#define TLV_TYPE_HIT     0xfd
#define TLV_TYPE_MISS    0xbf   /* V2: value = [sender_cid 4B BE][data] */
#define TLV_TYPE_NAK     0xfb
#define TLV_TYPE_HELLO   0xfe   /* value = generation 4B BE            */
#define TLV_TYPE_CONFIRM 0xfc   /* V2: value = N x sender_cid (4B BE)  */
#define TLV_TYPE_RAW     0xba   /* V3: value = data, NO dedup. Chunks
                                   below conf_min_cache_size skip the
                                   hash + store entirely and ride as
                                   RAW. Still TLV-framed because the
                                   decoder is a strict byte-by-byte
                                   state machine -- unframed bytes on
                                   this stream would be parsed as a
                                   header and desync the connection.
                                   3 bytes of framing buys skipping
                                   SHA-256, the store write, the index
                                   entry and the disk I/O. */
#define TLV_HDR_SIZE     3

/* decode-side length bound: full-size MISS = 4B cid + CHUNK_SIZE data;
 * still inside rx->val[TLV_RX_VAL_MAX + 8]. */
#define MODULE4_MAX_TLV_VAL (TLV_RX_VAL_MAX + MODULE4_CID_SIZE)

#define MODULE4_MAX_PEERS       16
#define MODULE4_NAK_COLD_THRESHOLD 5
/* confirmed bitmap covers cids 1..MODULE4_CID_SPACE. cids are
 * monotonic and, with eviction, grow past MODULE2_MAX_CHUNKS over the
 * appliance's lifetime; 4x headroom covers ~3 full store turnovers.
 * cids beyond the space are ALWAYS sent as MISS (safe, no dedup) --
 * revisit if evict counters show fast turnover. 8M bits = 1 MB/peer. */
#include "module2.h"
#define MODULE4_CID_SPACE   (4U * MODULE2_MAX_CHUNKS)
#define MODULE4_BITMAP_BYTES ((MODULE4_CID_SPACE + 7U) / 8U)

/* stall-at-gap: hard cap on queued records per connection. Exceeding
 * it force-drains (holes are abandoned, loudly) rather than growing
 * without bound during a stall. */
#define MODULE4_REORDER_MAX  1024

struct module4_state {
    uint32_t total_hits;
    uint32_t total_misses;
    uint32_t total_lookups;
    uint32_t total_nak_sent;
    uint32_t total_nak_received;
    uint32_t total_nak_unsatisfiable;
    uint32_t total_hello_sent;
    uint32_t total_hello_received;
    uint32_t total_cold_transitions;
    uint32_t forced_miss_cold;
    uint32_t forced_miss_unconfirmed;   /* V2: had it, peer bit clear   */
    uint32_t confirms_sent;             /* V2: CONFIRM TLVs sent        */
    uint32_t confirms_received;         /* V2: cids marked confirmed    */
    uint32_t reorder_held;              /* V2: records queued behind gap */
    uint32_t reorder_filled;            /* V2: holes filled by resend    */
    uint32_t reorder_overflow;          /* V2: force-drains (data loss!) */
    uint32_t total_raws;                /* V3: sub-threshold, uncached  */
};

void         module4_init(void);

/* V2: peer_key replaces the bare cold flag -- module4 derives cold AND
 * the confirmed bitmap from it. HIT only if warm AND bit set. */
struct mbuf *module4_lookup_and_build_tlv(uint8_t *hash, uint8_t *data,
                                           uint32_t data_len, uint32_t peer_key);

/* V2: takes module1_state (owns rx + reorder queue + confirm batch). */
void         module4_decode_tlv_chain(struct mbuf *top, struct socket *so1,
                                       struct socket *so2,
                                       struct module1_state *ms);

struct mbuf *module4_build_hello(void);
void         module4_conn_reset(struct module1_state *ms);  /* free queue */
void         module4_print_stats(void);

/* health snapshot for na_log (no printf, pure data) */
struct m4_health {
    uint32_t lookups, hits, misses, raws, dedup_pct;
    uint32_t nak_sent, nak_recv, nak_unsat;
    uint32_t hello_sent, hello_recv, cold_transitions;
    uint32_t fmiss_cold, fmiss_unconf;
    uint32_t confirms_sent, confirms_recv;
    uint32_t ro_held, ro_filled, ro_overflow;
};
void         module4_get_health(struct m4_health *out);

#endif /* MODULE4_H */
