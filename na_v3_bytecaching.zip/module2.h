#ifndef MODULE2_H
#define MODULE2_H

#include <stdint.h>
#include <stdio.h>
#include <rte_hash.h>

/* =================================================================
 * 8 GB SLOT STORE + CLOCK EVICTION -- no linear scans on any hot path
 *
 *   8 GB / 4096                = 2,097,152 chunks
 *   slot = 40 hdr + 4096 data  = 4136 B; offset = slot * 4136
 *   file hard bound            = ~8.68 GB (fixed slots, in-place reuse)
 *   index RAM                  = ~134 MB static (BSS)
 *
 * LOOKUPS (all O(1)):
 *   hash -> slot : rte_hash g_m2.hash_table        (encode/dedup)
 *   cid  -> slot : rte_hash g_cid_map              (HIT reads, refs)
 *   free slot    : stack pop                        (store, not full)
 *   eviction     : CLOCK hand                       (store, full)
 *
 * EVICTION = CLOCK / second-chance (Corbato 1968; the policy behind
 * BSD/Linux page reclaim). One reference bit per slot, set on every
 * access. A circular hand sweeps: ref=1 -> clear bit, advance;
 * ref=0 -> evict. O(1) amortized, no linked list to corrupt.
 * NOTE: no IETF RFC standardizes cache eviction; CLOCK is the
 * literature-proven choice, stated as such.
 *
 * GRACE: slots touched within EVICT_GRACE accesses are skipped by the
 * hand (treated as referenced) -- closes the HIT-sent/evict/NAK-in-
 * flight race on ~700 ms links. increment_ref on a HIT refreshes the
 * stamp, making recently-HIT chunks unevictable for the window.
 *
 * FILE FORMAT: BREAKING vs the append store -- wipe Chunk_store.dat
 * on BOTH ends. Generation is untouched by eviction (not a wipe).
 * ================================================================= */

#define MODULE2_MAX_CHUNKS     2097152U        /* 8 GB / 4096          */
#define MODULE2_HASH_SIZE           32
#define MODULE2_CHUNK_MAX         4096U
#define MODULE2_HDR_SIZE            40
#define MODULE2_SLOT_SIZE      (MODULE2_HDR_SIZE + MODULE2_CHUNK_MAX)
#define MODULE2_STORE_FILE   "Chunk_store.dat"
#define MODULE2_GEN_FILE     "Chunk_store.gen"
#define MODULE2_HASH_TABLE_SZ  4194304U        /* 2x keys              */
#define MODULE2_EVICT_GRACE     262144U        /* accesses             */

struct chunk_index {
    uint32_t chunk_id;
    uint8_t  hash[MODULE2_HASH_SIZE];
    uint32_t data_len;
    uint32_t ref_count;
    uint64_t last_use;      /* access stamp -- grace window            */
    uint8_t  ref_bit;       /* CLOCK reference bit                     */
    uint8_t  is_used;
};

struct module2_state {
    struct chunk_index  index[MODULE2_MAX_CHUNKS];
    uint32_t            total_stored;
    uint32_t            next_chunk_id;    /* monotonic, never reused   */
    uint64_t            use_clock;
    uint32_t            clock_hand;
    uint32_t            evictions;
    uint32_t            evict_forced;     /* hand gave up on grace/ref */
    uint32_t            total_bytes_stored;
    uint32_t            duplicate_count;
    FILE               *fp;
    struct rte_hash    *hash_table;
    uint32_t            generation;
};

void     module2_init(void);
uint32_t module2_store_chunk(uint8_t *data, uint32_t data_len, uint8_t *hash);
uint32_t module2_find_by_hash(uint8_t *hash);
uint32_t module2_read_chunk(uint32_t chunk_id, uint8_t *buf, uint32_t buf_size);
void     module2_print_stats(void);
void     module2_increment_ref(uint32_t chunk_id);
void     module2_close(void);
uint32_t module2_get_generation(void);

/* health snapshot for na_log (no printf, pure data) */
struct m2_health {
    uint32_t used, max, mb_stored, evictions, evict_forced, generation;
};
void     module2_get_health(struct m2_health *out);

#endif /* MODULE2_H */
