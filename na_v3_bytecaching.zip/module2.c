#include <stdio.h>
#include <string.h>
#include <rte_hash.h>
#include <rte_jhash.h>
#include <rte_eal.h>
#include <time.h>
#include "module2.h"

static struct module2_state g_m2;

/* cid -> slot, O(1). cids are monotonic and never reused; entries are
 * deleted on eviction, so live population <= MAX_CHUNKS. */
static struct rte_hash *g_cid_map;

/* free-slot stack: O(1) pop while the store is below capacity. */
static uint32_t g_free_stack[MODULE2_MAX_CHUNKS];
static uint32_t g_free_top;      /* number of entries on the stack */

static long slot_offset(uint32_t slot)
{
    return (long)slot * (long)MODULE2_SLOT_SIZE;
}

static inline void touch(uint32_t slot)
{
    g_m2.index[slot].ref_bit  = 1;
    g_m2.index[slot].last_use = ++g_m2.use_clock;
}

void module2_init(void)
{
    uint32_t slot;
    struct rte_hash_parameters hp;
    int store_existed = 1;

    memset(&g_m2, 0, sizeof(g_m2));
    g_m2.next_chunk_id = 1;
    g_free_top = 0;

    g_m2.fp = fopen(MODULE2_STORE_FILE, "r+b");
    if (!g_m2.fp) {
        store_existed = 0;
        g_m2.fp = fopen(MODULE2_STORE_FILE, "w+b");
        if (!g_m2.fp) { printf("cannot open chunk store file\n"); return; }
        printf("created new chunk store (slot format, %u slots, ~%lu MB max)\n",
               MODULE2_MAX_CHUNKS,
               ((unsigned long)MODULE2_MAX_CHUNKS * MODULE2_SLOT_SIZE) >> 20);
    }

    /* generation: time-based on fresh store (survives full-directory
     * wipes and node replacement); read back unchanged otherwise.
     * Eviction NEVER touches this. */
    {
        FILE *gf = fopen(MODULE2_GEN_FILE, "r");
        uint32_t g = 0;
        if (gf) { if (fscanf(gf, "%u", &g) != 1) g = 0; fclose(gf); }
        if (!store_existed || g == 0) {
            g = (uint32_t)time(NULL);
            FILE *gw = fopen(MODULE2_GEN_FILE, "w");
            if (gw) { fprintf(gw, "%u\n", g); fclose(gw); }
        }
        g_m2.generation = g;
        printf("module2: generation = %u (store %s)\n",
               g, store_existed ? "loaded" : "FRESH/wiped");
    }

    memset(&hp, 0, sizeof(hp));
    hp.name      = "chunk_hash_table";
    hp.entries   = MODULE2_HASH_TABLE_SZ;
    hp.key_len   = MODULE2_HASH_SIZE;
    hp.hash_func = rte_jhash;
    hp.socket_id = rte_socket_id();
    g_m2.hash_table = rte_hash_create(&hp);

    memset(&hp, 0, sizeof(hp));
    hp.name      = "chunk_cid_map";
    hp.entries   = MODULE2_HASH_TABLE_SZ;
    hp.key_len   = sizeof(uint32_t);
    hp.hash_func = rte_jhash;
    hp.socket_id = rte_socket_id();
    g_cid_map = rte_hash_create(&hp);

    if (!g_m2.hash_table || !g_cid_map) {
        printf("hash table creation failed\n");
        return;
    }

    if (store_existed) {
        /* one-time O(n) rebuild: file position IS the slot number */
        printf("loading slot store from disk...\n");
        for (slot = 0; slot < MODULE2_MAX_CHUNKS; slot++) {
            uint32_t cid, dlen;
            uint8_t  h[MODULE2_HASH_SIZE];

            if (fseek(g_m2.fp, slot_offset(slot), SEEK_SET) != 0) break;
            if (fread(&cid,  sizeof(uint32_t),  1, g_m2.fp) != 1) break; /* EOF */
            if (fread(&dlen, sizeof(uint32_t),  1, g_m2.fp) != 1) break;
            if (fread(h,     MODULE2_HASH_SIZE, 1, g_m2.fp) != 1) break;

            if (cid == 0 || dlen == 0 || dlen > MODULE2_CHUNK_MAX)
                continue;                       /* never-written slot */

            g_m2.index[slot].chunk_id  = cid;
            g_m2.index[slot].data_len  = dlen;
            g_m2.index[slot].ref_count = 1;
            g_m2.index[slot].ref_bit   = 0;     /* CLOCK: cold on load */
            g_m2.index[slot].last_use  = 0;
            g_m2.index[slot].is_used   = 1;
            memcpy(g_m2.index[slot].hash, h, MODULE2_HASH_SIZE);

            if (cid >= g_m2.next_chunk_id)
                g_m2.next_chunk_id = cid + 1;

            {
                intptr_t s = (intptr_t)slot;
                rte_hash_add_key_data(g_m2.hash_table, h, (void *)s);
                rte_hash_add_key_data(g_cid_map, &cid, (void *)s);
            }
            g_m2.total_stored++;
            g_m2.total_bytes_stored += dlen;
        }
        printf("done loading: %u chunks, next id %u\n",
               g_m2.total_stored, g_m2.next_chunk_id);
    }

    /* free stack: every unused slot, descending so low slots pop first */
    for (slot = MODULE2_MAX_CHUNKS; slot > 0; slot--) {
        if (!g_m2.index[slot - 1].is_used)
            g_free_stack[g_free_top++] = slot - 1;
    }
    printf("free slots: %u / %u\n", g_free_top, MODULE2_MAX_CHUNKS);
}

uint32_t module2_get_generation(void) { return g_m2.generation; }

void module2_get_health(struct m2_health *o)
{
    if (!o) return;
    o->used         = g_m2.total_stored;
    o->max          = MODULE2_MAX_CHUNKS;
    o->mb_stored    = g_m2.total_bytes_stored >> 20;
    o->evictions    = g_m2.evictions;
    o->evict_forced = g_m2.evict_forced;
    o->generation   = g_m2.generation;
}

static int slot_of_cid(uint32_t cid)
{
    void *data;
    if (!g_cid_map) return -1;
    if (rte_hash_lookup_data(g_cid_map, &cid, &data) < 0) return -1;
    return (int)(intptr_t)data;
}

uint32_t module2_find_by_hash(uint8_t *hash)
{
    void *data;
    int   slot;

    if (!hash || !g_m2.hash_table) return 0;
    if (rte_hash_lookup_data(g_m2.hash_table, hash, &data) < 0) return 0;

    slot = (int)(intptr_t)data;
    if (slot < 0 || slot >= (int)MODULE2_MAX_CHUNKS || !g_m2.index[slot].is_used)
        return 0;
    touch((uint32_t)slot);
    return g_m2.index[slot].chunk_id;
}

/* ---- CLOCK eviction: O(1) amortized, hand sweeps at most 2 laps ---- */
static int clock_evict(void)
{
    uint32_t sweeps = 2U * MODULE2_MAX_CHUNKS;
    uint32_t s;

    while (sweeps--) {
        s = g_m2.clock_hand;
        g_m2.clock_hand = (g_m2.clock_hand + 1U) % MODULE2_MAX_CHUNKS;

        if (!g_m2.index[s].is_used) continue;

        /* grace: recently touched (possible HIT-in-flight) -> skip
         * WITHOUT clearing the ref bit */
        if (g_m2.use_clock - g_m2.index[s].last_use < MODULE2_EVICT_GRACE)
            continue;

        if (g_m2.index[s].ref_bit) {           /* second chance */
            g_m2.index[s].ref_bit = 0;
            continue;
        }

        /* victim */
        rte_hash_del_key(g_m2.hash_table, g_m2.index[s].hash);
        rte_hash_del_key(g_cid_map, &g_m2.index[s].chunk_id);
        g_m2.total_bytes_stored -= g_m2.index[s].data_len;
        g_m2.index[s].is_used = 0;
        g_m2.total_stored--;
        g_m2.evictions++;
        return (int)s;
    }

    /* every slot in grace or referenced across two laps (pathological):
     * take the hand's slot regardless, loudly, rather than fail. */
    s = g_m2.clock_hand;
    g_m2.clock_hand = (g_m2.clock_hand + 1U) % MODULE2_MAX_CHUNKS;
    if (!g_m2.index[s].is_used) return -1;
    printf("clock_evict: forced eviction of slot %u (all in grace)\n", s);
    g_m2.evict_forced++;
    rte_hash_del_key(g_m2.hash_table, g_m2.index[s].hash);
    rte_hash_del_key(g_cid_map, &g_m2.index[s].chunk_id);
    g_m2.total_bytes_stored -= g_m2.index[s].data_len;
    g_m2.index[s].is_used = 0;
    g_m2.total_stored--;
    g_m2.evictions++;
    return (int)s;
}

static int get_slot(void)
{
    if (g_free_top > 0)
        return (int)g_free_stack[--g_free_top];    /* O(1), store not full */
    return clock_evict();
}

uint32_t module2_store_chunk(uint8_t *data, uint32_t dlen, uint8_t *hash)
{
    int      slot;
    uint32_t cid;

    if (!data || !hash || dlen == 0 || dlen > MODULE2_CHUNK_MAX) return 0;
    if (!g_m2.fp)         { printf("file not open\n");        return 0; }
    if (!g_m2.hash_table) { printf("hash table not ready\n"); return 0; }

    cid = module2_find_by_hash(hash);
    if (cid != 0) {
        module2_increment_ref(cid);
        return cid;
    }

    slot = get_slot();
    if (slot < 0) { printf("store full and eviction failed\n"); return 0; }

    cid = g_m2.next_chunk_id++;

    if (fseek(g_m2.fp, slot_offset((uint32_t)slot), SEEK_SET) != 0) return 0;
    fwrite(&cid,  sizeof(uint32_t),  1, g_m2.fp);
    fwrite(&dlen, sizeof(uint32_t),  1, g_m2.fp);
    fwrite(hash,  MODULE2_HASH_SIZE, 1, g_m2.fp);
    fwrite(data,  dlen,              1, g_m2.fp);
    fflush(g_m2.fp);

    g_m2.index[slot].chunk_id  = cid;
    g_m2.index[slot].data_len  = dlen;
    g_m2.index[slot].ref_count = 1;
    g_m2.index[slot].is_used   = 1;
    memcpy(g_m2.index[slot].hash, hash, MODULE2_HASH_SIZE);
    touch((uint32_t)slot);

    {
        intptr_t s = (intptr_t)slot;
        if (rte_hash_add_key_data(g_m2.hash_table, hash, (void *)s) < 0)
            printf("hash insert failed for chunk %u\n", cid);
        if (rte_hash_add_key_data(g_cid_map, &cid, (void *)s) < 0)
            printf("cid map insert failed for chunk %u\n", cid);
    }

    g_m2.total_stored++;
    g_m2.total_bytes_stored += dlen;
    return cid;
}

uint32_t module2_read_chunk(uint32_t cid, uint8_t *buf, uint32_t buf_size)
{
    int    slot;
    size_t n;

    if (!buf || cid == 0) return 0;
    if (!g_m2.fp) { printf("file not open\n"); return 0; }

    slot = slot_of_cid(cid);                       /* O(1), no scan */
    if (slot < 0 || !g_m2.index[slot].is_used ||
        g_m2.index[slot].chunk_id != cid) {
        printf("chunk %u not found\n", cid);
        return 0;
    }

    if (buf_size < g_m2.index[slot].data_len) {
        printf("read buffer too small\n");
        return 0;
    }

    fseek(g_m2.fp, slot_offset((uint32_t)slot) + MODULE2_HDR_SIZE, SEEK_SET);
    n = fread(buf, 1, g_m2.index[slot].data_len, g_m2.fp);
    if (n != g_m2.index[slot].data_len) {
        printf("short read: got %zu, wanted %u\n", n, g_m2.index[slot].data_len);
        return 0;
    }
    touch((uint32_t)slot);
    return (uint32_t)n;
}

void module2_increment_ref(uint32_t cid)
{
    int slot;
    if (cid == 0) return;
    slot = slot_of_cid(cid);                       /* O(1), no scan */
    if (slot < 0 || !g_m2.index[slot].is_used) return;
    g_m2.index[slot].ref_count++;
    g_m2.duplicate_count++;
    touch((uint32_t)slot);
}

void module2_print_stats(void)
{
    uint32_t total   = g_m2.total_stored + g_m2.duplicate_count;
    uint32_t hit_pct = total ? (g_m2.duplicate_count * 100) / total : 0;
    printf("unique chunks:  %u / %u\n", g_m2.total_stored, MODULE2_MAX_CHUNKS);
    printf("duplicates:     %u\n", g_m2.duplicate_count);
    printf("bytes stored:   %u MB\n", g_m2.total_bytes_stored >> 20);
    printf("next chunk id:  %u\n", g_m2.next_chunk_id);
    printf("dedup ratio:    %u%%\n", hit_pct);
    printf("generation:     %u\n", g_m2.generation);
    printf("evictions:      %u (forced %u)  hand=%u  free=%u\n",
           g_m2.evictions, g_m2.evict_forced, g_m2.clock_hand, g_free_top);
}

void module2_close(void)
{
    if (g_m2.hash_table) { rte_hash_free(g_m2.hash_table); g_m2.hash_table = NULL; }
    if (g_cid_map)       { rte_hash_free(g_cid_map);       g_cid_map = NULL; }
    if (g_m2.fp)         { fclose(g_m2.fp);                g_m2.fp = NULL; }
}
