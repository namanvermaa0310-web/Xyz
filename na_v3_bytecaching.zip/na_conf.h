#ifndef NA_CONF_H
#define NA_CONF_H

#include <stdint.h>

/* =================================================================
 * na_conf -- reads the [na_params] block of profile.cfg.
 *
 * Self-contained INI reader so this drops in without touching your
 * cfg_file.c / rte_cfgfile plumbing. If you prefer, replace
 * na_conf_load() with rte_cfgfile_get_entry() calls -- the rest of
 * the code only uses the accessors below.
 *
 * profile.cfg additions (all optional, defaults shown):
 *
 *   [na_params]
 *   conf_min_cache_size = 512               ; bytes; below this a
 *                                           ; chunk is sent RAW --
 *                                           ; no hash, no store
 *   conf_log_events     = na_events.log     ; empty = disabled
 *   conf_log_health     = na_health.jsonl   ; empty = disabled
 *   conf_log_level      = 1                 ; 0=DEBUG 1=INFO 2=WARN 3=ERROR
 * ================================================================= */

#define NA_DEFAULT_MIN_CACHE_SIZE  512U

void        na_conf_load(const char *profile_path);
uint32_t    na_conf_min_cache_size(void);
const char *na_conf_log_events(void);
const char *na_conf_log_health(void);
int         na_conf_log_level(void);

#endif /* NA_CONF_H */
