--=============================================================================
-- tb_loopback.vhd
--
--  Testbench:  ftile_eth_400g_model  <->  eth400g_loopback
--
--  All settings are in the SETTINGS block below. Change one value, re-run.
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use work.eth400g_pkg.all;

entity tb_loopback is
end entity tb_loopback;

architecture sim of tb_loopback is

    --=========================================================================
    --  >>>>>>>>>>>>>>>>>>>>   SETTINGS   <<<<<<<<<<<<<<<<<<<<
    --=========================================================================
    --  FRAME_LEN : every frame exactly this many bytes, 64 .. 65535
    --      A beat is 128 bytes (16 seg x 8 B), so
    --          frames per beat = 16 / (ceil(FRAME_LEN/8) + GAP_SEGS)
    --      64   -> 8 seg  -> 2 frames per beat  (the multi-frame case)
    --      1436 -> 180 seg -> 12 beats per frame
    --      9000 -> jumbo. Needs DROP_DELAY >= 80.
    --
    --  eop_empty is non-zero only when FRAME_LEN is not a multiple of 8.
    --=========================================================================
    constant FRAME_LEN    : natural := 64;
    constant GAP_SEGS     : natural := 1;    -- idle segments between frames
                                             -- 0 = tight packing (inframe=ffff)
                                             -- >=1 needed for DROP to resolve
                                             --     frame boundaries
    constant STALL_RATE   : natural := 0;    -- 0 = never, 40 = often
    constant ERR_RATE     : natural := 0;    -- 0 = none, 64 = ~25% of frames
    constant DROP_ON_ERR  : std_logic := '1';
    constant ALGO_LATENCY : positive := 17;  -- your X. any value.
    constant PROC_BYPASS  : boolean  := false;
    constant RUN_CYCLES   : natural := 6000;
    constant RX_MAX_FRAME : natural := 1518;
    constant AVG_IPG      : natural := 12;   -- 12 = standard, 1 = max rate
    --=========================================================================

    constant RDY_LAT    : natural := 3;
    constant DROP_DELAY : positive := 16;

    signal clk       : std_logic := '0';
    signal rst_n     : std_logic := '0';
    signal tx_rst_n  : std_logic := '1';
    signal rx_rst_n  : std_logic := '1';
    signal run       : std_logic := '0';
    signal sim_done  : boolean   := false;

    -- reset / status
    signal rst_ack_n, tx_rst_ack_n, rx_rst_ack_n : std_logic;
    signal tx_lanes_stable, rx_pcs_ready         : std_logic;
    signal rx_block_lock, rx_am_lock             : std_logic;
    signal rx_pcs_fully_aligned                  : std_logic;
    signal local_fault, remote_fault, hi_ber     : std_logic;

    -- RX
    signal rx_data      : std_logic_vector(DATA_W-1 downto 0);
    signal rx_valid     : std_logic;
    signal rx_inframe   : std_logic_vector(NUM_SEG-1 downto 0);
    signal rx_eop_empty : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
    signal rx_fcs_error : std_logic_vector(NUM_SEG-1 downto 0);
    signal rx_error     : std_logic_vector(NUM_SEG*ERR_W-1 downto 0);
    signal rx_status    : std_logic_vector(NUM_SEG*STAT_W-1 downto 0);

    -- TX
    signal tx_data      : std_logic_vector(DATA_W-1 downto 0);
    signal tx_valid     : std_logic;
    signal tx_inframe   : std_logic_vector(NUM_SEG-1 downto 0);
    signal tx_eop_empty : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
    signal tx_error     : std_logic_vector(NUM_SEG-1 downto 0);
    signal tx_skip_crc  : std_logic_vector(NUM_SEG-1 downto 0);
    signal tx_ready     : std_logic;

    signal m_rx_frames, m_bad_frames, m_viol : unsigned(31 downto 0);
    signal rx_beats, tx_beats, ovf_beats     : unsigned(31 downto 0);
    signal dropped_frames                    : unsigned(31 downto 0);
    signal fifo_level                        : unsigned(15 downto 0);

    signal dbg_wr      : std_logic;
    signal dbg_data    : std_logic_vector(DATA_W-1 downto 0);
    signal dbg_inframe : std_logic_vector(NUM_SEG-1 downto 0);
    signal dbg_empty   : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);

    constant ZERO_SEG : std_logic_vector(NUM_SEG-1 downto 0) := (others => '0');

    -- integrity check
    constant QD : natural := 8192;
    constant REF_W : natural := DATA_W + NUM_SEG + NUM_SEG*EMPTY_W;
    type refq_t is array (0 to QD-1) of std_logic_vector(REF_W-1 downto 0);
    signal refq     : refq_t;
    signal wr_i     : natural := 0;
    signal rd_i     : natural := 0;
    signal mismatch : natural := 0;
    signal raw_beats: natural := 0;

begin

    clk <= not clk after CLK_PERIOD_PS/2 when not sim_done else '0';

    --=========================================================================
    u_ip : entity work.ftile_eth_400g_model
        generic map (
            READY_LATENCY => RDY_LAT,
            RX_MAX_FRAME  => RX_MAX_FRAME,
            TX_MAX_FRAME  => RX_MAX_FRAME,
            ENFORCE_MAX   => false,
            RX_STRIP      => STRIP_CRC,
            AVG_IPG       => AVG_IPG,
            MIN_LEN       => MIN_ETH_FRAME,
            MAX_LEN       => 1518
        )
        port map (
            i_clk_tx => clk, i_clk_rx => clk,
            i_rst_n => rst_n, i_tx_rst_n => tx_rst_n, i_rx_rst_n => rx_rst_n,
            o_rst_ack_n => rst_ack_n,
            o_tx_rst_ack_n => tx_rst_ack_n,
            o_rx_rst_ack_n => rx_rst_ack_n,
            o_tx_lanes_stable => tx_lanes_stable,
            o_rx_pcs_ready => rx_pcs_ready,
            o_rx_block_lock => rx_block_lock,
            o_rx_am_lock => rx_am_lock,
            o_rx_pcs_fully_aligned => rx_pcs_fully_aligned,
            o_local_fault_status => local_fault,
            o_remote_fault_status => remote_fault,
            o_rx_hi_ber => hi_ber,
            i_gen_enable => run,
            i_force_len => to_unsigned(FRAME_LEN, 16),
            i_gap_segs  => to_unsigned(GAP_SEGS, 3),
            i_err_rate  => to_unsigned(ERR_RATE, 8),
            i_tx_stall_rate => to_unsigned(STALL_RATE, 8),
            o_rx_mac_data => rx_data,
            o_rx_mac_valid => rx_valid,
            o_rx_mac_inframe => rx_inframe,
            o_rx_mac_eop_empty => rx_eop_empty,
            o_rx_mac_fcs_error => rx_fcs_error,
            o_rx_mac_error => rx_error,
            o_rx_mac_status_data => rx_status,
            i_tx_mac_data => tx_data,
            i_tx_mac_valid => tx_valid,
            i_tx_mac_inframe => tx_inframe,
            i_tx_mac_eop_empty => tx_eop_empty,
            i_tx_mac_error => tx_error,
            i_tx_mac_skip_crc => tx_skip_crc,
            o_tx_mac_ready => tx_ready,
            o_model_rx_frames => m_rx_frames,
            o_model_bad_frames => m_bad_frames,
            o_model_proto_viol => m_viol
        );

    --=========================================================================
    u_lb : entity work.eth400g_loopback
        generic map (
            READY_LATENCY => RDY_LAT,
            FIFO_DEPTH    => 512,
            ALGO_LATENCY  => ALGO_LATENCY,
            PROC_BYPASS   => PROC_BYPASS,
            DROP_DELAY    => DROP_DELAY,
            TAG_W         => 6
        )
        port map (
            clk => clk, rst_n => rst_n,
            i_tx_lanes_stable => tx_lanes_stable,
            i_rx_pcs_ready    => rx_pcs_ready,
            i_rx_mac_data => rx_data,
            i_rx_mac_valid => rx_valid,
            i_rx_mac_inframe => rx_inframe,
            i_rx_mac_eop_empty => rx_eop_empty,
            i_rx_mac_fcs_error => rx_fcs_error,
            i_rx_mac_error => rx_error,
            i_tx_error      => (others => '0'),
            i_tx_skip_crc   => (others => '0'),
            i_drop_on_error => DROP_ON_ERR,
            o_tx_mac_data => tx_data,
            o_tx_mac_valid => tx_valid,
            o_tx_mac_inframe => tx_inframe,
            o_tx_mac_eop_empty => tx_eop_empty,
            o_tx_mac_error => tx_error,
            o_tx_mac_skip_crc => tx_skip_crc,
            i_tx_mac_ready => tx_ready,
            o_rx_beats => rx_beats,
            o_tx_beats => tx_beats,
            o_ovf_beats => ovf_beats,
            o_dropped_frames => dropped_frames,
            o_fifo_level => fifo_level,
            o_dbg_wr      => dbg_wr,
            o_dbg_data    => dbg_data,
            o_dbg_inframe => dbg_inframe,
            o_dbg_empty   => dbg_empty
        );

    --=========================================================================
    -- DATA INTEGRITY
    --
    -- Compares against the stream AFTER the algorithm, because the algorithm
    -- changes the data by design. Enqueues on the DUT's ACTUAL FIFO write
    -- event: gating on the RX input instead desynchronises the queue the
    -- moment a beat is dropped, turning one drop into an unbounded run of
    -- false mismatches.
    --=========================================================================
    chk : process(clk)
        variable sent : boolean;
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                wr_i <= 0; rd_i <= 0; mismatch <= 0; raw_beats <= 0;
            else
                if rx_valid = '1' and rx_inframe /= ZERO_SEG then
                    raw_beats <= raw_beats + 1;
                end if;

                -- Uses the loopback's debug ports rather than VHDL-2008
                -- external names, so this runs in any VHDL-93 simulator.
                if dbg_wr = '1' then
                    refq(wr_i mod QD) <= dbg_data & dbg_inframe & dbg_empty;
                    wr_i <= wr_i + 1;
                end if;

                sent := (tx_valid = '1') and (tx_inframe /= ZERO_SEG);
                if sent then
                    if refq(rd_i mod QD) /=
                       (tx_data & tx_inframe & tx_eop_empty) then
                        mismatch <= mismatch + 1;
                    end if;
                    rd_i <= rd_i + 1;
                end if;
            end if;
        end if;
    end process;

    --=========================================================================
    stim : process
        variable t0, t1   : time;
        variable b0, b1   : natural;
        variable gbps,fpb : real;
        variable L        : line;
    begin
        --------------------------------------------------------------------
        -- RESET SEQUENCE  (UG sec 6.2)
        --   Drive i_rst_n high WHILE i_tx_rst_n and i_rx_rst_n are already
        --   deasserted, then wait for o_tx_lanes_stable / o_rx_pcs_ready.
        --   The datapath must NOT drive TX before lanes are stable.
        --------------------------------------------------------------------
        tx_rst_n <= '1';
        rx_rst_n <= '1';
        rst_n    <= '0';
        for i in 0 to 19 loop wait until rising_edge(clk); end loop;
        rst_n    <= '1';

        wait until tx_lanes_stable = '1' and rx_pcs_ready = '1';
        report "IP out of reset: tx_lanes_stable and rx_pcs_ready asserted";
        for i in 0 to 9 loop wait until rising_edge(clk); end loop;

        --------------------------------------------------------------------
        -- Start traffic, let the pipeline FILL, then measure steady state.
        -- Counting the fill makes throughput LOOK latency-dependent when the
        -- steady-state rate is not.
        --------------------------------------------------------------------
        run <= '1';
        for i in 0 to ALGO_LATENCY + DROP_DELAY + 128 loop
            wait until rising_edge(clk);
        end loop;

        t0 := now;
        b0 := to_integer(tx_beats);
        for i in 0 to RUN_CYCLES-1 loop wait until rising_edge(clk); end loop;
        t1 := now;
        b1 := to_integer(tx_beats);
        run <= '0';

        for i in 0 to 1999 loop wait until rising_edge(clk); end loop;

        gbps := real((b1-b0) * DATA_W) /
                (real((t1-t0)/1 ps) / 1000.0);
        if raw_beats /= 0 then
            fpb := real(to_integer(m_rx_frames)) / real(raw_beats);
        else
            fpb := 0.0;
        end if;

        write(L, string'("")); writeline(output, L);
        write(L, string'("====================================================="));
        writeline(output, L);
        write(L, string'(" 400G LOOPBACK  -  VHDL")); writeline(output, L);
        write(L, string'("====================================================="));
        writeline(output, L);
        write(L, string'(" frame size          : ")); write(L, FRAME_LEN);
        write(L, string'(" bytes")); writeline(output, L);
        write(L, string'(" gap segments        : ")); write(L, GAP_SEGS);
        writeline(output, L);
        write(L, string'(" TX stall rate       : ")); write(L, STALL_RATE);
        writeline(output, L);
        write(L, string'(" algo latency (X)    : ")); write(L, ALGO_LATENCY);
        writeline(output, L);
        write(L, string'("-----------------------------------------------------"));
        writeline(output, L);
        write(L, string'(" frames received     : "));
        write(L, to_integer(m_rx_frames)); writeline(output, L);
        write(L, string'(" frames flagged bad  : "));
        write(L, to_integer(m_bad_frames)); writeline(output, L);
        write(L, string'(" frames dropped      : "));
        write(L, to_integer(dropped_frames)); writeline(output, L);
        write(L, string'(" beats rx raw        : ")); write(L, raw_beats);
        writeline(output, L);
        write(L, string'(" beats accepted / tx : "));
        write(L, to_integer(rx_beats)); write(L, string'(" / "));
        write(L, to_integer(tx_beats)); writeline(output, L);
        write(L, string'(" frames per beat     : "));
        write(L, fpb, right, 6, 3); writeline(output, L);
        write(L, string'(" fifo overflow beats : "));
        write(L, to_integer(ovf_beats)); writeline(output, L);
        write(L, string'("-----------------------------------------------------"));
        writeline(output, L);
        write(L, string'(" DATA MISMATCHES     : ")); write(L, mismatch);
        writeline(output, L);
        write(L, string'(" TX protocol viol.   : "));
        write(L, to_integer(m_viol)); writeline(output, L);
        write(L, string'(" interface rate      : "));
        write(L, gbps, right, 7, 1);
        write(L, string'(" Gbps of 425")); writeline(output, L);
        write(L, string'("====================================================="));
        writeline(output, L);
        if mismatch = 0 and m_viol = 0 and (b1-b0) /= 0 then
            write(L, string'(" PASS"));
        else
            write(L, string'(" FAIL"));
        end if;
        writeline(output, L);
        write(L, string'("====================================================="));
        writeline(output, L);

        sim_done <= true;
        wait;
    end process;

end architecture sim;
