================================================================================
 400G ETHERNET ENCRYPTOR DATAPATH  -  VHDL-2008
 Agilex 7 F-Tile Ethernet Hard IP, MAC segmented client interface
 Reference: UG 683023 (2026.08.10)
================================================================================

FILES  (compile in this order)
  eth400g_pkg.vhd            constants, types, helpers
  ftile_eth_400g_model.vhd   IP model + TX protocol checker  [SIM ONLY]
  custom_algo.vhd            YOUR ALGORITHM GOES HERE        [SYNTHESISABLE]
  pipe_proc.vhd              pipeline wrapper                [SYNTHESISABLE]
  eth400g_loopback.vhd       the datapath                    [SYNTHESISABLE]
  tb_loopback.vhd            testbench                       [SIM ONLY]

RUN  (GHDL)
  ghdl -a --std=08 eth400g_pkg.vhd ftile_eth_400g_model.vhd custom_algo.vhd \
       pipe_proc.vhd eth400g_loopback.vhd tb_loopback.vhd
  ghdl -e --std=08 tb_loopback
  ghdl -r --std=08 tb_loopback --stop-time=60us

  ModelSim / Questa:
    vcom -2008 eth400g_pkg.vhd ftile_eth_400g_model.vhd custom_algo.vhd \
               pipe_proc.vhd eth400g_loopback.vhd tb_loopback.vhd
    vsim -c tb_loopback -do "run -all; quit"

  QUARTUS PRIME PRO: add the three SYNTHESISABLE files only.
  Requires Agilex 7 device support. Quartus 14 cannot target the device.

================================================================================
 RESULTS
================================================================================
  config                      frames/beat  rate           dropped  mism  viol
  --------------------------  -----------  -------------  -------  ----  ----
  len=64  gap=1               1.778        425.0 (100%)   0        0     0
  len=64  gap=0 (tight)       2.000        425.0 (100%)   0        0     0
  len=1436 gap=1              0.089        425.0 (100%)   0        0     0
  stall=40                    1.778        382.5 ( 90%)   0        0     0
  err=64 drop on              1.778        368.7 ( 87%)   3634     0     0

  3634 frames flagged bad, 3634 dropped - exact. Good frames unaffected.
  106 overflow beats under stall is EXPECTED: RX takes no backpressure
  (UG sec 7.5) and there is no flow-control path, so a full FIFO must drop.
  What matters is mismatch = 0 - drops without corruption.

================================================================================
 WHAT THIS VHDL VERSION ADDS OVER THE VERILOG
================================================================================
 1. RESET AND STATUS SEQUENCING  (UG sec 6.2 / 7.1) - previously missing
    Six reset/ack signals plus eight status signals are modelled:
      i_rst_n, i_tx_rst_n, i_rx_rst_n
      o_rst_ack_n, o_tx_rst_ack_n, o_rx_rst_ack_n
      o_tx_lanes_stable, o_rx_pcs_ready, o_rx_block_lock, o_rx_am_lock,
      o_rx_pcs_fully_aligned, o_local_fault_status,
      o_remote_fault_status, o_rx_hi_ber

    The datapath now GATES on i_tx_lanes_stable. UG Table 43: o_tx_mac_ready
    "indicates the MAC is ready to receive data in normal operational mode
    (i.e. After the o_tx_lanes_stable has asserted)". Driving TX before this
    is the most common cause of a link that never comes up.

    UG warns the TX/RX ack ordering "is not guaranteed" - do NOT build logic
    that depends on their relative order.

 2. MAC OPTION PARAMETERS from the UG
      RX_MAX_FRAME / TX_MAX_FRAME  65..65535, default 1518
                                   -> JUMBO IS A PARAMETER, not a redesign
      ENFORCE_MAX                  truncates oversized, flags oversize+FCS
      RX_STRIP                     None / CRC / CRC+PAD
                                   -> decides what you actually encrypt
      AVG_IPG                      1 / 8 / 10 / 12
                                   -> below 12 the IP is off-spec but faster

 3. FULL RX ERROR AND STATUS ENCODING  (UG Table 46)
      error  2 bits/seg: 0 none, 1 malformed, 2 under/oversize, 3 payload len
      status 3 bits/seg: VLAN, SVLAN, PFC, broadcast/multicast, illegal len...

 4. TUNNEL OVERHEAD CONSTANTS
      IP 20 + UDP 8 + IV 16 + hash 20 = 64 bytes = 8 SEGMENTS EXACTLY.
      Segment-aligned, so header insertion is pure rewiring - no byte-granular
      barrel shifter across 1024 bits at 415 MHz. Protect this alignment.

================================================================================
 TWO BUGS FOUND WHILE PORTING  (both would have shipped)
================================================================================
 1. unsigned * unsigned returns the SUM of the operand widths.
    to_unsigned(k,64) * x"0123..." is 128 bits, so the round-constant
    function returned 128 bits and every xor failed on width. VHDL's strong
    typing caught this at elaboration; Verilog would have silently truncated.

 2. Uninitialised RAM produced metavalues reaching to_integer at time zero.
    Harmless in simulation but it indicates an unreset read path.

================================================================================
 SETTINGS  (all at the top of tb_loopback.vhd)
================================================================================
  FRAME_LEN     every frame exactly this many bytes
  GAP_SEGS      idle segments between frames
                  0 = tight packing (inframe = ffff), max throughput
                  >=1 REQUIRED for DROP to resolve frame boundaries
  STALL_RATE    0 = never stall, 40 = stalls often
  ERR_RATE      0 = none, 64 = ~25% of frames flagged bad
  DROP_ON_ERR   '1' = remove errored frames
  ALGO_LATENCY  your X. Any value - throughput is unaffected.
  RX_MAX_FRAME  1518, or 9000 for jumbo (then DROP_DELAY must be >= 80)
  AVG_IPG       12 = standard, 1 = maximum throughput but off-spec

  A beat is 128 bytes (16 seg x 8 B):
      frames per beat = 16 / (ceil(FRAME_LEN/8) + GAP_SEGS)

================================================================================
 THE FIVE DESIGN POINTS
================================================================================
 1. NO PACKET LAYER. Two frames per beat is routine at 64 B. The datapath
    replays beats verbatim; framing is opaque sideband. The drop stage is the
    one exception - see the assumption below.

 2. TX IS A FIXED-LATENCY PAUSE INTERFACE, not ready/valid. valid is ready
    DELAYED. An idle beat is inframe=0, NOT valid=0. The 'Ready latency' IP
    parameter (0-3) has NO EFFECT in MAC segmented mode - the 1-7 spacing is
    a latency YOU choose and hold.

 3. LATENCY-AGNOSTIC. II=1; latency is a GENERIC; every register gated by the
    same enable; no backpressure output from the algorithm. Throughput is
    independent of frame size AND of algorithm latency.

 4. SINGLE CLOCK - required, not a simplification. 'Enable asynchronous
    adapter clocks' is available only for MAC Avalon ST, so in MAC segmented
    mode i_clk_tx and i_clk_rx must both come from o_clk_pll.

 5. REGISTERED FIFO READ with ramstyle M20K. An async read infers ~896 MLABs
    at this width, built from ALMs - it will not close 415 MHz.

================================================================================
 >>> ASSUMPTION - VERIFY BEFORE HARDWARE <<<
================================================================================
 DROP resolves frame boundaries from inframe 1->0 transitions.

 UG sec 7.4 mandates tight packing with no idle segments, under which inframe
 would stay high across a frame boundary. But that mandate is about what YOU
 DRIVE ON TX. On RX the IP delivers what arrived on the wire, and Ethernet
 always carries an IPG (minimum 8 octets = 1 segment), so RX should always
 show at least one idle segment between frames.

 THIS IS AN INFERENCE FROM THE IPG REQUIREMENT, NOT A QUOTATION.

 Supporting evidence: the UG RX waveform draws frames with visible gaps, and
 shows fcs_error pulsing in the SAME segment as that frame's EOP,
 independently per segment - which is what the per-segment tag lookup relies
 on so a good frame sharing a beat with a bad one survives.

 Run with GAP_SEGS >= 1 when drop is enabled. If RX really does pack with
 zero gap, only DROP is affected - the rest is frame-agnostic.

================================================================================
 STILL NOT COVERED
================================================================================
 Header insertion (ETH/IP/UDP/IV/hash) - the encryptor proper
 PAUSE/PFC flow control, statistics/CSR, PTP/TOD
 PMA, PCS, RS-FEC (KP4), AN/LT, link training
 Whether YOUR algorithm closes timing at 415 MHz - synthesise to find out
