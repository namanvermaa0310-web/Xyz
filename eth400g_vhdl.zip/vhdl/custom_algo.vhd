--=============================================================================
-- custom_algo.vhd
--
--  PLACEHOLDER FOR YOUR CUSTOM ENCRYPTION ALGORITHM.
--  This is the ONLY file you replace. Everything around it is written so
--  that replacing it changes nothing else.
--
--  SYNTHESISABLE - targets Agilex 7.
--
--=============================================================================
--  THE CONTRACT - all four are mandatory
--=============================================================================
--  1. INITIATION INTERVAL = 1
--     One 1024-bit beat in, one out, EVERY cycle that i_en is '1'.
--     No internal stall. No "busy for N cycles then resume".
--
--  2. FIXED KNOWN LATENCY = the LATENCY generic
--     Output for beat N appears exactly LATENCY cycles after acceptance.
--     Any value. Nothing outside this file needs to know it - the wrapper
--     re-aligns the sideband automatically.
--
--  3. EVERY REGISTER GATED BY i_en
--     When i_en is '0' the whole algorithm freezes. This is how the MAC's
--     TX pause propagates backwards without losing data.
--
--  4. NO BACKPRESSURE OUTPUT
--     No ready, no busy, no stall. If the algorithm can ever say "not now",
--     downstream logic starts depending on its timing again and the
--     latency-agnostic property collapses.
--
--=============================================================================
--  WHY THIS MATTERS AT 400G - IT IS NOT THE SAME AS AT 100G
--=============================================================================
--  A 100G design with a 512-bit datapath at 390.625 MHz has 200 Gb/s of
--  capacity for 100 Gb/s of traffic: 50% idle. Crypto latency can hide in
--  the idle cycles, which is exactly why throughput there depends on frame
--  size and why ~1200 bytes is the observed threshold.
--
--  At 400G the MAC interface runs 1024 b x 415.0390625 MHz = 425 Gb/s for
--  400 Gb/s of payload: about 6% idle. Hiding even 17 cycles that way would
--  need a ~35 kB frame - larger than jumbo. It is not a tuning problem, it
--  is arithmetically impossible at any legal frame size.
--
--  With II=1 the question disappears: LATENCY frames are in flight at once,
--  throughput is independent of frame size, and latency costs only buffering.
--      LATENCY 17  -> 2.1 kB in flight,  41 ns added, throughput unchanged
--      LATENCY 100 -> 12.5 kB in flight, 241 ns added, throughput unchanged
--
--=============================================================================
--  IF YOUR ALGORITHM CANNOT BE MADE II=1
--=============================================================================
--  That is an ALGORITHM property, not an implementation one. If round N+1
--  needs round N's OUTPUT rather than a pipelined intermediate, no amount of
--  RTL effort gives you II=1.
--
--  Check this in the algorithm spec BEFORE writing more RTL. Fallbacks:
--    - restructure to remove the recurrence, or
--    - instantiate K copies round-robin, K = recurrence length, so the
--      AGGREGATE initiation interval is 1. Costs K times the area.
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.eth400g_pkg.all;

entity custom_algo is
    generic (
        LATENCY : positive := 17        -- your X. Any value.
    );
    port (
        clk      : in  std_logic;
        rst_n    : in  std_logic;
        i_en     : in  std_logic;       -- freeze when '0'
        i_plain  : in  std_logic_vector(DATA_W-1 downto 0);
        o_cipher : out std_logic_vector(DATA_W-1 downto 0)
    );
end entity custom_algo;

architecture rtl of custom_algo is

    type stage_arr_t is array (0 to LATENCY-1)
        of std_logic_vector(DATA_W-1 downto 0);
    signal stage : stage_arr_t := (others => (others => '0'));

    -- Per-stage round constant so successive stages are not identical logic
    -- NOTE: unsigned * unsigned returns the SUM of the operand widths, so
    -- the product must be resized back to SEG_W before it is used. Without
    -- the resize this returns 128 bits and every xor below fails on width.
    function rc(k : natural) return std_logic_vector is
        constant base : unsigned(SEG_W-1 downto 0) := x"9E3779B97F4A7C15";
        constant mul  : unsigned(SEG_W-1 downto 0) := x"0123456789ABCDEF";
        variable prod : unsigned(2*SEG_W-1 downto 0);
    begin
        prod := to_unsigned(k, SEG_W) * mul;
        return std_logic_vector(base + resize(prod(SEG_W-1 downto 0), SEG_W));
    end function;

begin

    --=========================================================================
    -- PLACEHOLDER IMPLEMENTATION
    --
    -- A LATENCY-deep pipeline doing real per-segment work each stage, so ALM
    -- usage and timing are representative rather than a pass-through.
    -- Replace the body. Keep the ports. Keep i_en on every register.
    --=========================================================================
    proc_pipe : process(clk)
        variable rot : std_logic_vector(SEG_W-1 downto 0);
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                stage <= (others => (others => '0'));
            elsif i_en = '1' then
                -- Stage 0
                for s in 0 to NUM_SEG-1 loop
                    stage(0)(s*SEG_W+SEG_W-1 downto s*SEG_W) <=
                        i_plain(s*SEG_W+SEG_W-1 downto s*SEG_W) xor rc(0);
                end loop;

                -- Stages 1 .. LATENCY-1 : rotate then XOR a round constant
                for k in 1 to LATENCY-1 loop
                    for s in 0 to NUM_SEG-1 loop
                        rot := stage(k-1)(s*SEG_W+SEG_W-2 downto s*SEG_W) &
                               stage(k-1)(s*SEG_W+SEG_W-1);
                        stage(k)(s*SEG_W+SEG_W-1 downto s*SEG_W) <=
                            rot xor rc(k);
                    end loop;
                end loop;
            end if;
        end if;
    end process;

    o_cipher <= stage(LATENCY-1);

end architecture rtl;
