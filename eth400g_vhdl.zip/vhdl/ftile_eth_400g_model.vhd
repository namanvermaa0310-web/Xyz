--=============================================================================
-- ftile_eth_400g_model.vhd
--
--  BEHAVIOURAL MODEL of the Agilex 7 F-Tile Ethernet Hard IP, 400GE-8,
--  MAC SEGMENTED client interface.
--
--  SIMULATION ONLY. Delete this and instantiate the licensed IP when
--  available; the datapath connects to the same signal names.
--
--  Reference: F-Tile Ethernet Hard IP User Guide, doc 683023 (2026.08.10)
--
--=============================================================================
--  IP FEATURES MODELLED  (and the UG section each comes from)
--=============================================================================
--   sec 5    Clocks           415.0390625 MHz MAC datapath clock
--   sec 6.2  Reset sequence   12-step bring-up, 6 reset/ack signals
--   sec 7.1  Status           tx_lanes_stable, rx_pcs_ready, block_lock,
--                             am_lock, pcs_fully_aligned, local/remote fault
--   sec 7.4  TX segmented     fixed-latency PAUSE protocol, tight packing,
--                             skip_crc, tx error
--   sec 7.5  RX segmented     no backpressure, per-segment inframe /
--                             eop_empty / fcs_error / error / status
--   MAC opts TX/RX max frame size (65..65535), enforce max frame size,
--            bytes to remove from RX frames, average IPG, VLAN detection
--
--=============================================================================
--  KEY INTERFACE SEMANTICS
--=============================================================================
--  The MAC segmented interface does NOT use sop/eop strobes. It uses
--  INFRAME + EOP_EMPTY:
--
--    *_inframe(s)     '1' = segment s is inside a frame
--                     SOP = inframe 0 -> 1 between consecutive segments
--                     EOP = inframe 1 -> 0 between consecutive segments
--    *_eop_empty(s)   unused bytes in segment s, valid only at EOP
--
--  UG sec 7.5: "Packets may start on any 8-byte segment. For multisegmented
--  interfaces, a new packet may start and the previous packet end are within
--  the same cycle."
--
--  At 400G a beat is 128 bytes and the minimum frame is 64 bytes, so TWO
--  complete frames land in ONE cycle routinely. Not a corner case.
--
--  TX IS A FIXED-LATENCY PAUSE INTERFACE, NOT READY/VALID (UG sec 7.4):
--    "i_tx_mac_valid asserts only when o_tx_mac_ready is asserted, even
--     though there is no packet to send"
--    "...can be spaced by a fixed latency between 1 to 7 clock cycles"
--    "When i_tx_mac_valid deasserts, [all TX signals] must be paused for as
--     many cycles as o_tx_mac_ready is deasserted"
--
--  NOTE: the 'Ready latency' IP PARAMETER (range 0-3) has NO EFFECT in MAC
--  segmented mode. The 1-7 cycle spacing is a latency YOU choose and hold
--  consistently, not something configured in the IP.
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.eth400g_pkg.all;

entity ftile_eth_400g_model is
    generic (
        -- TX pause spacing you have chosen to implement. Legal 1..7.
        READY_LATENCY : natural range 1 to 7 := 3;

        -- UG MAC options. Jumbo is a PARAMETER: range 65..65535.
        RX_MAX_FRAME  : natural := DEF_MAX_FRAME;
        TX_MAX_FRAME  : natural := DEF_MAX_FRAME;
        ENFORCE_MAX   : boolean := false;   -- truncate oversized, flag error
        RX_STRIP      : rx_strip_t := STRIP_CRC;

        -- 'Average inter-packet gap': 1, 8, 10 or 12. Default 12 is standard.
        -- UG warns values below 12 mean "the IP core no longer complies with
        -- the Ethernet standard" - it buys throughput at small frame sizes.
        AVG_IPG       : natural range 1 to 12 := 12;

        -- Traffic generation (NOT IP features - model control only)
        MIN_LEN       : natural := MIN_ETH_FRAME;
        MAX_LEN       : natural := DEF_MAX_FRAME;
        SEED          : natural := 12345
    );
    port (
        --=====================================================================
        -- CLOCKS  (UG sec 5)
        -- In MAC segmented mode i_clk_tx and i_clk_rx MUST come from
        -- o_clk_pll. 'Enable asynchronous adapter clocks' is available only
        -- for MAC Avalon ST, so these cannot be independent here.
        --=====================================================================
        i_clk_tx        : in  std_logic;
        i_clk_rx        : in  std_logic;

        --=====================================================================
        -- RESETS  (UG sec 6.2)
        --=====================================================================
        i_rst_n         : in  std_logic;   -- full IP reset
        i_tx_rst_n      : in  std_logic;   -- TX datapath reset
        i_rx_rst_n      : in  std_logic;   -- RX datapath reset

        o_rst_ack_n     : out std_logic;
        o_tx_rst_ack_n  : out std_logic;
        o_rx_rst_ack_n  : out std_logic;

        --=====================================================================
        -- STATUS  (UG sec 7.1)   all asynchronous on the real IP
        --=====================================================================
        o_tx_lanes_stable    : out std_logic;
        o_rx_pcs_ready       : out std_logic;
        o_rx_block_lock      : out std_logic;
        o_rx_am_lock         : out std_logic;
        o_rx_pcs_fully_aligned : out std_logic;
        o_local_fault_status   : out std_logic;
        o_remote_fault_status  : out std_logic;
        o_rx_hi_ber            : out std_logic;

        --=====================================================================
        -- MODEL CONTROL - NONE OF THESE EXIST ON THE REAL IP
        --=====================================================================
        i_gen_enable    : in  std_logic;
        i_force_len     : in  unsigned(15 downto 0);  -- 0 = pseudo-random
        i_gap_segs      : in  unsigned(2 downto 0);   -- idle segs between frames
        i_err_rate      : in  unsigned(7 downto 0);   -- 0 = none, 255 = all
        i_tx_stall_rate : in  unsigned(7 downto 0);   -- ready deassert rate

        --=====================================================================
        -- RX MAC SEGMENTED CLIENT  (IP -> user).  Takes NO backpressure.
        --=====================================================================
        o_rx_mac_data        : out std_logic_vector(DATA_W-1 downto 0);
        o_rx_mac_valid       : out std_logic;
        o_rx_mac_inframe     : out std_logic_vector(NUM_SEG-1 downto 0);
        o_rx_mac_eop_empty   : out std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
        o_rx_mac_fcs_error   : out std_logic_vector(NUM_SEG-1 downto 0);
        o_rx_mac_error       : out std_logic_vector(NUM_SEG*ERR_W-1 downto 0);
        o_rx_mac_status_data : out std_logic_vector(NUM_SEG*STAT_W-1 downto 0);

        --=====================================================================
        -- TX MAC SEGMENTED CLIENT  (user -> IP)
        --=====================================================================
        i_tx_mac_data        : in  std_logic_vector(DATA_W-1 downto 0);
        i_tx_mac_valid       : in  std_logic;
        i_tx_mac_inframe     : in  std_logic_vector(NUM_SEG-1 downto 0);
        i_tx_mac_eop_empty   : in  std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
        i_tx_mac_error       : in  std_logic_vector(NUM_SEG-1 downto 0);
        i_tx_mac_skip_crc    : in  std_logic_vector(NUM_SEG-1 downto 0);
        o_tx_mac_ready       : out std_logic;

        --=====================================================================
        -- MODEL OBSERVATION - not on the real IP
        --=====================================================================
        o_model_rx_frames  : out unsigned(31 downto 0);
        o_model_bad_frames : out unsigned(31 downto 0);
        o_model_proto_viol : out unsigned(31 downto 0)
    );
end entity ftile_eth_400g_model;


architecture behav of ftile_eth_400g_model is

    --=========================================================================
    -- RESET / STATUS SEQUENCING  (UG sec 6.2)
    --
    -- Bringing the IP out of reset:
    --   1. drive i_rst_n high WHILE i_tx_rst_n and i_rx_rst_n are already
    --      deasserted
    --   2. o_rst_ack_n deasserts. UG: "this step doesn't indicate that the IP
    --      core is in fully functional state". o_tx_rst_ack_n and
    --      o_rx_rst_ack_n also deassert but UG: "the exact sequence and
    --      timing is not guaranteed" - do NOT build logic that depends on
    --      their relative order.
    --   3. IP fully out of reset: o_tx_lanes_stable and o_rx_pcs_ready assert
    --
    -- Your datapath must NOT drive TX until o_tx_lanes_stable is high.
    -- UG Table 43: o_tx_mac_ready "indicates the MAC is ready to receive data
    -- in normal operational mode (i.e. After the o_tx_lanes_stable has
    -- asserted)."
    --=========================================================================
    constant RST_ACK_CYC   : natural := 8;    -- i_rst_n high -> o_rst_ack_n low
    constant LANE_CYC      : natural := 24;   -- -> tx_lanes_stable
    constant PCS_CYC       : natural := 32;   -- -> rx_pcs_ready, alignment

    signal rst_cnt     : natural range 0 to 63 := 0;
    signal tx_cnt      : natural range 0 to 63 := 0;
    signal rx_cnt      : natural range 0 to 63 := 0;

    signal s_rst_ack_n : std_logic := '0';
    signal s_lanes     : std_logic := '0';
    signal s_pcs_rdy   : std_logic := '0';

    --=========================================================================
    -- Pseudo-random source
    --=========================================================================
    signal lfsr     : unsigned(31 downto 0) := to_unsigned(SEED, 32);
    signal bp_lfsr  : unsigned(7 downto 0)  := x"5A";
    signal err_lfsr : unsigned(7 downto 0)  := x"C3";

    --=========================================================================
    -- RX generator state
    --=========================================================================
    signal rx_seq    : unsigned(31 downto 0) := (others => '0');
    signal rx_len    : natural := MIN_ETH_FRAME;
    signal rx_off    : natural := 0;
    signal rx_active : boolean := false;
    signal gap_cnt   : natural := 0;
    signal ipg_cnt   : natural := 0;

    --=========================================================================
    -- TX protocol checker state
    --=========================================================================
    signal rdy_pipe   : std_logic_vector(7 downto 0) := (others => '0');
    signal tx_d_hold  : std_logic_vector(DATA_W-1 downto 0) := (others => '0');
    signal tx_if_hold : std_logic_vector(NUM_SEG-1 downto 0) := (others => '0');
    signal have_hold  : boolean := false;
    signal settle     : natural range 0 to 255 := 0;

    -- VHDL-93: out ports cannot be read, so count internally
    constant ZERO16 : std_logic_vector(NUM_SEG-1 downto 0) := (others => '0');
    signal cnt_frames : unsigned(31 downto 0) := (others => '0');
    signal cnt_bad    : unsigned(31 downto 0) := (others => '0');
    signal cnt_viol   : unsigned(31 downto 0) := (others => '0');
    signal tx_ready_i : std_logic := '0';

    --=========================================================================
    -- Frame content generator
    --
    -- [ 6B DA ][ 6B SA ][ 2B len/type ][ 4B seq ][ payload pattern ]
    -- The sequence number lets a checker detect drops, duplication and
    -- reordering independently of payload corruption.
    --=========================================================================
    function frame_byte(idx : natural; sq : unsigned) return std_logic_vector is
    begin
        case idx is
            when 0|1|2|3|4|5 => return x"FF";                 -- DA broadcast
            when 6           => return x"00";                 -- SA
            when 7           => return x"1A";
            when 8           => return x"2B";
            when 9           => return x"3C";
            when 10          => return x"4D";
            when 11          => return x"5E";
            when 12          => return x"08";                 -- Length/Type hi
            when 13          => return x"00";                 -- Length/Type lo
            when 14          => return std_logic_vector(sq(31 downto 24));
            when 15          => return std_logic_vector(sq(23 downto 16));
            when 16          => return std_logic_vector(sq(15 downto 8));
            when 17          => return std_logic_vector(sq(7 downto 0));
            when others      =>
                return std_logic_vector(
                         to_unsigned(idx mod 256, 8) xor sq(7 downto 0));
        end case;
    end function;

    -- Effective frame length after 'Bytes to remove from RX frames'
    function stripped_len(len : natural) return natural is
    begin
        case RX_STRIP is
            when STRIP_NONE    => return len;          -- FCS kept
            when STRIP_CRC     => return len - 4;      -- FCS removed
            when STRIP_CRC_PAD =>                      -- FCS and padding
                if len <= MIN_ETH_FRAME then
                    return MIN_ETH_FRAME - 4;
                else
                    return len - 4;
                end if;
        end case;
    end function;

begin

    o_model_rx_frames  <= cnt_frames;
    o_model_bad_frames <= cnt_bad;
    o_model_proto_viol <= cnt_viol;
    o_tx_mac_ready     <= tx_ready_i;

    --=========================================================================
    -- RESET AND STATUS SEQUENCING
    --=========================================================================
    reset_seq : process(i_clk_rx)
    begin
        if rising_edge(i_clk_rx) then
            if i_rst_n = '0' then
                rst_cnt     <= 0;
                s_rst_ack_n <= '0';
            elsif rst_cnt < RST_ACK_CYC then
                rst_cnt     <= rst_cnt + 1;
            else
                s_rst_ack_n <= '1';          -- IP no longer in full reset
            end if;

            -- TX datapath
            if i_rst_n = '0' or i_tx_rst_n = '0' then
                tx_cnt   <= 0;
                s_lanes  <= '0';
            elsif s_rst_ack_n = '1' and tx_cnt < LANE_CYC then
                tx_cnt   <= tx_cnt + 1;
            elsif tx_cnt >= LANE_CYC then
                s_lanes  <= '1';             -- TX lanes stable
            end if;

            -- RX datapath
            if i_rst_n = '0' or i_rx_rst_n = '0' then
                rx_cnt    <= 0;
                s_pcs_rdy <= '0';
            elsif s_rst_ack_n = '1' and rx_cnt < PCS_CYC then
                rx_cnt    <= rx_cnt + 1;
            elsif rx_cnt >= PCS_CYC then
                s_pcs_rdy <= '1';            -- RX PCS ready
            end if;
        end if;
    end process;

    o_rst_ack_n    <= s_rst_ack_n;
    -- UG: the exact sequence and timing of the TX/RX acks is NOT guaranteed.
    o_tx_rst_ack_n <= s_rst_ack_n;
    o_rx_rst_ack_n <= s_rst_ack_n;

    o_tx_lanes_stable      <= s_lanes;
    o_rx_pcs_ready         <= s_pcs_rdy;
    o_rx_block_lock        <= s_pcs_rdy;
    o_rx_am_lock           <= s_pcs_rdy;
    o_rx_pcs_fully_aligned <= s_pcs_rdy;
    o_local_fault_status   <= not s_pcs_rdy;
    o_remote_fault_status  <= '0';
    o_rx_hi_ber            <= '0';

    --=========================================================================
    -- LFSRs
    --=========================================================================
    rng : process(i_clk_rx)
    begin
        if rising_edge(i_clk_rx) then
            if i_rst_n = '0' then
                lfsr     <= to_unsigned(SEED, 32);
                err_lfsr <= x"C3";
            else
                lfsr     <= lfsr(30 downto 0) &
                            (lfsr(31) xor lfsr(21) xor lfsr(1) xor lfsr(0));
                err_lfsr <= err_lfsr(6 downto 0) &
                            (err_lfsr(7) xor err_lfsr(5));
            end if;
        end if;
    end process;

    --=========================================================================
    -- RX TRAFFIC GENERATOR
    --
    -- Frames are packed TIGHTLY by default (i_gap_segs = 0), which is the
    -- maximum-throughput case UG sec 7.4 mandates for TX. Setting i_gap_segs
    -- >= 1 produces beats where inframe has HOLES, matching the loosely
    -- packed case drawn in the UG RX waveform. Both are legal RX streams and
    -- a datapath must survive either.
    --=========================================================================
    rx_gen : process(i_clk_rx)
        variable v_data  : std_logic_vector(DATA_W-1 downto 0);
        variable v_if    : std_logic_vector(NUM_SEG-1 downto 0);
        variable v_empty : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
        variable v_fcs   : std_logic_vector(NUM_SEG-1 downto 0);
        variable v_err   : std_logic_vector(NUM_SEG*ERR_W-1 downto 0);
        variable v_stat  : std_logic_vector(NUM_SEG*STAT_W-1 downto 0);
        variable v_len   : natural;
        variable v_off   : natural;
        variable v_seq   : unsigned(31 downto 0);
        variable v_act   : boolean;
        variable v_gap   : natural;
        variable v_nf    : natural;
        variable v_nbad  : natural;
        variable v_eff   : natural;
        variable bad     : boolean;
        variable oversz  : boolean;
        variable b       : natural;
    begin
        if rising_edge(i_clk_rx) then
            if i_rst_n = '0' or i_rx_rst_n = '0' then
                o_rx_mac_data        <= (others => '0');
                o_rx_mac_valid       <= '0';
                o_rx_mac_inframe     <= (others => '0');
                o_rx_mac_eop_empty   <= (others => '0');
                o_rx_mac_fcs_error   <= (others => '0');
                o_rx_mac_error       <= (others => '0');
                o_rx_mac_status_data <= (others => '0');
                rx_seq    <= (others => '0');
                rx_len    <= MIN_ETH_FRAME;
                rx_off    <= 0;
                rx_active <= false;
                gap_cnt   <= 0;
                ipg_cnt   <= 0;
                cnt_frames <= (others => '0');
                cnt_bad    <= (others => '0');

            -- Traffic only after the RX datapath reports ready.
            elsif s_pcs_rdy = '1' and (i_gen_enable = '1' or rx_active) then

                v_data  := (others => '0');
                v_if    := (others => '0');
                v_empty := (others => '0');
                v_fcs   := (others => '0');
                v_err   := (others => '0');
                v_stat  := (others => '0');
                v_len   := rx_len;
                v_off   := rx_off;
                v_seq   := rx_seq;
                v_act   := rx_active;
                v_gap   := gap_cnt;
                v_nf    := 0;
                v_nbad  := 0;

                for s in 0 to NUM_SEG-1 loop
                    if v_gap /= 0 then
                        -- idle segment between frames: inframe stays '0',
                        -- leaving a hole in the beat
                        v_gap := v_gap - 1;
                    else
                        if not v_act then
                            if i_gen_enable = '1' then
                                if i_force_len /= 0 then
                                    v_len := to_integer(i_force_len);
                                else
                                    v_len := MIN_LEN +
                                        (to_integer(lfsr(15 downto 0))
                                         mod (MAX_LEN - MIN_LEN + 1));
                                end if;
                                v_off := 0;
                                v_act := true;
                            end if;
                        end if;

                        if v_act then
                            -- 'Bytes to remove from RX frames' applies to what
                            -- the client sees, not to what was on the wire.
                            v_eff := stripped_len(v_len);

                            for k in 0 to SEG_B-1 loop
                                b := v_off + k;
                                if b < v_eff then
                                    v_data((s*SEG_B+k)*8+7 downto (s*SEG_B+k)*8)
                                        := frame_byte(b, v_seq);
                                end if;
                            end loop;

                            v_if(s) := '1';

                            if (v_off + SEG_B) >= v_eff then
                                -- EOP in this segment
                                v_empty(s*EMPTY_W+EMPTY_W-1 downto s*EMPTY_W)
                                    := std_logic_vector(to_unsigned(
                                         SEG_B - (v_eff - v_off), EMPTY_W));

                                -- Error injection. UG Table 46: error and
                                -- fcs_error are valid on EOP segments.
                                bad := (i_err_rate /= 0) and
                                       (err_lfsr < i_err_rate);

                                -- 'Enforce maximum frame size': the IP
                                -- truncates oversized packets and the error
                                -- signal indicates oversize AND FCS error.
                                oversz := ENFORCE_MAX and (v_len > RX_MAX_FRAME);

                                if oversz then
                                    v_fcs(s) := '1';
                                    v_err(s*ERR_W+ERR_W-1 downto s*ERR_W)
                                        := RXERR_SIZE;
                                    v_nbad := v_nbad + 1;
                                elsif bad then
                                    v_fcs(s) := '1';
                                    v_err(s*ERR_W+ERR_W-1 downto s*ERR_W)
                                        := RXERR_MALFORM;
                                    v_nbad := v_nbad + 1;
                                end if;

                                -- Status: broadcast DA in this generator
                                v_stat(s*STAT_W+STAT_W-1 downto s*STAT_W)
                                    := RXSTAT_BCAST_MC;

                                v_seq := v_seq + 1;
                                v_nf  := v_nf + 1;
                                v_act := false;
                                v_off := 0;
                                v_gap := to_integer(i_gap_segs);
                            else
                                v_off := v_off + SEG_B;
                            end if;
                        end if;
                    end if;
                end loop;

                o_rx_mac_data        <= v_data;
                o_rx_mac_inframe     <= v_if;
                o_rx_mac_eop_empty   <= v_empty;
                o_rx_mac_fcs_error   <= v_fcs;
                o_rx_mac_error       <= v_err;
                o_rx_mac_status_data <= v_stat;

                -- 'Average inter-packet gap': below 12 the IP no longer
                -- complies with the Ethernet standard but throughput rises,
                -- most noticeably at small frame sizes.
                if ipg_cnt /= 0 then
                    o_rx_mac_valid <= '0';
                    ipg_cnt        <= ipg_cnt - 1;
                else
                    if v_if = ZERO16 then
                        o_rx_mac_valid <= '0';
                    else
                        o_rx_mac_valid <= '1';
                    end if;
                end if;

                rx_len    <= v_len;
                rx_off    <= v_off;
                rx_seq    <= v_seq;
                rx_active <= v_act;
                gap_cnt   <= v_gap;

                cnt_frames <= cnt_frames + v_nf;
                cnt_bad    <= cnt_bad    + v_nbad;

            else
                o_rx_mac_valid   <= '0';
                o_rx_mac_inframe <= (others => '0');
            end if;
        end if;
    end process;

    --=========================================================================
    -- TX READY GENERATOR
    --
    -- o_tx_mac_ready IS a real IP output (UG Table 43) and the pause protocol
    -- it drives IS documented (UG sec 7.4). But the RATE and PATTERN of
    -- stalling are NOT specified anywhere in the UG. The LFSR below is an
    -- arbitrary stress pattern - useful for proving the datapath survives
    -- frequent stalls, NOT a prediction of real IP behaviour.
    --
    -- Ready is gated on o_tx_lanes_stable, per UG Table 43.
    --=========================================================================
    tx_ready_gen : process(i_clk_tx)
    begin
        if rising_edge(i_clk_tx) then
            if i_rst_n = '0' or i_tx_rst_n = '0' then
                bp_lfsr        <= x"5A";
                tx_ready_i <= '0';
            else
                bp_lfsr <= bp_lfsr(6 downto 0) &
                           (bp_lfsr(7) xor bp_lfsr(5));
                if s_lanes = '0' then
                    tx_ready_i <= '0';
                elsif i_tx_stall_rate = 0 then
                    tx_ready_i <= '1';
                elsif bp_lfsr > i_tx_stall_rate then
                    tx_ready_i <= '1';
                else
                    tx_ready_i <= '0';
                end if;
            end if;
        end if;
    end process;

    --=========================================================================
    -- TX PROTOCOL CHECKER
    --
    -- Enforces UG sec 7.4:
    --   valid must equal ready delayed by exactly READY_LATENCY, and the bus
    --   must freeze while valid is deasserted.
    --
    -- A model that only supplies stimulus lets protocol bugs through
    -- silently. This one catches them.
    --=========================================================================
    tx_check : process(i_clk_tx)
        variable exp_valid : std_logic;
    begin
        if rising_edge(i_clk_tx) then
            if i_rst_n = '0' or i_tx_rst_n = '0' then
                rdy_pipe   <= (others => '0');
                have_hold  <= false;
                settle     <= 0;
                cnt_viol <= (others => '0');
            else
                rdy_pipe <= rdy_pipe(6 downto 0) & tx_ready_i;
                if settle < 255 then
                    settle <= settle + 1;
                end if;

                exp_valid := rdy_pipe(READY_LATENCY-1);

                -- Do not police across reset or before lanes are stable.
                if settle > 64 and s_lanes = '1' then
                    if i_tx_mac_valid /= exp_valid then
                        cnt_viol <= cnt_viol + 1;
                        report "TX PROTOCOL: valid /= ready delayed by " &
                               integer'image(READY_LATENCY)
                               severity warning;
                    end if;

                    if i_tx_mac_valid = '0' and have_hold then
                        if i_tx_mac_data /= tx_d_hold or
                           i_tx_mac_inframe /= tx_if_hold then
                            cnt_viol <= cnt_viol + 1;
                            report "TX PROTOCOL: bus changed while valid low"
                                   severity warning;
                        end if;
                    end if;
                end if;

                if i_tx_mac_valid = '1' then
                    tx_d_hold  <= i_tx_mac_data;
                    tx_if_hold <= i_tx_mac_inframe;
                    have_hold  <= true;
                end if;
            end if;
        end if;
    end process;

end architecture behav;
