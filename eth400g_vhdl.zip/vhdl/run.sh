#!/bin/bash
ghdl -a --std=08 eth400g_pkg.vhd ftile_eth_400g_model.vhd custom_algo.vhd \
     pipe_proc.vhd eth400g_loopback.vhd tb_loopback.vhd 2>/dev/null
ghdl -e --std=08 tb_loopback 2>/dev/null
timeout 300 ghdl -r --std=08 tb_loopback --stop-time=45us 2>/dev/null | grep -v metavalue
