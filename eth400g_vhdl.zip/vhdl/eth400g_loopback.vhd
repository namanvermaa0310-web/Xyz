--=============================================================================
-- eth400g_loopback.vhd
--
--  400G LOOPBACK DATAPATH.  SYNTHESISABLE - targets Agilex 7.
--
--    RX MAC segmented -> frame tag + error drop -> pipe_proc -> FIFO -> TX
--
--  Reference: F-Tile Ethernet Hard IP User Guide, doc 683023, sec 7.4 / 7.5
--
--=============================================================================
-- DESIGN POINT 1 - NO PACKET LAYER
--=============================================================================
-- UG sec 7.5: "Packets may start on any 8-byte segment... a new packet may
-- start and the previous packet end are within the same cycle."
-- UG sec 7.4 (Attention): "the input packets need to be packed tightly,
-- leaving no idle segments in between."
--
-- A beat is 128 bytes; the minimum frame is 64. TWO frames per cycle is
-- routine. Any design holding ONE packet state per beat miscounts and
-- eventually commits truncated frames - it passes light testing and corrupts
-- traffic under load.
--
-- The datapath buffers and replays beats verbatim, carrying inframe /
-- eop_empty / error / skip_crc as opaque sideband. The ONE exception is the
-- drop stage, which must know frame boundaries; see the assumption below.
--
--=============================================================================
-- DESIGN POINT 2 - TX IS A FIXED-LATENCY PAUSE INTERFACE, NOT READY/VALID
--=============================================================================
-- UG sec 7.4: valid asserts whenever ready is asserted "even though there is
-- no packet to send", spaced by a fixed 1-7 cycle latency, and the bus must
-- freeze while valid is low.
--
--   o_tx_mac_valid is i_tx_mac_ready DELAYED. NOT derived from having data.
--   An IDLE BEAT IS inframe=0, NOT valid=0.
--
-- A classic handshake ("out_free = not valid or ready") is the WRONG
-- protocol. It compiles, passes a naive testbench, and fails on silicon.
--
-- NOTE: the 'Ready latency' IP parameter (0-3) has NO EFFECT in MAC
-- segmented mode. READY_LATENCY here is a latency YOU choose and hold.
--
--=============================================================================
-- DESIGN POINT 3 - LATENCY-AGNOSTIC BY CONSTRUCTION
--=============================================================================
-- The algorithm's latency is not under our control and may change. Nothing
-- outside pipe_proc/custom_algo depends on knowing it:
--   II=1, no internal stall; latency is a GENERIC, never a constant;
--   every register gated by the same enable; no backpressure output.
-- Throughput is therefore independent of frame size AND of algorithm latency.
--
--=============================================================================
-- DESIGN POINT 4 - SINGLE CLOCK  (this is required, not a simplification)
--=============================================================================
-- UG: 'Enable asynchronous adapter clocks' is "Available only when Client
-- interface is set to MAC Avalon ST". In MAC SEGMENTED mode i_clk_tx and
-- i_clk_rx MUST both come from o_clk_pll, so they cannot be independent.
-- One clock port is the honest interface; separate ports with unsynchronised
-- pointer comparison would be a latent CDC failure.
--
--=============================================================================
-- DESIGN POINT 5 - REGISTERED FIFO READ (fitting)
--=============================================================================
-- An asynchronous read makes Quartus infer MLAB / distributed LUTRAM. At
-- 1120 bits x 512 deep that is ~896 MLABs, built from ALMs - it will not
-- close 415 MHz. A REGISTERED read infers M20K: ~28 blocks. Cost is one
-- cycle of read latency, absorbed by the output stage.
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;
use work.eth400g_pkg.all;

entity eth400g_loopback is
    generic (
        READY_LATENCY : natural range 1 to 7 := 3;
        FIFO_DEPTH    : positive := 512;
        ALGO_LATENCY  : positive := 17;   -- your X
        PROC_BYPASS   : boolean  := false;

        -- DROP_DELAY must exceed the longest frame's span in beats, or a
        -- frame's first beats leave the delay line before its EOP error
        -- arrives and cannot be retracted.
        --   beats = ceil( (ceil(LEN/8) + GAP) / 16 )
        --     1518 B -> 12 beats  -> 16 is enough
        --     9000 B -> 71 beats  -> JUMBO NEEDS DROP_DELAY 80
        DROP_DELAY    : positive := 16;
        TAG_W         : positive := 6     -- 2**TAG_W > frames in the window
    );
    port (
        clk   : in std_logic;
        rst_n : in std_logic;

        --=====================================================================
        -- Gate from the IP status. UG Table 43: o_tx_mac_ready "indicates the
        -- MAC is ready to receive data in normal operational mode (i.e. After
        -- the o_tx_lanes_stable has asserted)". Driving TX before this is a
        -- common cause of a link that never comes up.
        --=====================================================================
        i_tx_lanes_stable : in std_logic;
        i_rx_pcs_ready    : in std_logic;

        --=====================================================================
        -- RX MAC segmented client (from IP). Takes NO backpressure.
        --=====================================================================
        i_rx_mac_data      : in std_logic_vector(DATA_W-1 downto 0);
        i_rx_mac_valid     : in std_logic;
        i_rx_mac_inframe   : in std_logic_vector(NUM_SEG-1 downto 0);
        i_rx_mac_eop_empty : in std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
        i_rx_mac_fcs_error : in std_logic_vector(NUM_SEG-1 downto 0);
        i_rx_mac_error     : in std_logic_vector(NUM_SEG*ERR_W-1 downto 0);

        --=====================================================================
        -- TX SIDEBAND - INDEPENDENT OF RX
        --
        -- o_tx_mac_error is NOT derived from i_rx_mac_error. They mean
        -- different things:
        --   o_rx_mac_error (2b/seg) CLASSIFIES a received frame
        --   i_tx_mac_error (1b/seg) COMMANDS the MAC to invalidate the frame
        --                           it is transmitting
        -- Forwarding one to the other means "this arrived corrupt, so
        -- transmit it and mark it corrupt" - rarely what an encryptor wants.
        --
        -- skip_crc also disables PADDING and SOURCE ADDRESS INSERTION
        -- (UG Table 40), and makes the MAC use the last 4 bytes of your data
        -- as the CRC instead of calculating one. It becomes a real per-frame
        -- decision once header insertion changes the frame length.
        --=====================================================================
        i_tx_error      : in std_logic_vector(NUM_SEG-1 downto 0);
        i_tx_skip_crc   : in std_logic_vector(NUM_SEG-1 downto 0);
        i_drop_on_error : in std_logic;

        --=====================================================================
        -- TX MAC segmented client (to IP)
        --=====================================================================
        o_tx_mac_data      : out std_logic_vector(DATA_W-1 downto 0);
        o_tx_mac_valid     : out std_logic;
        o_tx_mac_inframe   : out std_logic_vector(NUM_SEG-1 downto 0);
        o_tx_mac_eop_empty : out std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
        o_tx_mac_error     : out std_logic_vector(NUM_SEG-1 downto 0);
        o_tx_mac_skip_crc  : out std_logic_vector(NUM_SEG-1 downto 0);
        i_tx_mac_ready     : in  std_logic;

        --=====================================================================
        -- Status
        --=====================================================================
        o_rx_beats       : out unsigned(31 downto 0);
        o_tx_beats       : out unsigned(31 downto 0);
        o_ovf_beats      : out unsigned(31 downto 0);
        o_dropped_frames : out unsigned(31 downto 0);
        o_fifo_level     : out unsigned(15 downto 0)
    );
end entity eth400g_loopback;


architecture rtl of eth400g_loopback is

    constant ADDR_W  : natural := integer(ceil(log2(real(FIFO_DEPTH))));
    constant SB_W    : natural := NUM_SEG + NUM_SEG*EMPTY_W + NUM_SEG + NUM_SEG;
    constant ENTRY_W : natural := DATA_W + SB_W;
    constant NTAG    : natural := 2**TAG_W;

    --=========================================================================
    -- FRAME TAGGING AND ERROR DROP
    --
    -- >>> ASSUMPTION - VERIFY BEFORE HARDWARE <<<
    --   UG sec 7.4 mandates tight packing with no idle segments, which would
    --   make inframe stay high across a frame boundary and leave no 1->0
    --   transition to mark EOP. But that mandate is about what YOU DRIVE ON
    --   TX for maximum throughput.
    --
    --   On RX the IP delivers what arrived on the wire, and Ethernet always
    --   carries an inter-packet gap (minimum 8 octets = 1 segment), so RX
    --   should always show at least one idle segment between frames, making
    --   an inframe 1->0 transition a reliable EOP marker HERE.
    --
    --   This is an INFERENCE from the IPG requirement, NOT a quotation.
    --   Confirm against the generated design example. If RX really does pack
    --   with zero gap, only DROP is affected - the rest is frame-agnostic.
    --
    --   The UG RX waveform supports the inference: it draws frames with
    --   visible gaps and shows fcs_error pulsing in the SAME segment as that
    --   frame's EOP, independently per segment.
    --=========================================================================
    signal cur_tag    : unsigned(TAG_W-1 downto 0) := (others => '0');
    signal next_tag   : unsigned(TAG_W-1 downto 0) := (others => '0');
    signal frame_open : std_logic := '0';
    signal drop_set   : std_logic_vector(NTAG-1 downto 0) := (others => '0');
    signal seg_tag    : std_logic_vector(NUM_SEG*TAG_W-1 downto 0)
                        := (others => '0');

    -- Delay line: hold the stream long enough for the EOP error to arrive
    type dl_data_t  is array (0 to DROP_DELAY-1)
        of std_logic_vector(DATA_W-1 downto 0);
    type dl_if_t    is array (0 to DROP_DELAY-1)
        of std_logic_vector(NUM_SEG-1 downto 0);
    type dl_empty_t is array (0 to DROP_DELAY-1)
        of std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
    type dl_tag_t   is array (0 to DROP_DELAY-1)
        of std_logic_vector(NUM_SEG*TAG_W-1 downto 0);

    signal dl_data  : dl_data_t  := (others => (others => '0'));
    signal dl_if    : dl_if_t    := (others => (others => '0'));
    signal dl_empty : dl_empty_t := (others => (others => '0'));
    signal dl_tag   : dl_tag_t   := (others => (others => '0'));
    signal dl_vld   : std_logic_vector(DROP_DELAY-1 downto 0)
                      := (others => '0');

    signal q_data  : std_logic_vector(DATA_W-1 downto 0);
    signal q_if    : std_logic_vector(NUM_SEG-1 downto 0);
    signal q_empty : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);
    signal q_tag   : std_logic_vector(NUM_SEG*TAG_W-1 downto 0);
    signal q_vld   : std_logic;
    signal keep    : std_logic_vector(NUM_SEG-1 downto 0);

    --=========================================================================
    -- Processing stage
    --=========================================================================
    signal p_valid : std_logic;
    signal p_data  : std_logic_vector(DATA_W-1 downto 0);
    signal p_if    : std_logic_vector(NUM_SEG-1 downto 0);
    signal p_empty : std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);

    --=========================================================================
    -- FIFO
    --=========================================================================
    type mem_t is array (0 to FIFO_DEPTH-1)
        of std_logic_vector(ENTRY_W-1 downto 0);
    signal mem : mem_t := (others => (others => '0'));
    attribute ramstyle : string;
    attribute ramstyle of mem : signal is "M20K, no_rw_check";

    signal wr_ptr : unsigned(ADDR_W downto 0) := (others => '0');
    signal rd_ptr : unsigned(ADDR_W downto 0) := (others => '0');
    signal level  : unsigned(ADDR_W downto 0);
    signal full   : std_logic;
    signal empty  : std_logic;

    signal mem_q    : std_logic_vector(ENTRY_W-1 downto 0) := (others => '0');
    signal rd_vld_d : std_logic := '0';

    --=========================================================================
    -- TX pause control
    --=========================================================================
    signal rdy_pipe : std_logic_vector(7 downto 0) := (others => '0');
    signal tx_en    : std_logic;

    signal wr_entry : std_logic_vector(ENTRY_W-1 downto 0);

begin

    --=========================================================================
    -- FRAME TAGGING
    --=========================================================================
    tag_proc : process(clk)
        variable v_cur   : unsigned(TAG_W-1 downto 0);
        variable v_next  : unsigned(TAG_W-1 downto 0);
        variable v_open  : std_logic;
        variable v_drop  : std_logic_vector(NTAG-1 downto 0);
        variable v_tag   : std_logic_vector(NUM_SEG*TAG_W-1 downto 0);
        variable v_ndrop : natural;
        variable seg_bad : boolean;
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                cur_tag    <= (others => '0');
                next_tag   <= (others => '0');
                frame_open <= '0';
                drop_set   <= (others => '0');
                seg_tag    <= (others => '0');
                o_dropped_frames <= (others => '0');

            elsif i_rx_mac_valid = '1' then
                v_cur   := cur_tag;
                v_next  := next_tag;
                v_open  := frame_open;
                v_drop  := drop_set;
                v_tag   := (others => '0');
                v_ndrop := 0;

                for s in 0 to NUM_SEG-1 loop
                    if i_rx_mac_inframe(s) = '1' then
                        if v_open = '0' then
                            -- inframe 0 -> 1 : start of a new frame
                            v_cur  := v_next;
                            v_next := v_next + 1;
                            v_drop(to_integer(v_cur)) := '0';  -- clear stale
                            v_open := '1';
                        end if;

                        v_tag(s*TAG_W+TAG_W-1 downto s*TAG_W) :=
                            std_logic_vector(v_cur);

                        -- UG Table 46: error and fcs_error are valid on EOP
                        -- segments. The UG RX waveform confirms they pulse in
                        -- the SAME segment as that frame's EOP.
                        seg_bad := (i_rx_mac_fcs_error(s) = '1') or
                                   (i_rx_mac_error(s*ERR_W+1 downto s*ERR_W)
                                      /= RXERR_NONE);

                        if seg_bad and v_drop(to_integer(v_cur)) = '0' then
                            v_drop(to_integer(v_cur)) := '1';
                            v_ndrop := v_ndrop + 1;   -- count once per frame
                        end if;
                    else
                        -- inframe 1 -> 0 : frame closed on the previous segment
                        v_open := '0';
                    end if;
                end loop;

                cur_tag    <= v_cur;
                next_tag   <= v_next;
                frame_open <= v_open;
                drop_set   <= v_drop;
                seg_tag    <= v_tag;

                if i_drop_on_error = '1' then
                    o_dropped_frames <= o_dropped_frames + v_ndrop;
                end if;
            end if;
        end if;
    end process;

    --=========================================================================
    -- DELAY LINE
    --=========================================================================
    delay_proc : process(clk)
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                dl_data  <= (others => (others => '0'));
                dl_if    <= (others => (others => '0'));
                dl_empty <= (others => (others => '0'));
                dl_tag   <= (others => (others => '0'));
                dl_vld   <= (others => '0');
            else
                dl_data(0)  <= i_rx_mac_data;
                dl_if(0)    <= i_rx_mac_inframe;
                dl_empty(0) <= i_rx_mac_eop_empty;
                dl_tag(0)   <= seg_tag;
                dl_vld(0)   <= i_rx_mac_valid;
                for k in 1 to DROP_DELAY-1 loop
                    dl_data(k)  <= dl_data(k-1);
                    dl_if(k)    <= dl_if(k-1);
                    dl_empty(k) <= dl_empty(k-1);
                    dl_tag(k)   <= dl_tag(k-1);
                    dl_vld(k)   <= dl_vld(k-1);
                end loop;
            end if;
        end if;
    end process;

    q_data  <= dl_data(DROP_DELAY-1);
    q_if    <= dl_if(DROP_DELAY-1);
    q_empty <= dl_empty(DROP_DELAY-1);
    q_tag   <= dl_tag(DROP_DELAY-1);
    q_vld   <= dl_vld(DROP_DELAY-1);

    -- Mask out segments belonging to frames marked bad. Per-segment, so a
    -- good frame sharing a beat with a bad one survives.
    g_keep : for s in 0 to NUM_SEG-1 generate
        keep(s) <= q_if(s) and
                   not (i_drop_on_error and
                        drop_set(to_integer(unsigned(
                            q_tag(s*TAG_W+TAG_W-1 downto s*TAG_W)))));
    end generate;

    --=========================================================================
    -- PROCESSING STAGE
    --
    -- i_en is tied high: the FIFO downstream absorbs TX pauses, and RX takes
    -- no backpressure (UG sec 7.5) so this side must keep accepting. If the
    -- algorithm is ever moved DOWNSTREAM of the FIFO, i_en must be driven by
    -- tx_en instead, or beats are lost on every pause.
    --=========================================================================
    u_proc : entity work.pipe_proc
        generic map (LATENCY => ALGO_LATENCY, BYPASS => PROC_BYPASS)
        port map (
            clk         => clk,
            rst_n       => rst_n,
            i_en        => '1',
            i_valid     => q_vld,
            i_data      => q_data,
            i_inframe   => keep,
            i_eop_empty => q_empty,
            o_valid     => p_valid,
            o_data      => p_data,
            o_inframe   => p_if,
            o_eop_empty => p_empty
        );

    --=========================================================================
    -- ELASTIC BEAT FIFO
    --=========================================================================
    level        <= wr_ptr - rd_ptr;
    full         <= '1' when level >= FIFO_DEPTH else '0';
    empty        <= '1' when wr_ptr = rd_ptr else '0';
    o_fifo_level <= resize(level, 16);

    wr_entry <= p_data & p_if & p_empty & i_tx_error & i_tx_skip_crc;

    wr_proc : process(clk)
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                wr_ptr      <= (others => '0');
                o_rx_beats  <= (others => '0');
                o_ovf_beats <= (others => '0');
            elsif p_valid = '1' and p_if /= (p_if'range => '0') then
                o_rx_beats <= o_rx_beats + 1;
                if full = '0' then
                    mem(to_integer(wr_ptr(ADDR_W-1 downto 0))) <= wr_entry;
                    wr_ptr <= wr_ptr + 1;
                else
                    -- UG sec 7.5: RX takes no backpressure, so a full FIFO
                    -- means the beat is lost. Counted so it is never silent.
                    -- The production answer is PAUSE/PFC (UG sec 4.2.3),
                    -- which stops the far end instead of dropping.
                    o_ovf_beats <= o_ovf_beats + 1;
                end if;
            end if;
        end if;
    end process;

    --=========================================================================
    -- TX PAUSE CONTROL
    --=========================================================================
    rdy_proc : process(clk)
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                rdy_pipe <= (others => '0');
            else
                rdy_pipe <= rdy_pipe(6 downto 0) &
                            (i_tx_mac_ready and i_tx_lanes_stable);
            end if;
        end if;
    end process;

    -- The outputs below are REGISTERED, which adds one cycle. Tapping at
    -- READY_LATENCY-2 makes o_tx_mac_valid land exactly READY_LATENCY cycles
    -- after i_tx_mac_ready. Tapping at READY_LATENCY-1 is off by one.
    tx_en <= rdy_pipe(READY_LATENCY-2) when READY_LATENCY >= 2
             else (i_tx_mac_ready and i_tx_lanes_stable);

    --=========================================================================
    -- TX OUTPUT with registered FIFO read
    --=========================================================================
    rd_mem : process(clk)
    begin
        if rising_edge(clk) then
            if tx_en = '1' then
                mem_q <= mem(to_integer(rd_ptr(ADDR_W-1 downto 0)));
            end if;
        end if;
    end process;

    tx_proc : process(clk)
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                rd_ptr             <= (others => '0');
                rd_vld_d           <= '0';
                o_tx_mac_data      <= (others => '0');
                o_tx_mac_valid     <= '0';
                o_tx_mac_inframe   <= (others => '0');
                o_tx_mac_eop_empty <= (others => '0');
                o_tx_mac_error     <= (others => '0');
                o_tx_mac_skip_crc  <= (others => '0');
                o_tx_beats         <= (others => '0');
            else
                -- valid ALWAYS tracks ready delayed by READY_LATENCY, never
                -- gated on having data. UG sec 7.4: valid asserts whenever
                -- ready is asserted "even though there is no packet to send".
                o_tx_mac_valid <= tx_en;

                if tx_en = '1' then
                    if empty = '0' then
                        rd_ptr   <= rd_ptr + 1;
                        rd_vld_d <= '1';
                    else
                        rd_vld_d <= '0';
                    end if;

                    if rd_vld_d = '1' then
                        o_tx_mac_data      <= mem_q(ENTRY_W-1 downto SB_W);
                        o_tx_mac_inframe   <= mem_q(SB_W-1 downto
                                                    SB_W-NUM_SEG);
                        o_tx_mac_eop_empty <= mem_q(SB_W-NUM_SEG-1 downto
                                                    2*NUM_SEG);
                        o_tx_mac_error     <= mem_q(2*NUM_SEG-1 downto NUM_SEG);
                        o_tx_mac_skip_crc  <= mem_q(NUM_SEG-1 downto 0);
                        o_tx_beats         <= o_tx_beats + 1;
                    else
                        -- IDLE BEAT: inframe = 0 with valid still asserted.
                        -- Deasserting valid here would break the protocol.
                        o_tx_mac_data      <= (others => '0');
                        o_tx_mac_inframe   <= (others => '0');
                        o_tx_mac_eop_empty <= (others => '0');
                        o_tx_mac_error     <= (others => '0');
                        o_tx_mac_skip_crc  <= (others => '0');
                    end if;
                end if;
                -- tx_en '0': every output register holds. Bus frozen, as
                -- UG sec 7.4 requires.
            end if;
        end if;
    end process;

end architecture rtl;
