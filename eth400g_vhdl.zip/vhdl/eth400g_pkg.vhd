--=============================================================================
-- eth400g_pkg.vhd
--
--  Shared constants and types for the Agilex 7 F-Tile Ethernet Hard IP
--  400GE MAC segmented client interface.
--
--  Reference: F-Tile Ethernet Hard IP User Guide, doc 683023 (2026.08.10)
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package eth400g_pkg is

    --=========================================================================
    -- 400GE-8 GEOMETRY   (UG Tables 43 and 46)
    --=========================================================================
    constant DATA_W   : natural := 1024;  -- client datapath
    constant NUM_SEG  : natural := 16;    -- segments per beat
    constant SEG_B    : natural := 8;     -- bytes per segment
    constant SEG_W    : natural := 64;    -- bits per segment
    constant EMPTY_W  : natural := 3;     -- eop_empty bits per segment
    constant ERR_W    : natural := 2;     -- rx error bits per segment
    constant STAT_W   : natural := 3;     -- rx status bits per segment
    constant BEAT_B   : natural := NUM_SEG * SEG_B;   -- 128 bytes per beat

    --=========================================================================
    -- MAC DATAPATH CLOCK
    --
    -- UG sec 5: i_clk_tx / i_clk_rx are driven by o_clk_pll, which is
    --   "415.0390625 MHz or higher for all Ethernet modes with IEEE 802.3
    --    RS(544,514) (CL134)"   -- RS(544,514) is KP4 FEC, i.e. 400GE.
    --
    -- NOT 390.625 MHz. That is o_clk_tx_div (TX SERDES rate / 68), used for
    -- TOD/PTP - a different clock entirely.
    --
    -- 1024 b x 415.0390625 MHz = 425 Gb/s of INTERFACE capacity, carrying
    -- 400 Gb/s of payload plus idle segments for IFG and preamble.
    --=========================================================================
    constant CLK_PERIOD_PS : time := 2409.5 ps;   -- 415.0390625 MHz

    --=========================================================================
    -- RX ERROR CODES   (UG Table 46, o_rx_mac_error, 2 bits per segment)
    --=========================================================================
    constant RXERR_NONE     : std_logic_vector(1 downto 0) := "00";
    constant RXERR_MALFORM  : std_logic_vector(1 downto 0) := "01";
    -- control character that is not a terminate character
    constant RXERR_SIZE     : std_logic_vector(1 downto 0) := "10";
    -- undersized (<64 B) or oversized (> programmed max)
    constant RXERR_PAYLEN   : std_logic_vector(1 downto 0) := "11";
    -- payload shorter than the length field, length <= 1500

    --=========================================================================
    -- RX STATUS CODES   (UG Table 46, o_rx_mac_status_data, 3 bits/segment)
    -- Reported in priority order 5,4,7,6,1,2,3,0
    --=========================================================================
    constant RXSTAT_VALID_LEN : std_logic_vector(2 downto 0) := "000";
    constant RXSTAT_ETH_TYPE  : std_logic_vector(2 downto 0) := "001";
    constant RXSTAT_BCAST_MC  : std_logic_vector(2 downto 0) := "010";
    constant RXSTAT_RSVD      : std_logic_vector(2 downto 0) := "011";
    constant RXSTAT_SFC_PFC   : std_logic_vector(2 downto 0) := "100";
    constant RXSTAT_SVLAN     : std_logic_vector(2 downto 0) := "101";
    constant RXSTAT_ILLEGAL   : std_logic_vector(2 downto 0) := "110";
    constant RXSTAT_FC_FRAME  : std_logic_vector(2 downto 0) := "111";

    --=========================================================================
    -- FRAME SIZE LIMITS
    -- UG: TX/RX maximum frame size parameter range is 65 .. 65535,
    -- default 1518. Jumbo support is a PARAMETER, not a redesign.
    --=========================================================================
    constant MIN_ETH_FRAME  : natural := 64;
    constant DEF_MAX_FRAME  : natural := 1518;
    constant JUMBO_MAX      : natural := 9000;

    --=========================================================================
    -- 'Bytes to remove from RX frames'  (UG MAC Options, default Remove CRC)
    --=========================================================================
    type rx_strip_t is (STRIP_NONE, STRIP_CRC, STRIP_CRC_PAD);

    --=========================================================================
    -- TUNNEL ENCAPSULATION OVERHEAD
    --   IP 20 + UDP 8 + IV 16 + hash 20 = 64 bytes
    --   Ethernet header is preserved, not added.
    --
    --   64 = 8 segments EXACTLY, so the header insert is segment-aligned:
    --   pure rewiring, no byte-granular barrel shifter. This is worth
    --   protecting - an unaligned overhead forces a full 1024-bit barrel
    --   shift at 415 MHz, which is the hardest timing problem in the design.
    --=========================================================================
    constant TUNNEL_OVH_B    : natural := 64;
    constant TUNNEL_OVH_SEG  : natural := TUNNEL_OVH_B / SEG_B;   -- 8

    --=========================================================================
    -- HELPERS
    --=========================================================================
    -- Slice segment s out of a packed per-segment vector of width w
    function seg_slice(v : std_logic_vector; s : natural; w : natural)
        return std_logic_vector;

    -- Bytes carried by one beat, given inframe and eop_empty
    function beat_bytes(inframe   : std_logic_vector;
                        eop_empty : std_logic_vector) return natural;

    -- Beats needed for a frame of len bytes, including gap segments
    function frame_beats(len : natural; gap_segs : natural) return natural;

end package eth400g_pkg;


package body eth400g_pkg is

    function seg_slice(v : std_logic_vector; s : natural; w : natural)
        return std_logic_vector is
        variable r : std_logic_vector(w-1 downto 0);
    begin
        for i in 0 to w-1 loop
            r(i) := v(s*w + i);
        end loop;
        return r;
    end function;

    function beat_bytes(inframe   : std_logic_vector;
                        eop_empty : std_logic_vector) return natural is
        variable n : natural := 0;
        variable e : natural;
    begin
        for s in 0 to NUM_SEG-1 loop
            if inframe(s) = '1' then
                e := to_integer(unsigned(seg_slice(eop_empty, s, EMPTY_W)));
                n := n + (SEG_B - e);
            end if;
        end loop;
        return n;
    end function;

    function frame_beats(len : natural; gap_segs : natural) return natural is
        variable segs : natural;
    begin
        segs := (len + SEG_B - 1) / SEG_B + gap_segs;
        return (segs + NUM_SEG - 1) / NUM_SEG;
    end function;

end package body eth400g_pkg;
