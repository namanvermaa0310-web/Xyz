--=============================================================================
-- pipe_proc.vhd
--
--  PROCESSING WRAPPER.  SYNTHESISABLE - targets Agilex 7.
--
--  Wraps custom_algo and keeps the SIDEBAND aligned with the data.
--
--  This file exists so custom_algo can be a plain data-in / data-out block
--  with no knowledge of Ethernet framing. All the plumbing lives here:
--
--    - inframe / eop_empty / valid travel a delay line matched to the
--      algorithm's LATENCY, so framing stays bit-aligned with its data
--    - every register is gated by i_en, so a TX pause freezes the whole
--      pipeline together
--    - LATENCY is a generic passed straight through. Change it in one place
--      and this wrapper re-aligns automatically. No other file moves.
--
--  Initiation interval is 1: one beat in, one out, every enabled cycle.
--=============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.eth400g_pkg.all;

entity pipe_proc is
    generic (
        LATENCY : positive := 17;       -- must equal custom_algo's latency
        BYPASS  : boolean  := false     -- true = pure delay, no transform
    );
    port (
        clk          : in  std_logic;
        rst_n        : in  std_logic;
        i_en         : in  std_logic;

        i_valid      : in  std_logic;
        i_data       : in  std_logic_vector(DATA_W-1 downto 0);
        i_inframe    : in  std_logic_vector(NUM_SEG-1 downto 0);
        i_eop_empty  : in  std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0);

        o_valid      : out std_logic;
        o_data       : out std_logic_vector(DATA_W-1 downto 0);
        o_inframe    : out std_logic_vector(NUM_SEG-1 downto 0);
        o_eop_empty  : out std_logic_vector(NUM_SEG*EMPTY_W-1 downto 0)
    );
end entity pipe_proc;

architecture rtl of pipe_proc is

    --=========================================================================
    -- SIDEBAND DELAY LINE - depth follows LATENCY automatically
    --=========================================================================
    constant SB_W : natural := 1 + NUM_SEG + NUM_SEG*EMPTY_W;

    type sb_arr_t is array (0 to LATENCY-1)
        of std_logic_vector(SB_W-1 downto 0);
    signal sb : sb_arr_t := (others => (others => '0'));

    signal sb_in  : std_logic_vector(SB_W-1 downto 0);
    signal sb_out : std_logic_vector(SB_W-1 downto 0);

    --=========================================================================
    -- Data path
    --=========================================================================
    type dl_arr_t is array (0 to LATENCY-1)
        of std_logic_vector(DATA_W-1 downto 0);
    signal dl : dl_arr_t := (others => (others => '0'));

    signal algo_out : std_logic_vector(DATA_W-1 downto 0);

begin

    sb_in <= i_valid & i_inframe & i_eop_empty;

    sideband : process(clk)
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                sb <= (others => (others => '0'));
            elsif i_en = '1' then
                sb(0) <= sb_in;
                for k in 1 to LATENCY-1 loop
                    sb(k) <= sb(k-1);
                end loop;
            end if;
        end if;
    end process;

    sb_out      <= sb(LATENCY-1);
    o_valid     <= sb_out(SB_W-1);
    o_inframe   <= sb_out(SB_W-2 downto SB_W-1-NUM_SEG);
    o_eop_empty <= sb_out(NUM_SEG*EMPTY_W-1 downto 0);

    --=========================================================================
    g_bypass : if BYPASS generate
        delay_only : process(clk)
        begin
            if rising_edge(clk) then
                if rst_n = '0' then
                    dl <= (others => (others => '0'));
                elsif i_en = '1' then
                    dl(0) <= i_data;
                    for k in 1 to LATENCY-1 loop
                        dl(k) <= dl(k-1);
                    end loop;
                end if;
            end if;
        end process;
        o_data <= dl(LATENCY-1);
    end generate;

    g_algo : if not BYPASS generate
        u_algo : entity work.custom_algo
            generic map (LATENCY => LATENCY)
            port map (
                clk      => clk,
                rst_n    => rst_n,
                i_en     => i_en,
                i_plain  => i_data,
                o_cipher => algo_out
            );
        o_data <= algo_out;
    end generate;

end architecture rtl;
