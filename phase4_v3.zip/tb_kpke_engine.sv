`timescale 1ns/1ps
// =============================================================================
// tb_kpke_engine.sv -- assert the K-PKE call sequences against FIPS 203
// Algorithms 13, 14 and 15, using the verified golden model as the reference
// for what the order must be.
//
// The sub-units are behavioural stubs: their arithmetic is already covered by
// their own testbenches (basemul, poly_basemul, matvec_mul, cbd eta=2/eta=3,
// sample_ntt, NTT, SHA3-512, compress). What is under test HERE is the
// orchestration -- which unit is invoked, in what order, with which indices.
// Ordering is exactly where an FSM of this size goes wrong.
// =============================================================================
module tb_kpke_engine;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start;
  wire busy, done;
  wire [2:0] usel, uop; wire [7:0] ua0, ua1, ua2;
  wire ustart; reg udone;
  wire [5:0] dbg; wire [10:0] bbase;

  kpke_engine #(.K_PARAM(2), .ETA1(3), .ETA2(2), .DU(10), .DV(4)) dut(
    .clk(clk),.rst_n(rst_n),.op(op),.start(start),.busy(busy),.done(done),
    .unit_sel(usel),.unit_op(uop),.unit_a0(ua0),.unit_a1(ua1),.unit_a2(ua2),
    .unit_start(ustart),.unit_done(udone),.byte_base(bbase),.dbg_state(dbg));

  // ---- stub: every service call completes after 3 cycles ----
  integer ud;
  integer nlog;
  reg [2:0] lsel[0:63]; reg [2:0] lop[0:63];
  reg [7:0] la0[0:63], la1[0:63], la2[0:63];

  always @(posedge clk) begin
    udone <= 1'b0;
    if (ustart) begin
      lsel[nlog]<=usel; lop[nlog]<=uop;
      la0[nlog]<=ua0; la1[nlog]<=ua1; la2[nlog]<=ua2;
      nlog <= nlog+1;
      ud <= 3;
    end else if (ud>0) begin
      ud <= ud-1;
      if (ud==1) udone <= 1'b1;
    end
  end

  integer errors=0, i;
  reg [63:0] uname [0:6];
  initial begin
    uname[0]="HASH"; uname[1]="XOF"; uname[2]="PRF"; uname[3]="NTT";
    uname[4]="MATVEC"; uname[5]="POLY"; uname[6]="CODEC";
  end

  task run_op(input [1:0] o, input [255:0] label);
    begin
      nlog=0;
      @(negedge clk); op=o; start=1'b1;
      @(negedge clk); start=1'b0;
      while(!busy) @(posedge clk);
      while(busy)  @(posedge clk);
      repeat(6) @(posedge clk);
      $display("[TB] %0s: %0d service calls", label, nlog);
    end
  endtask

  task expect_call(input integer n, input [2:0] u,
                   input [7:0] a0, input [7:0] a1, input [7:0] a2,
                   input [255:0] what);
    begin
      if (lsel[n] !== u) begin
        $display("[TB] FAIL step %0d: unit %0s, expected %0s (%0s)",
                 n, uname[lsel[n]], uname[u], what);
        errors=errors+1;
      end else if (la0[n]!==a0 || la1[n]!==a1 || la2[n]!==a2) begin
        $display("[TB] FAIL step %0d %0s: args (%0d,%0d,%0d) expected (%0d,%0d,%0d)",
                 n, what, la0[n],la1[n],la2[n], a0,a1,a2);
        errors=errors+1;
      end
    end
  endtask

  initial begin
    $display("============================================================");
    $display("  Phase 4D: kpke_engine -- Algorithms 13 / 14 / 15");
    $display("============================================================");
    rst_n=0; start=0; op=0; ud=0; nlog=0; udone=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);

    // ================= Algorithm 13: KeyGen =================
    run_op(2'd0, "KeyGen (Alg 13)");
    // G(d||k)
    expect_call(0, 3'd0, 0,0,0, "G(d||k)");
    // A_hat[i][j] = SampleNTT(XOF(rho, j, i)) -> slots 0..3
    expect_call(1, 3'd1, 0,0,0, "XOF(rho,0,0)->A[0][0]");
    expect_call(2, 3'd1, 1,0,1, "XOF(rho,1,0)->A[0][1]");
    expect_call(3, 3'd1, 0,1,2, "XOF(rho,0,1)->A[1][0]");
    expect_call(4, 3'd1, 1,1,3, "XOF(rho,1,1)->A[1][1]");
    // s[i] = CBD_eta1(PRF(sigma,N)), N=0,1 -- eta MUST be 3 for ML-KEM-512
    expect_call(5, 3'd2, 0,3,8,  "PRF(sigma,0)+CBD3->s[0]");
    expect_call(6, 3'd2, 1,3,9,  "PRF(sigma,1)+CBD3->s[1]");
    // e[i], N=2,3
    expect_call(7, 3'd2, 2,3,10, "PRF(sigma,2)+CBD3->e[0]");
    expect_call(8, 3'd2, 3,3,11, "PRF(sigma,3)+CBD3->e[1]");
    // NTTs
    expect_call(9,  3'd3, 0,8,12,  "NTT s[0]");
    expect_call(10, 3'd3, 0,9,13,  "NTT s[1]");
    expect_call(11, 3'd3, 0,10,14, "NTT e[0]");
    expect_call(12, 3'd3, 0,11,15, "NTT e[1]");
    // matvec row0, add e_hat[0]; row1, add e_hat[1]
    expect_call(13, 3'd4, 0,12,23, "MATVEC row0");
    expect_call(14, 3'd5, 23,14,16,"t_hat[0]=acc+e_hat[0]");
    expect_call(15, 3'd4, 1,12,23, "MATVEC row1");
    expect_call(16, 3'd5, 23,15,17,"t_hat[1]=acc+e_hat[1]");
    // encode ek then dk
    // ek and dk are each K polynomials, so 2*K = 4 encodes for ML-KEM-512
    expect_call(17, 3'd6, 0,16,0, "ByteEncode12(t_hat[0])->ek");
    expect_call(18, 3'd6, 0,17,0, "ByteEncode12(t_hat[1])->ek");
    expect_call(19, 3'd6, 0,12,1, "ByteEncode12(s_hat[0])->dk");
    expect_call(20, 3'd6, 0,13,1, "ByteEncode12(s_hat[1])->dk");
    if (nlog !== 21) begin
      $display("[TB] FAIL KeyGen: %0d calls, expected 21", nlog); errors=errors+1;
    end

    // ================= Algorithm 14: Encrypt =================
    run_op(2'd1, "Encrypt (Alg 14)");
    // ek holds K encoded polynomials, so Encrypt begins with K decodes.
    // A single decode would have recovered only t_hat[0].
    expect_call(0, 3'd6, 0,0,16, "ByteDecode12(ek)->t_hat[0]");
    expect_call(1, 3'd6, 0,0,17, "ByteDecode12(ek)->t_hat[1]");
    expect_call(2, 3'd1, 0,0,0,  "XOF->A[0][0]");
    expect_call(6, 3'd2, 0,3,8,  "PRF(r,0)+CBD3->y[0]");
    expect_call(7, 3'd2, 1,3,9,  "PRF(r,1)+CBD3->y[1]");
    // e1/e2 use ETA2 = 2, NOT eta1 -- a classic place to get it wrong
    expect_call(8, 3'd2, 2,2,10, "PRF(r,2)+CBD2->e1[0]");
    expect_call(9, 3'd2, 3,2,11, "PRF(r,3)+CBD2->e1[1]");
    expect_call(10,3'd2, 4,2,21, "PRF(r,4)+CBD2->e2");
    $display("[TB] Encrypt: e1/e2 correctly use eta=2, y uses eta=3");

    // ================= Algorithm 15: Decrypt =================
    run_op(2'd2, "Decrypt (Alg 15)");
    // Decrypt must FIRST decode dk into s_hat -- an earlier version went
    // straight to decompressing the ciphertext and never recovered the
    // secret key at all.
    if (lsel[0] !== 3'd6 || lop[0] !== 3'd1) begin
      $display("[TB] FAIL Decrypt step0: expected ByteDecode12(dk)"); errors=errors+1;
    end else $display("[TB] Decrypt: decodes dk into s_hat first");
    // Decrypt must contain a MATVEC and an inverse NTT
    begin : chk
      integer sawmv, sawinv;
      sawmv=0; sawinv=0;
      for (i=0;i<nlog;i=i+1) begin
        if (lsel[i]===3'd4) sawmv=1;
        if (lsel[i]===3'd3 && lop[i]===3'd1) sawinv=1;
      end
      if (!sawmv)  begin $display("[TB] FAIL: Decrypt has no MATVEC"); errors=errors+1; end
      if (!sawinv) begin $display("[TB] FAIL: Decrypt has no inverse NTT"); errors=errors+1; end
      if (sawmv && sawinv) $display("[TB] Decrypt: MATVEC and inverse NTT present");
    end

    $display("============================================================");
    if (errors==0)
      $display("  PASS -- K-PKE call sequences match FIPS 203 Algs 13/14/15");
    else
      $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #2_000_000; $display("TIMEOUT state=%0d",dbg); $finish; end
endmodule
