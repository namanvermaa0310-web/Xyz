Phase 4 v3 -- all remaining datapath operations
===============================================

    bash run.sh        (three suites, all passing)

WHAT IS NEW IN THIS DROP
------------------------
kpke_datapath.sv now implements EVERY non-hashing service call. Previously
five of them fell through to a stub that completed immediately and did
nothing, so Encrypt and Decrypt would have "run" and produced garbage.

  ByteDecode_12          384 bytes -> 256 twelve-bit coefficients
  Compress_d + pack      d = 10 (ciphertext u) and d = 4 (ciphertext v)
  unpack + Decompress_d  the inverse
  add-message            v = v + Decompress_1(m)
  Compress_1 -> message  256 coefficients -> 32 bytes

  Verified against the golden model:
      ByteDecode_12       256/256 coefficients
      Compress_10 + pack  320/320 bytes
      unpack+Decompress   256/256 coefficients

MATVEC now honours unit_op, which it previously ignored -- it always did
mode 0. Four modes, and the transpose Encrypt needs is purely an addressing
change here, so matvec_mul itself is untouched and stays as verified:

  0  KeyGen     base = SLOT_A + i*k, stride 1   (walk a row)
  1  Encrypt u  base = SLOT_A + i,   stride k   (walk a column = transpose)
  2  Encrypt v  base = SLOT_T,       stride 1
  3  Decrypt    base = SLOT_T,       stride 1

TWO REAL BUGS FOUND IN kpke_engine WHILE DOING THIS
---------------------------------------------------
1. Encrypt issued ONE ByteDecode_12 for ek. ek holds K polynomials, so only
   t_hat[0] was ever recovered -- the same class of mistake as the encode
   loop fixed in the previous drop. Now K decodes. Encrypt is 26 calls.

2. Decrypt NEVER DECODED dk. It went straight to decompressing the
   ciphertext, so the matvec had no valid s_hat to multiply against. Decrypt
   now decodes dk into SLOT_T (unused in Decrypt) first. 10 calls.

Neither would have shown up in the control-level testbench as it stood,
because that testbench only checked the calls the design happened to make.

REGRESSION AFTER ALL OF THIS
----------------------------
    kpke_engine call sequences        PASS  (21 / 26 / 10 calls)
    new codec ops                     PASS
    full KeyGen, FSM-driven           PASS  (768 ek + rho + 768 dk bytes)

WHAT IS STILL MISSING -- READ THIS BEFORE ASSUMING ENCRYPT WORKS
----------------------------------------------------------------
Encrypt and Decrypt CANNOT run end to end yet, and the reason is in
kpke_seed_unit, not in the datapath:

  * Encrypt's PRF key is the CIPHERTEXT COINS r, not sigma. kpke_seed_unit
    only ever holds a sigma captured from G(d||k) and has no way to load an
    externally supplied PRF key.

  * Encrypt's rho comes from the last 32 bytes of ek, not from G. Again no
    load path exists.

  * Decrypt needs neither, but it shares the same unit.

  So kpke_seed_unit needs two new service ops -- LOAD_RHO (from a byte
  buffer) and LOAD_PRFKEY (from a byte buffer) -- plus the engine issuing
  them at the start of Encrypt. That is the next piece of work, and it is
  small compared with what is already here.

AFTER THAT, TO FINISH THE PROJECT
---------------------------------
  1. kpke_seed_unit: LOAD_RHO + LOAD_PRFKEY ops
  2. tb_kpke_encrypt / tb_kpke_decrypt against the golden ciphertext
     (golden_mlkem.py already computes it; ec_*.hex generation is a
     three-line script)
  3. mlkem_hash_unit.sv -- H, G and J over the 800-byte ek and z||c buffers.
     MUST be instantiated with MAX_MSG_BYTES >= 800; the 512 default would
     silently truncate and produce plausible but wrong keys.
  4. mlkem_system.sv -- mlkem_fo_ctrl + kpke_system + hash unit + byte
     memories. verify_cmov.sv and mlkem_fo_ctrl.sv are included here and
     already verified standalone.
  5. Full KeyGen -> Encaps -> Decaps vs golden_mlkem.py, including the
     corrupted-ciphertext rejection path.

VIVADO
------
kpke_system_synth.xdc is included. Synthesis -> Implementation -> Report
Timing Summary, then STOP. Do not Generate Bitstream: kpke_system has 304
unpinned top-level port bits because it is an internal block, not a chip top.

kpke_datapath grew substantially in this drop, and the previous kpke_top
result had only +0.449 ns of margin, so re-check WNS before assuming it
still closes.
