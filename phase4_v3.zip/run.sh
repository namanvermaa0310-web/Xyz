#!/bin/bash
set -e
echo "########## kpke_engine call sequences ##########"
iverilog -g2012 -o a.vvp mlkem_pkg.sv kpke_engine.sv tb_kpke_engine.sv && vvp a.vvp
echo ""
echo "########## new codec ops (DEC12 / COMPR / DECOMP) ##########"
iverilog -g2012 -o b.vvp mlkem_pkg.sv twiddle_rom.sv ntt_engine.sv basemul.sv \
  poly_basemul.sv matvec_mul.sv poly_slots.sv kpke_datapath.sv tb_codec_ops.sv && vvp b.vvp
echo ""
echo "########## full KeyGen, FSM-driven ##########"
iverilog -g2012 -o c.vvp mlkem_pkg.sv keccak_pkg.sv twiddle_rom.sv ntt_engine.sv \
  basemul.sv poly_basemul.sv matvec_mul.sv poly_slots.sv kpke_datapath.sv \
  keccak_round.sv keccak_f1600.sv sha3_512.sv shake128.sv shake256.sv sample_ntt.sv \
  cbd_sampler.sv cbd_sampler_eta3.sv kpke_seed_unit.sv kpke_top.sv kpke_engine.sv \
  kpke_system.sv tb_kpke_system.sv && vvp c.vvp
rm -f *.vvp
