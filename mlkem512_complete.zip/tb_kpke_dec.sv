`timescale 1ns/1ps
// First end-to-end run of K-PKE.Encrypt (FIPS 203 Algorithm 14).
module tb_kpke_dec;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start; wire busy, done, serr;
  wire [5:0] d_ra; reg [7:0] d_rd;
  wire [10:0] bw_a, br_a; wire [7:0] bw_d; wire bw_en; reg [7:0] br_d;
  wire [255:0] rho_out; wire [5:0] dbg;

  kpke_system #(.K_PARAM(2), .ADDR_W(13)) dut(
    .clk(clk),.rst_n(rst_n),.op(op),.start(start),.busy(busy),.done(done),
    .d_rd_data(d_rd),.d_rd_addr(d_ra),
    .byte_wr_addr(bw_a),.byte_wr_data(bw_d),.byte_wr_en(bw_en),
    .byte_rd_addr(br_a),.byte_rd_data(br_d),
    .rho_out(rho_out),.sample_error(serr),.dbg_engine_state(dbg));

  reg [7:0] bmem[0:2047], dmem[0:63];
  always @(posedge clk) begin
    br_d <= bmem[br_a];
    d_rd <= dmem[d_ra];
    if (bw_en) bmem[bw_a] <= bw_d;
  end
  reg [7:0] g_ct[0:31];
  integer errors=0, i;

  initial begin
    $readmemh("de_init.hex", bmem);
    $readmemh("de_msg.hex", g_ct);
    $display("============================================================");
    $display("  K-PKE.Decrypt (Alg 15) end to end");
    $display("============================================================");
    rst_n=0; start=0; op=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);
    @(negedge clk); op=2'd2; start=1'b1;
    @(negedge clk); start=1'b0;
    while(!busy) @(negedge clk);
    $display("[TB] Decrypt running...");
    while(busy) @(negedge clk);
    repeat(4) @(posedge clk);
    $display("[TB] Decrypt done");
    // Decrypt writes the recovered message to MSG_BASE = 1868
    for(i=0;i<32;i=i+1)
      if (bmem[1868+i] !== g_ct[i]) begin
        if(errors<8) $display("[TB] FAIL m[%0d]: got %02h want %02h",
                              i,bmem[1868+i],g_ct[i]);
        errors=errors+1;
      end
    $display("============================================================");
    if(errors==0) $display("  PASS -- 32/32 message bytes recovered correctly");
    else          $display("  FAIL -- %0d of 32 message bytes wrong", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #900_000_000; $display("TIMEOUT eng=%0d",dbg); $finish; end
endmodule
