## =============================================================================
## mlkem_system_synth.xdc -- synthesis + timing for the complete ML-KEM-512
## Target: xc7k325tffg900-2
## =============================================================================
## SCOPE: Synthesis -> Implementation -> Report Timing Summary. STOP THERE.
## Do NOT run Generate Bitstream. mlkem_system is an internal block with
## several hundred unpinned top-level port bits, so NSTD-1 / UCIO-1 fire at
## bitgen -- correctly. A board wrapper (IBUFDS + MMCM + reset synchroniser +
## UART bridge) exposing four real pins is what would get a pin XDC, exactly
## as Phases 1-3 have.
## =============================================================================

create_clock -period 10.000 -name clk [get_ports clk]
set_false_path -from [get_ports rst_n]

## Let implementation finish without pin assignments so the timing report is
## real. Do not copy these two lines into a board XDC.
set_property SEVERITY {Warning} [get_drc_checks NSTD-1]
set_property SEVERITY {Warning} [get_drc_checks UCIO-1]

## Keep pad paths out of the picture; what matters is the internal logic.
set_false_path -from [all_inputs]    -to [all_registers]
set_false_path -from [all_registers] -to [all_outputs]

set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 2.5 [current_design]

## =============================================================================
## REFERENCE POINT
## kpke_top -- the K-PKE datapath alone -- closed at WNS = +0.449 ns with 0
## failing endpoints of 56,684. mlkem_system adds kpke_engine, three more
## Keccak sponges (in mlkem_hash_unit), verify_cmov and the FO sequencer on
## top of that, and kpke_datapath itself has grown substantially since. That
## +0.449 ns was already thin, so DO NOT assume it still holds.
##
## If WNS is negative, record the number AND the worst path's startpoint and
## endpoint. Which module owns it decides the fix:
##   keccak_round   -> split theta+rho+pi from chi+iota (24 -> 48 cycles)
##   ntt / basemul  -> already one multiplier per stage; look at memory paths
##   poly_slots     -> the 2-read-port array may need registered outputs
##   byte buffers   -> the 13-bit shared bus has wide muxes at the top level
## =============================================================================
