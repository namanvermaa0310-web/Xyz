module keccak_f1600 (
  input  wire            clk,
  input  wire            rst_n,
  input  wire            start,
  input  wire [1599:0]   state_in,
  output reg  [1599:0]   state_out,
  output wire            busy,
  output reg             done       // level-sensitive: stays high until next start
);
  reg [1599:0] cur_state;
  reg [4:0]    round_idx;   // 0..23
  reg          running;

  wire [1599:0] round_out;
  keccak_round u_round (
    .state_in  (cur_state),
    .round_idx (round_idx),
    .state_out (round_out)
  );

  assign busy = running;

  always @(posedge clk) begin
    if (!rst_n) begin
      running   <= 1'b0;
      round_idx <= 5'd0;
      cur_state <= 1600'd0;
      state_out <= 1600'd0;
      done      <= 1'b0;
    end else if (start && !running) begin
      running   <= 1'b1;
      round_idx <= 5'd0;
      cur_state <= state_in;
      done      <= 1'b0;
    end else if (running) begin
      cur_state <= round_out;
      if (round_idx == 5'd23) begin
        running   <= 1'b0;
        state_out <= round_out;
        done      <= 1'b1;
      end else begin
        round_idx <= round_idx + 5'd1;
      end
    end else if (start) begin
      // start re-asserted after a prior completion: begin a fresh permutation
      running   <= 1'b1;
      round_idx <= 5'd0;
      cur_state <= state_in;
      done      <= 1'b0;
    end
  end
endmodule : keccak_f1600
