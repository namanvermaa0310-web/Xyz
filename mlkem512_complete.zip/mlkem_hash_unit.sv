// =============================================================================
// mlkem_hash_unit.sv -- H, G and J for the Fujisaki-Okamoto layer
// -----------------------------------------------------------------------------
//   H(s) = SHA3-256(s)          used for H(ek), 32-byte output
//   G(s) = SHA3-512(s)          used for G(m || H(ek)) and G(m' || h)
//   J(s) = SHAKE-256(s, 32)     used for Kbar = J(z || c)
//
// SIZING -- the reason this unit exists separately from kpke_seed_unit.
// The seed unit only ever hashes ~34 bytes (rho||j||i, sigma||N), so its
// cores are parameterised small. The FO layer hashes ek (800 bytes) and
// z||c (32 + 768 = 800 bytes). Instantiating those cores at the 512-byte
// default would SILENTLY TRUNCATE the input and yield plausible but wrong
// keys, so MAX_MSG_BYTES is 832 here.
//
// Inputs are streamed from the shared byte buffer; outputs are written back
// to it, so the FO controller only ever moves offsets around.
//
// Every sub-core is waited on via BUSY (rise then fall), never via `done` --
// the level-held-done pattern has caused skipped operations four times in
// this project.
// =============================================================================
module mlkem_hash_unit #(
  parameter integer MAX_MSG = 832
)(
  input  wire        clk,
  input  wire        rst_n,

  input  wire [1:0]  hsel,        // 0 = H, 1 = G, 2 = J
  // 12 bits, not 11. The FO-layer buffers live above 2048 (G output at 2632,
  // Kbar at 2696, shared secret at 2760), and an 11-bit address silently
  // truncates them -- G's digest was being written 2048 bytes low, so
  // G_BASE read back as all zeros while everything upstream looked correct.
  input  wire [12:0] in_base,     // where the input starts
  input  wire [12:0] in_len,      // how many bytes
  input  wire [12:0] out_base,    // where to write the digest
  input  wire        start,
  output reg         busy,
  output reg         done,
  output reg         active,      // owns the byte-buffer ports

  output reg  [12:0] byte_rd_addr,
  input  wire [7:0]  byte_rd_data,
  output reg  [12:0] byte_wr_addr,
  output reg  [7:0]  byte_wr_data,
  output reg         byte_wr_en,

  // G returns 64 bytes; the caller usually wants them split as (K, r).
  output wire [511:0] g_digest
);

  localparam H_H = 2'd0;
  localparam H_G = 2'd1;
  localparam H_J = 2'd2;

  reg [1:0]  r_sel;
  reg [12:0] r_ibase, r_ilen, r_obase;
  reg [12:0] cnt;

  // ---- SHA3-256 (H) ----
  reg         h_start; reg [9:0] h_len;
  reg  [10:0] h_wa; reg [7:0] h_wd; reg h_we;
  wire        h_busy, h_done; wire [255:0] h_hash;
  sha3_256_mb #(.MAX_MSG_BYTES(MAX_MSG)) u_h (
    .clk(clk), .rst_n(rst_n), .start(h_start), .msg_len(h_len),
    .wr_addr(h_wa), .wr_data(h_wd), .wr_en(h_we),
    .busy(h_busy), .done(h_done), .hash_out(h_hash));

  // ---- SHA3-512 (G) ----
  reg         g_start; reg [9:0] g_len;
  reg  [10:0] g_wa; reg [7:0] g_wd; reg g_we;
  wire        g_busy, g_done; wire [511:0] g_hash;
  sha3_512_mb #(.MAX_MSG_BYTES(MAX_MSG)) u_g (
    .clk(clk), .rst_n(rst_n), .start(g_start), .msg_len(g_len),
    .wr_addr(g_wa), .wr_data(g_wd), .wr_en(g_we),
    .busy(g_busy), .done(g_done), .hash_out(g_hash));
  assign g_digest = g_hash;

  // ---- SHAKE-256 (J), 32-byte output ----
  reg         j_start; reg [9:0] j_mlen, j_olen;
  reg  [10:0] j_wa; reg [7:0] j_wd; reg j_we;
  wire        j_busy, j_done;
  reg  [9:0]  j_ra; wire [7:0] j_rd;
  shake256 #(.MAX_MSG_BYTES(MAX_MSG), .MAX_OUT_BYTES(64)) u_j (
    .clk(clk), .rst_n(rst_n), .start(j_start), .msg_len(j_mlen),
    .wr_addr(j_wa), .wr_data(j_wd), .wr_en(j_we), .out_len(j_olen),
    .busy(j_busy), .done(j_done), .rd_addr(j_ra), .rd_data(j_rd));

  // Digest byte i is the MSB-first slice, matching the convention used by
  // sha3_256 / sha3_512 throughout this project.
  wire [7:0] h_byte = h_hash[(31 - cnt[4:0])*8 +: 8];
  wire [7:0] g_byte = g_hash[(63 - cnt[5:0])*8 +: 8];

  localparam S_IDLE = 4'd0;
  localparam S_LD_A = 4'd1;   // drive byte address
  localparam S_LD_W = 4'd2;   // registered read settles
  localparam S_LD_B = 4'd3;   // push byte into the core
  localparam S_GO   = 4'd4;
  localparam S_ARM  = 4'd5;
  localparam S_RUN  = 4'd6;
  localparam S_WR   = 4'd7;   // write digest back to the buffer
  localparam S_JRD  = 4'd8;   // SHAKE output is read from its own memory
  localparam S_FIN  = 4'd9;

  reg [3:0] state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; busy <= 1'b0; done <= 1'b0; active <= 1'b0;
      r_sel <= 2'd0; r_ibase <= 13'd0; r_ilen <= 13'd0; r_obase <= 13'd0;
      cnt <= 13'd0; byte_rd_addr <= 13'd0;
      byte_wr_addr <= 13'd0; byte_wr_data <= 8'd0; byte_wr_en <= 1'b0;
      h_start <= 1'b0; h_len <= 10'd0; h_wa <= 11'd0; h_wd <= 8'd0; h_we <= 1'b0;
      g_start <= 1'b0; g_len <= 10'd0; g_wa <= 11'd0; g_wd <= 8'd0; g_we <= 1'b0;
      j_start <= 1'b0; j_mlen <= 10'd0; j_olen <= 10'd0;
      j_wa <= 11'd0; j_wd <= 8'd0; j_we <= 1'b0; j_ra <= 10'd0;
    end else begin
      done <= 1'b0; byte_wr_en <= 1'b0;
      h_start <= 1'b0; h_we <= 1'b0;
      g_start <= 1'b0; g_we <= 1'b0;
      j_start <= 1'b0; j_we <= 1'b0;

      case (state)
        S_IDLE: begin
          active <= 1'b0;
          if (start) begin
            r_sel <= hsel; r_ibase <= in_base; r_ilen <= in_len;
            r_obase <= out_base;
            cnt <= 13'd0; busy <= 1'b1; active <= 1'b1;
            byte_rd_addr <= in_base;
            state <= S_LD_W;
          end
        end

        // Stream the input into whichever core is selected.
        S_LD_W: state <= S_LD_B;
        S_LD_B: begin
          case (r_sel)
            H_H: begin h_wa <= cnt[10:0]; h_wd <= byte_rd_data; h_we <= 1'b1; end
            H_G: begin g_wa <= cnt[10:0]; g_wd <= byte_rd_data; g_we <= 1'b1; end
            default: begin j_wa <= cnt[10:0]; j_wd <= byte_rd_data; j_we <= 1'b1; end
          endcase
          if (cnt == r_ilen - 13'd1) begin
            cnt <= 13'd0;
            state <= S_GO;
          end else begin
            byte_rd_addr <= r_ibase + cnt + 13'd1;
            cnt <= cnt + 13'd1;
            state <= S_LD_W;
          end
        end

        S_GO: begin
          case (r_sel)
            H_H: begin h_len <= r_ilen[9:0]; h_start <= 1'b1; end
            H_G: begin g_len <= r_ilen[9:0]; g_start <= 1'b1; end
            default: begin
              j_mlen <= r_ilen[9:0]; j_olen <= 10'd32; j_start <= 1'b1;
            end
          endcase
          state <= S_ARM;
        end

        // Gate on busy, never on the level-held done.
        S_ARM: if ((r_sel == H_H && h_busy) || (r_sel == H_G && g_busy) ||
                   (r_sel == H_J && j_busy)) state <= S_RUN;
        S_RUN: if (!((r_sel == H_H && h_busy) || (r_sel == H_G && g_busy) ||
                     (r_sel == H_J && j_busy))) begin
          cnt <= 13'd0;
          if (r_sel == H_J) begin j_ra <= 10'd0; state <= S_JRD; end
          else state <= S_WR;
        end

        // H -> 32 bytes, G -> 64 bytes, straight out of the digest register.
        S_WR: begin
          byte_wr_addr <= r_obase + cnt;
          byte_wr_data <= (r_sel == H_H) ? h_byte : g_byte;
          byte_wr_en   <= 1'b1;
          if (cnt == ((r_sel == H_H) ? 13'd31 : 13'd63)) state <= S_FIN;
          else cnt <= cnt + 13'd1;
        end

        // SHAKE keeps its output in a memory; rd_data is combinational.
        S_JRD: begin
          byte_wr_addr <= r_obase + cnt;
          byte_wr_data <= j_rd;
          byte_wr_en   <= 1'b1;
          if (cnt == 13'd31) state <= S_FIN;
          else begin
            j_ra <= j_ra + 10'd1;
            cnt  <= cnt + 11'd1;
          end
        end

        S_FIN: begin
          busy <= 1'b0; done <= 1'b1; active <= 1'b0;
          state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule : mlkem_hash_unit
