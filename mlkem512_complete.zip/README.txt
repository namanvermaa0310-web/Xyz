ML-KEM-512 (FIPS 203) on Kintex-7 -- complete implementation
=============================================================

    bash run.sh

    1. kpke_engine call sequences ..... PASS  (21 / 28 / 11 service calls)
    2. codec ops ...................... PASS
    3. K-PKE KeyGen  (Alg 13) ......... PASS  768 ek + rho + 768 dk bytes
    4. K-PKE Encrypt (Alg 14) ......... PASS  768/768 ciphertext bytes
    5. K-PKE Decrypt (Alg 15) ......... PASS  32/32 message bytes
    6. FULL ML-KEM   (Algs 16/17/18) .. PASS  shared secret agreement +
                                              implicit rejection

Suite 6 is the one that defines a working KEM:

    [TB] Encaps shared secret matches golden (32/32)
    [TB] Encaps ciphertext matches golden (768/768)
    [TB] *** SHARED SECRET AGREEMENT: K' == K, 32/32 bytes ***
    [TB] corrupted ciphertext correctly rejected
    [TB] rejection secret differs from K, as required

Encaps and Decaps independently derive the SAME 32-byte secret, and a single
flipped ciphertext bit produces a DIFFERENT secret rather than the real one.
That second property is what makes this CCA-secure rather than merely
CPA-secure, and a design can look entirely functional while getting it wrong.

VERIFICATION PROVENANCE
-----------------------
golden_mlkem.py is checked byte-for-byte against kyber-py 1.2.0 -- ek, dk,
ciphertext, shared secret AND the implicit-rejection value all match. Below
that, every primitive has been verified independently:
  * 128 twiddle constants match the FIPS 203 Appendix A table
  * Barrett reduction proven exact by exhaustive check over all 11,075,585
    possible products
  * Compress/Decompress, ByteEncode/Decode, cbd3 and the zeta table all
    cross-checked against the CRYSTALS-Kyber C reference
  * SHA3-256/512 and SHAKE-128/256 against FIPS 202 vectors, including
    multi-block absorb and multi-block squeeze

*** FIPS 203, NOT round-3 Kyber ***
Round-3 ends Encaps/Decaps with ss = KDF(pre_k || H(c)). FIPS 203 removed it:
the shared secret is K straight out of G. This implements the FIPS 203 form.

DESIGN RULE LEARNED THE HARD WAY
--------------------------------
NEVER poll a sub-block's `done`. ALWAYS gate on `busy` rising then falling.
Level-held `done` caused the same bug SEVEN times in this project -- a caller
sees the PREVIOUS operation's completion, skips the current one, and produces
plausible-but-wrong data rather than an obvious hang. The last instance was
verify_cmov's own done: on the second Decaps the FO check exited before the
compare ran and returned the real key for a corrupted ciphertext. Its `busy`
output had simply been left unconnected.

VIVADO
------
mlkem_system_synth.xdc (whole KEM) and kpke_system_synth.xdc (K-PKE only).
Both are timing-only: a 100 MHz create_clock, boundary false paths, and
NSTD-1/UCIO-1 downgraded so implementation can finish without pin
assignments.

    Synthesis -> Implementation -> Report Timing Summary -> STOP.

Do NOT Generate Bitstream. These are internal blocks with hundreds of
unpinned port bits; that DRC error is correct and expected.

REFERENCE POINT: kpke_top (the K-PKE datapath alone) closed at
WNS = +0.449 ns, 0 failing endpoints of 56,684. mlkem_system adds the FO
sequencer, three more Keccak sponges and verify_cmov on top, and
kpke_datapath has itself grown since. +0.449 ns was already thin -- do not
assume it still holds. If WNS goes negative, record the worst path's
startpoint and endpoint; which module owns it decides the fix.

WHAT THIS IS, AND WHAT IT IS NOT
--------------------------------
IS:  a functionally complete, independently cross-verified ML-KEM-512
     implementation whose K-PKE datapath is synthesised and timing-closed
     at 100 MHz on xc7k325t.

IS NOT:
  * NIST CAVP-validated. ACVP tests whole KEMs, so this is now testable in
    principle -- but the vectors have not been run.
  * Hardware-validated. Phases 1 and 2 (NTT, Keccak) ran on a KC705; the
    full KEM has not. That needs a board wrapper + pin XDC + host driver,
    the same shape Phases 1-3 already have.
  * Side-channel analysed. verify_cmov is constant-time by construction and
    its timing invariance is asserted in simulation (2401 cycles either way);
    nothing else has been examined.
  * Performance-optimised. The NTT is a latency pipeline with no overlap
    between butterflies -- roughly 6x is available from overlapping alone,
    before any parallelism.
