module ntt_engine (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire        mode,
  output wire        done,
  output wire        busy,
  input  wire [7:0]  wr_addr,
  input  wire [15:0] wr_data,
  input  wire        wr_en,
  input  wire [7:0]  rd_addr,
  output wire [15:0] rd_data
);
  import mlkem_pkg::*;

  //==========================================================================
  // TIMING HISTORY (why this is pipelined the way it is)
  //   v1: single-cycle ST_COMPUTE doing butterfly AND N^-1 normalization
  //       -> WNS = -17.638 ns @ 100 MHz, 1391 failing endpoints.
  //   v2: split normalization into its own ST_NORM state
  //       -> WNS = -5.13 ns. Better, still failing.
  //   v3 (this): every pipeline stage now holds AT MOST ONE multiplier.
  //       A single butterfly chains three multiplies (zeta*data_b, then
  //       *20159 and *3329 for the Barrett reduction); those are now on
  //       three separate clock edges. Cost: 6 cycles/butterfly instead of
  //       3, so a full transform is 5376 cycles rather than 2688.
  //==========================================================================

  //==========================================================================
  // Coefficient Memory
  //==========================================================================
  (* ram_style = "block" *) reg [15:0] coeff_mem [0:255];
  integer i;
  initial for (i = 0; i < 256; i = i + 1) coeff_mem[i] = 16'd0;

  always @(posedge clk) begin
    if (state == ST_WRITE) begin
      coeff_mem[internal_wr_addr_a] = internal_wr_a;
      coeff_mem[internal_wr_addr_b] = internal_wr_b;
    end else if (wr_en) begin
      coeff_mem[wr_addr] = wr_data;
    end
  end

  assign rd_data = coeff_mem[rd_addr];

  //==========================================================================
  // Twiddle ROM
  //==========================================================================
  wire [6:0]  twiddle_addr;
  wire [15:0] twiddle_data;
  twiddle_rom u_twiddle_rom (.addr(twiddle_addr), .data(twiddle_data));

  //==========================================================================
  // FSM
  //   ST_READ  : fetch data_a, data_b, zeta from memory/ROM
  //   ST_MUL   : one multiply  -- zeta * mul_in
  //   ST_R1    : one multiply  -- Barrett estimate (* 20159)
  //   ST_R2    : one multiply  -- Barrett correction (* 3329), then reduce
  //   ST_BFLY  : adds/subs only; final result unless N^-1 scaling is needed
  //   ST_NM    : one multiply  -- (* 3303), last INTT stage only
  //   ST_NR1   : one multiply  -- Barrett estimate for the normalized value
  //   ST_NR2   : one multiply  -- Barrett correction, then reduce
  //   ST_WRITE : commit both coefficients back to memory
  //==========================================================================
  reg [3:0] state = ST_IDLE;
  localparam ST_IDLE  = 4'd0;
  localparam ST_READ  = 4'd1;
  localparam ST_MUL   = 4'd2;
  localparam ST_R1    = 4'd3;
  localparam ST_R2    = 4'd4;
  localparam ST_BFLY  = 4'd5;
  localparam ST_NM    = 4'd6;
  localparam ST_NR1   = 4'd7;
  localparam ST_NR2   = 4'd8;
  localparam ST_WRITE = 4'd9;

  wire need_norm = mode && last_stage;

  always @(posedge clk) begin
    if (!rst_n) state <= ST_IDLE;
    else begin
      case (state)
        ST_IDLE:  if (start) state <= ST_READ;
        ST_READ:  state <= ST_MUL;
        ST_MUL:   state <= ST_R1;
        ST_R1:    state <= ST_R2;
        ST_R2:    state <= ST_BFLY;
        ST_BFLY:  state <= need_norm ? ST_NM : ST_WRITE;
        ST_NM:    state <= ST_NR1;
        ST_NR1:   state <= ST_NR2;
        ST_NR2:   state <= ST_WRITE;
        ST_WRITE: state <= last_butterfly ? ST_IDLE : ST_READ;
        default:  state <= ST_IDLE;
      endcase
    end
  end

  assign busy = (state != ST_IDLE);
  assign done = (state == ST_IDLE) && was_last;

  //==========================================================================
  // Counters (advance only in ST_WRITE, so stage/group/offset and everything
  // derived from them are stable for the whole butterfly pipeline)
  //==========================================================================
  reg [2:0] stage = 3'd0;
  reg [6:0] group = 7'd0;
  reg [7:0] offset = 8'd0;
  reg       was_last = 1'b0;

  always @(posedge clk) begin
    if (!rst_n) begin
      stage <= 3'd0; group <= 7'd0; offset <= 8'd0; was_last <= 1'b0;
    end else if (state == ST_IDLE && start) begin
      stage <= 3'd0; group <= 7'd0; offset <= 8'd0; was_last <= 1'b0;
    end else if (state == ST_WRITE) begin
      was_last <= last_butterfly;
      if (!last_offset) begin
        offset <= offset + 8'd1;
      end else begin
        offset <= 8'd0;
        if (!last_group) begin
          group <= group + 7'd1;
        end else begin
          group <= 7'd0;
          if (!last_stage) stage <= stage + 3'd1;
        end
      end
    end
  end

  //==========================================================================
  // Combinational: len, num_groups, intt_prev_groups
  //==========================================================================
  wire [7:0] len;
  wire [6:0] num_groups;
  wire [6:0] intt_prev_groups;

  assign len = (mode == MODE_NTT) ?
    ((stage == 3'd0) ? 8'd128 : (stage == 3'd1) ? 8'd64  : (stage == 3'd2) ? 8'd32  :
     (stage == 3'd3) ? 8'd16  : (stage == 3'd4) ? 8'd8   : (stage == 3'd5) ? 8'd4   :
     (stage == 3'd6) ? 8'd2   : 8'd128) :
    ((stage == 3'd0) ? 8'd2   : (stage == 3'd1) ? 8'd4   : (stage == 3'd2) ? 8'd8   :
     (stage == 3'd3) ? 8'd16  : (stage == 3'd4) ? 8'd32  : (stage == 3'd5) ? 8'd64  :
     (stage == 3'd6) ? 8'd128 : 8'd2);

  assign num_groups = (mode == MODE_NTT) ?
    ((stage == 3'd0) ? 7'd1  : (stage == 3'd1) ? 7'd2  : (stage == 3'd2) ? 7'd4  :
     (stage == 3'd3) ? 7'd8  : (stage == 3'd4) ? 7'd16 : (stage == 3'd5) ? 7'd32 :
     (stage == 3'd6) ? 7'd64 : 7'd1) :
    ((stage == 3'd0) ? 7'd64 : (stage == 3'd1) ? 7'd32 : (stage == 3'd2) ? 7'd16 :
     (stage == 3'd3) ? 7'd8  : (stage == 3'd4) ? 7'd4  : (stage == 3'd5) ? 7'd2  :
     (stage == 3'd6) ? 7'd1  : 7'd64);

  assign intt_prev_groups = (mode == MODE_NTT) ? 7'd0 :
    ((stage == 3'd0) ? 7'd0   : (stage == 3'd1) ? 7'd64  : (stage == 3'd2) ? 7'd96  :
     (stage == 3'd3) ? 7'd112 : (stage == 3'd4) ? 7'd120 : (stage == 3'd5) ? 7'd124 :
     (stage == 3'd6) ? 7'd126 : 7'd0);

  //==========================================================================
  // Combinational: last detection, addresses, twiddle
  //==========================================================================
  wire last_offset    = ({1'b0, offset} == (len - 8'd1));
  wire last_group     = (group == (num_groups - 7'd1));
  wire last_stage     = (stage == 3'd6);
  wire last_butterfly = last_offset && last_group && last_stage;

  wire [7:0] addr_a, addr_b;
  wire [15:0] start_addr_calc = {1'b0, group} * (len << 1);
  wire [7:0]  start_addr = start_addr_calc[7:0];
  assign addr_a = start_addr + offset[7:0];
  assign addr_b = addr_a + len[7:0];

  assign twiddle_addr = mode ? (7'd127 - intt_prev_groups - group)
                              : ((7'd1 << stage) + {1'b0, group});

  //==========================================================================
  // Pipeline registers
  //==========================================================================
  reg [15:0] data_a, data_b, zeta;
  reg [7:0]  internal_wr_addr_a = 8'd0;
  reg [7:0]  internal_wr_addr_b = 8'd0;
  reg [15:0] internal_wr_a = 16'd0;
  reg [15:0] internal_wr_b = 16'd0;

  reg [31:0] prod_reg;        // zeta * mul_in
  reg [15:0] keep_a_reg;      // data_a (NTT) or (a+b) mod q (INTT)
  reg [23:0] prod_hold;       // low 24 bits of prod, carried alongside tval
  reg [12:0] tval_reg;        // Barrett quotient estimate
  reg [15:0] t_reg;           // reduced product, mod q

  reg [31:0] nprod_a, nprod_b;
  reg [23:0] nhold_a, nhold_b;
  reg [12:0] ntval_a, ntval_b;
  reg [15:0] pre_a_reg, pre_b_reg;

  //==========================================================================
  // ST_READ: fetch operands
  //==========================================================================
  always @(posedge clk) begin
    if (state == ST_READ) begin
      data_a <= coeff_mem[addr_a];
      data_b <= coeff_mem[addr_b];
      zeta   <= twiddle_data;
      internal_wr_addr_a <= addr_a;
      internal_wr_addr_b <= addr_b;
    end
  end

  //==========================================================================
  // ST_MUL inputs (combinational, adds/subs only -- no multiplier here)
  //   NTT : multiply data_b by zeta;      keep data_a for the final add/sub
  //   INTT: multiply (b-a) mod q by zeta; keep (a+b) mod q as out_a
  //==========================================================================
  wire [16:0] sum_ab   = data_a + data_b;
  wire [15:0] sum_ab_q = (sum_ab >= 17'd3329) ? (sum_ab - 17'd3329) : sum_ab[15:0];

  wire signed [16:0] sub_ba   = $signed(data_b) - $signed(data_a);
  wire [15:0]        sub_ba_q = sub_ba[16] ? (sub_ba[15:0] + 16'd3329) : sub_ba[15:0];

  wire [15:0] mul_in = mode ? sub_ba_q : data_b;
  wire [15:0] keep_a = mode ? sum_ab_q : data_a;

  //==========================================================================
  // Barrett reduction, split across ST_R1 / ST_R2 (one multiply each)
  //==========================================================================
  wire [38:0] bar_est   = (prod_reg[23:0] * 24'd20159) + 26'd33554432;   // ST_R1
  wire [24:0] bar_diff  = {1'b0, prod_hold} - (tval_reg * 25'd3329);     // ST_R2
  wire [15:0] bar_out   = bar_diff[24] ? (bar_diff[15:0] + 16'd3329) :
                          (bar_diff >= 25'd3329) ? (bar_diff[15:0] - 16'd3329) :
                          bar_diff[15:0];

  //==========================================================================
  // ST_BFLY: final combine, adds/subs only
  //==========================================================================
  wire [16:0] fin_sum   = keep_a_reg + t_reg;
  wire [15:0] ntt_out_a = (fin_sum >= 17'd3329) ? (fin_sum - 17'd3329) : fin_sum[15:0];
  wire signed [16:0] fin_sub = $signed(keep_a_reg) - $signed(t_reg);
  wire [15:0] ntt_out_b = fin_sub[16] ? (fin_sub[15:0] + 16'd3329) : fin_sub[15:0];

  wire [15:0] out_a_pre = mode ? keep_a_reg : ntt_out_a;   // INTT out_a = (a+b) mod q
  wire [15:0] out_b_pre = mode ? t_reg      : ntt_out_b;   // INTT out_b = reduced prod

  //==========================================================================
  // N^-1 normalization, split across ST_NM / ST_NR1 / ST_NR2 (last INTT stage)
  //==========================================================================
  wire [38:0] nbar_est_a = (nprod_a[23:0] * 24'd20159) + 26'd33554432;   // ST_NR1
  wire [38:0] nbar_est_b = (nprod_b[23:0] * 24'd20159) + 26'd33554432;   // ST_NR1

  wire [24:0] nbar_diff_a = {1'b0, nhold_a} - (ntval_a * 25'd3329);      // ST_NR2
  wire [15:0] nbar_out_a  = nbar_diff_a[24] ? (nbar_diff_a[15:0] + 16'd3329) :
                            (nbar_diff_a >= 25'd3329) ? (nbar_diff_a[15:0] - 16'd3329) :
                            nbar_diff_a[15:0];

  wire [24:0] nbar_diff_b = {1'b0, nhold_b} - (ntval_b * 25'd3329);      // ST_NR2
  wire [15:0] nbar_out_b  = nbar_diff_b[24] ? (nbar_diff_b[15:0] + 16'd3329) :
                            (nbar_diff_b >= 25'd3329) ? (nbar_diff_b[15:0] - 16'd3329) :
                            nbar_diff_b[15:0];

  //==========================================================================
  // SINGLE always block for all datapath pipeline registers.
  // (Two separate blocks driving internal_wr_a/b previously caused
  //  DRC MDRV-1 Multiple Driver Nets -- keep every assignment here.)
  //==========================================================================
  always @(posedge clk) begin
    case (state)
      ST_MUL: begin
        prod_reg   <= zeta * mul_in;
        keep_a_reg <= keep_a;
      end

      ST_R1: begin
        tval_reg  <= bar_est[38:26];
        prod_hold <= prod_reg[23:0];
      end

      ST_R2: begin
        t_reg <= bar_out;
      end

      ST_BFLY: begin
        if (need_norm) begin
          pre_a_reg <= out_a_pre;
          pre_b_reg <= out_b_pre;
        end else begin
          internal_wr_a <= out_a_pre;
          internal_wr_b <= out_b_pre;
        end
      end

      ST_NM: begin
        nprod_a <= pre_a_reg * 16'd3303;
        nprod_b <= pre_b_reg * 16'd3303;
      end

      ST_NR1: begin
        ntval_a <= nbar_est_a[38:26];
        ntval_b <= nbar_est_b[38:26];
        nhold_a <= nprod_a[23:0];
        nhold_b <= nprod_b[23:0];
      end

      ST_NR2: begin
        internal_wr_a <= nbar_out_a;
        internal_wr_b <= nbar_out_b;
      end

      default: ;
    endcase
  end

endmodule : ntt_engine
