// =============================================================================
// mlkem_system.sv -- complete ML-KEM-512 (FIPS 203 Algorithms 16, 17, 18)
// -----------------------------------------------------------------------------
// Ties together everything below it:
//     kpke_system      K-PKE KeyGen / Encrypt / Decrypt  (Algs 13/14/15)
//     mlkem_hash_unit  H, G and J over the 800-byte buffers
//     verify_cmov      constant-time ciphertext compare and key select
//
// The FO sequencing lives here rather than in mlkem_fo_ctrl because the
// buffer offsets are part of the sequence and only this level knows them.
// mlkem_fo_ctrl remains as the independently-verified reference for the call
// ORDER; this module implements that order against real hardware.
//
// *** FIPS 203, NOT round-3 Kyber. ***
// Round-3 ends Encaps and Decaps with ss = KDF(pre_k || H(c)). FIPS 203
// removed that: the shared secret is K straight out of G. Implementing the
// round-3 form would produce a self-consistent KEM that matches no ACVP
// vector and interoperates with nothing.
//
// BYTE MAP (all in one shared buffer)
//     0     ciphertext c            768 B
//     1024  dk_pke                  768 B
//     1792  ek                      800 B   (768 encoded + 32 rho)
//     1868  message m / m'           32 B   -- inside ek's span by design:
//                                             see note below
//     1900  encryption coins r       32 B
//     2600  H(ek) / h                32 B
//     2632  G output (K || r')       64 B
//     2696  Kbar = J(z||c)           32 B
//     2728  z (rejection seed)       32 B
//     2760  shared secret out        32 B
// NOTE: msg and coins sit at 1868/1900 because kpke_engine already uses those
// offsets, and ek is relocated to 1792 to keep clear of them.
// =============================================================================
module mlkem_system #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13
)(
  input  wire        clk,
  input  wire        rst_n,
  input  wire [1:0]  op,          // 0 = KeyGen, 1 = Encaps, 2 = Decaps
  input  wire        start,
  output reg         busy,
  output reg         done,

  input  wire [7:0]  d_rd_data,
  output wire [5:0]  d_rd_addr,

  // shared byte buffer, owned by the caller
  output wire [12:0] byte_rd_addr,
  input  wire [7:0]  byte_rd_data,
  // Second read port. verify_cmov compares the received ciphertext against
  // the re-encrypted one BYTE BY BYTE IN THE SAME CYCLE, which a single read
  // port cannot serve. A real BRAM has two read ports; this exposes the
  // second one rather than serialising the compare.
  output wire [12:0] byte_rd2_addr,
  input  wire [7:0]  byte_rd2_data,
  output wire [12:0] byte_wr_addr,
  output wire [7:0]  byte_wr_data,
  output wire        byte_wr_en,

  output wire [255:0] rho_out,
  output wire         sample_error,
  output reg          reject,      // 1 = implicit rejection path was taken
  output reg  [4:0]   dbg_state
);

  localparam [12:0] CT_BASE   = 13'd0;      // ciphertext c, 768 B
  localparam [12:0] DK_BASE   = 13'd1024;   // dk_pke,        768 B
  // m and coins are FIXED at these offsets by kpke_engine, so every other
  // region is placed around them. An earlier map put ek at 1792, whose
  // 800-byte span swallowed both -- m silently overwrote ek[76..107] and
  // H(ek) was therefore computed over corrupted data while every upstream
  // value still looked correct.
  localparam [12:0] MSG_BASE  = 13'd1868;   // message m / m', 32 B
  localparam [12:0] COINS_BASE= 13'd1900;   // coins r,        32 B
  localparam [12:0] EK_BASE   = 13'd2048;   // ek,            800 B (..2847)
  localparam [12:0] HEK_BASE  = 13'd2900;   // H(ek) / h,      32 B
  localparam [12:0] G_BASE    = 13'd2932;   // G out (K || r), 64 B
  localparam [12:0] KBAR_BASE = 13'd3000;   // Kbar,           32 B
  localparam [12:0] Z_BASE    = 13'd3100;   // z, then c: J hashes z||c
  localparam [12:0] SS_BASE   = 13'd3900;   // shared secret,  32 B
  localparam [12:0] CSAVE_BASE= 13'd3950;   // saved c,       768 B (..4717)
  localparam [12:0] GIN_BASE  = 13'd4750;   // staged m||H(ek), 64 B
  localparam [12:0] CT_LEN    = 13'd768;



  // ---------------------------------------------------------------------------
  // K-PKE
  // ---------------------------------------------------------------------------
  reg  [1:0] k_op; reg k_start;
  wire       k_busy, k_done;
  wire [12:0] k_br_addr, k_bw_addr;
  wire [7:0]  k_bw_data;
  wire        k_bw_en;

  kpke_system #(.K_PARAM(K_PARAM), .ADDR_W(ADDR_W), .EK_BASE_P(EK_BASE)) u_kpke (
    .clk(clk), .rst_n(rst_n), .op(k_op), .start(k_start),
    .busy(k_busy), .done(k_done),
    .d_rd_data(d_rd_data), .d_rd_addr(d_rd_addr),
    .byte_wr_addr(k_bw_addr), .byte_wr_data(k_bw_data), .byte_wr_en(k_bw_en),
    .byte_rd_addr(k_br_addr), .byte_rd_data(byte_rd_data),
    .rho_out(rho_out), .sample_error(sample_error), .dbg_engine_state());

  // ---------------------------------------------------------------------------
  // Hashes
  // ---------------------------------------------------------------------------
  reg  [1:0]  h_sel; reg [12:0] h_ib, h_il, h_ob; reg h_start;
  wire        h_busy, h_done, h_active;
  wire [12:0] h_br_addr, h_bw_addr;
  wire [7:0]  h_bw_data;
  wire        h_bw_en;
  wire [511:0] g_digest;

  mlkem_hash_unit #(.MAX_MSG(832)) u_hash (
    .clk(clk), .rst_n(rst_n),
    .hsel(h_sel), .in_base(h_ib), .in_len(h_il), .out_base(h_ob),
    .start(h_start), .busy(h_busy), .done(h_done), .active(h_active),
    .byte_rd_addr(h_br_addr), .byte_rd_data(byte_rd_data),
    .byte_wr_addr(h_bw_addr), .byte_wr_data(h_bw_data),
    .byte_wr_en(h_bw_en), .g_digest(g_digest));

  // ---------------------------------------------------------------------------
  // Constant-time compare and select
  // ---------------------------------------------------------------------------
  reg         v_start;
  wire        v_done, v_fail, v_sel, v_busy;
  wire [9:0]  v_c_addr, v_cp_addr;
  wire [5:0]  v_k_addr, v_ss_addr;
  wire [7:0]  v_ss_data;
  wire        v_ss_en;
  reg  [7:0]  v_c_data, v_cp_data, v_kp_data, v_kb_data;

  verify_cmov #(.CT_BYTES(768), .SS_BYTES(32)) u_vc (
    .clk(clk), .rst_n(rst_n), .start(v_start),
    .c_rd_addr(v_c_addr),  .c_rd_data(v_c_data),
    .cp_rd_addr(v_cp_addr), .cp_rd_data(v_cp_data),
    .k_rd_addr(v_k_addr),
    .kprime_rd_data(v_kp_data), .kbar_rd_data(v_kb_data),
    .ss_wr_addr(v_ss_addr), .ss_wr_data(v_ss_data), .ss_wr_en(v_ss_en),
    .sel_phase(v_sel), .fail(v_fail), .busy(v_busy), .done(v_done));

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  localparam S_IDLE     = 5'd0;
  localparam S_WAIT_K   = 5'd1;
  localparam S_WAIT_H   = 5'd2;
  // KeyGen
  localparam S_KG_PKE   = 5'd3;
  localparam S_KG_HEK   = 5'd4;
  // Encaps
  localparam S_EN_HEK   = 5'd5;
  localparam S_EN_G     = 5'd6;
  localparam S_EN_CPK   = 5'd7;   // copy G[0:32] -> shared secret
  localparam S_EN_CPR   = 5'd8;   // copy G[32:64] -> coins
  localparam S_EN_ENC   = 5'd9;
  // Decaps
  localparam S_DE_DEC   = 5'd10;
  localparam S_DE_G     = 5'd11;
  localparam S_DE_CPR   = 5'd12;
  localparam S_DE_J     = 5'd13;
  localparam S_DE_REENC = 5'd14;
  localparam S_DE_VER   = 5'd15;
  localparam S_FIN      = 5'd16;
  localparam S_CPY      = 5'd17;  // generic byte copy helper
  localparam S_CPY_W    = 5'd18;  // settle: the byte read is registered
  localparam S_DE_SAVE  = 5'd19;  // stash c before re-encryption
  localparam S_DE_VWAIT = 5'd20;
  localparam S_EN_STG2  = 5'd21;
  localparam S_EN_GGO   = 5'd22;
  localparam S_DE_STG2  = 5'd23;
  localparam S_DE_GGO   = 5'd24;
  localparam S_DE_SAVEW = 5'd25;   // settle before the first ciphertext byte
  localparam S_DE_SAVED = 5'd26;   // drain: let the LAST write land
  // Arm states: wait for the sub-block's BUSY to RISE before waiting for it
  // to fall. kpke_system's and the hash unit's `done` are LEVEL-HELD, so a
  // bare "!busy && done" falls straight through on the PREVIOUS operation's
  // completion. That made verify_cmov start while the Decaps re-encryption
  // had barely begun -- it compared the ciphertext against itself and
  // reported a match for a corrupted input, silently breaking CCA security.
  // Sixth time this pattern has appeared in this project.
  localparam S_ARM_K    = 5'd27;
  localparam S_ARM_H    = 5'd28;
  // verify_cmov's `done` is LEVEL-HELD too: it stays asserted after a run
  // until the next start. On the SECOND Decaps, S_DE_VWAIT saw the previous
  // run's done and exited before the compare had executed, latching the stale
  // verdict and returning the REAL key for a corrupted ciphertext. Gate on
  // busy instead. Seventh occurrence of this pattern in this project.
  localparam S_ARM_V    = 5'd29;

  reg [4:0] state, ret_state;
  reg [12:0] cp_src, cp_dst; reg [6:0] cp_len, cp_i;
  reg [12:0] cs_i;   // ciphertext-save counter (needs 12 bits)
  reg [12:0] seq_rd, seq_wr; reg [7:0] seq_wd; reg seq_we;
  reg        own_bus;    // this FSM owns the byte ports

  always @(*) dbg_state = state;

  // Byte-port arbitration. Exactly one owner at a time; the K-PKE and hash
  // units are never active simultaneously because each is waited on to
  // completion before the next is started.
  assign byte_rd_addr = vc_run
                      ? (v_sel ? (G_BASE + {7'd0, v_k_addr})
                               : (CT_BASE + {3'd0, v_c_addr}))
                      : own_bus ? seq_rd
                      : (h_active ? h_br_addr : k_br_addr);
  assign byte_wr_addr = vc_run ? (SS_BASE + {7'd0, v_ss_addr})
                      : own_bus ? seq_wr
                      : (h_active ? h_bw_addr : k_bw_addr);
  assign byte_wr_data = vc_run ? v_ss_data
                      : own_bus ? seq_wd
                      : (h_active ? h_bw_data : k_bw_data);
  assign byte_wr_en   = vc_run ? v_ss_en
                      : own_bus ? seq_we
                      : (h_active ? h_bw_en : k_bw_en);

  // verify_cmov reads three regions of the same buffer; drive them from the
  // sequencer's read port while it is running.
  // During the compare, port 1 walks the re-encrypted ciphertext / K'
  // and port 2 walks the saved ciphertext / Kbar.
  // verify_cmov owns the byte buses for its ENTIRE run, which happens in
  // S_DE_VWAIT -- S_DE_VER is a single cycle that only pulses v_start. Gating
  // on S_DE_VER alone left the compare running with its address and data
  // buses disconnected, so it saw stale bytes and always reported a match.
  wire vc_run = (state == S_DE_VER) || (state == S_ARM_V)
              || (state == S_DE_VWAIT);
  assign byte_rd2_addr = vc_run
                       ? (v_sel ? (KBAR_BASE + {7'd0, v_k_addr})
                                : (CSAVE_BASE + {3'd0, v_cp_addr}))
                       : (KBAR_BASE + {7'd0, v_k_addr});
  always @(*) begin
    v_c_data  = byte_rd_data;     // c'   (re-encrypted, at CT_BASE)
    v_cp_data = byte_rd2_data;    // c    (saved copy)
    v_kp_data = byte_rd_data;     // K'   (from G output)
    v_kb_data = byte_rd2_data;    // Kbar (from J output)
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; ret_state <= S_IDLE;
      busy <= 1'b0; done <= 1'b0; reject <= 1'b0; own_bus <= 1'b0;
      k_op <= 2'd0; k_start <= 1'b0;
      h_sel <= 2'd0; h_ib <= 13'd0; h_il <= 13'd0; h_ob <= 13'd0;
      h_start <= 1'b0; v_start <= 1'b0;
      cp_src <= 13'd0; cp_dst <= 13'd0; cp_len <= 7'd0; cp_i <= 7'd0;
      cs_i <= 13'd0;
      seq_rd <= 13'd0; seq_wr <= 13'd0; seq_wd <= 8'd0; seq_we <= 1'b0;
    end else begin
      k_start <= 1'b0; h_start <= 1'b0; v_start <= 1'b0;
      seq_we  <= 1'b0; done <= 1'b0;
      case (state)
        S_IDLE: begin
          own_bus <= 1'b0;
          if (start) begin
            busy <= 1'b1; reject <= 1'b0;
            case (op)
              2'd0: begin
                k_op <= 2'd0; k_start <= 1'b1;
                ret_state <= S_KG_PKE; state <= S_ARM_K;
              end
              2'd1: begin
                h_sel <= 2'd0; h_ib <= EK_BASE; h_il <= 13'd800;
                h_ob <= HEK_BASE; h_start <= 1'b1;
                ret_state <= S_EN_HEK; state <= S_ARM_H;
              end
              2'd2: begin
                // Stash the received ciphertext before anything can clobber it.
                own_bus <= 1'b1;
                cp_src <= CT_BASE; cp_dst <= CSAVE_BASE;
                cp_len <= 7'd0;             // 0 => full CT_LEN, see S_DE_SAVE
                cp_i <= 7'd0; seq_rd <= CT_BASE;
                state <= S_DE_SAVEW;
              end
              default: begin busy <= 1'b0; state <= S_IDLE; end
            endcase
          end
        end

        // ---------------- Algorithm 16: KeyGen ---------------------------
        S_KG_PKE: begin
          h_sel <= 2'd0; h_ib <= EK_BASE; h_il <= 13'd800;
          h_ob <= HEK_BASE; h_start <= 1'b1;
          ret_state <= S_KG_HEK; state <= S_ARM_H;
        end
        // dk = dk_pke || ek || H(ek) || z is a memory layout the caller owns;
        // every part is already in the buffer once H(ek) lands.
        S_KG_HEK: state <= S_FIN;

        // ---------------- Algorithm 17: Encaps ---------------------------
        S_EN_HEK: begin
          own_bus <= 1'b1;
          cp_src <= MSG_BASE; cp_dst <= GIN_BASE; cp_len <= 7'd32; cp_i <= 7'd0;
          seq_rd <= MSG_BASE; ret_state <= S_EN_STG2;
          state <= S_CPY_W;
        end
        S_EN_STG2: begin
          cp_src <= HEK_BASE; cp_dst <= GIN_BASE + 12'd32;
          cp_len <= 7'd32; cp_i <= 7'd0;
          seq_rd <= HEK_BASE; ret_state <= S_EN_GGO;
          state <= S_CPY_W;
        end
        S_EN_GGO: begin
          own_bus <= 1'b0;
          h_sel <= 2'd1; h_ib <= GIN_BASE; h_il <= 13'd64;
          h_ob <= G_BASE; h_start <= 1'b1;
          ret_state <= S_EN_G; state <= S_ARM_H;
        end
        S_EN_G: begin
          cp_src <= G_BASE; cp_dst <= SS_BASE; cp_len <= 7'd32; cp_i <= 7'd0;
          own_bus <= 1'b1; ret_state <= S_EN_CPR;
          seq_rd <= G_BASE;
          state <= S_CPY_W;      // settle: the byte read is registered
        end
        S_EN_CPR: begin
          cp_src <= G_BASE + 12'd32; cp_dst <= COINS_BASE; cp_len <= 7'd32;
          cp_i <= 7'd0; ret_state <= S_EN_ENC;
          seq_rd <= G_BASE + 12'd32;
          state <= S_CPY_W;
        end
        S_EN_ENC: begin
          own_bus <= 1'b0;
          k_op <= 2'd1; k_start <= 1'b1;
          state <= S_ARM_K;
          ret_state <= S_FIN;
        end

        // Copy all CT_LEN bytes of c to CSAVE_BASE. cp_i is only 7 bits, so
        // this uses its own counter rather than the generic S_CPY helper.
        // The byte read is registered, so the data for CT_BASE is not on
        // byte_rd_data until one cycle after the address is driven. Skipping
        // this made the saved copy shift by one byte, and the FO compare then
        // reported a mismatch on a perfectly valid ciphertext.
        S_DE_SAVEW: begin
          seq_rd <= CT_BASE + 13'd1;
          state  <= S_DE_SAVE;
        end

        S_DE_SAVE: begin
          seq_wr <= CSAVE_BASE + cs_i;
          seq_wd <= byte_rd_data;
          seq_we <= 1'b1;
          if (cs_i == CT_LEN - 13'd1) begin
            // Do NOT clear own_bus here. seq_wr/seq_wd/seq_we are registered,
            // so the final byte's write is still pending on the NEXT cycle --
            // clearing own_bus now disconnects it from the mux and byte 767
            // is silently lost. That single missing byte made the FO compare
            // reject every valid ciphertext.
            cs_i  <= 13'd0;
            state <= S_DE_SAVED;
          end else begin
            seq_rd <= CT_BASE + cs_i + 12'd2;
            cs_i <= cs_i + 12'd1;
          end
        end

        // Hold the bus one more cycle so the last write completes, then go.
        S_DE_SAVED: begin
          own_bus <= 1'b0;
          k_op <= 2'd2; k_start <= 1'b1;
          ret_state <= S_DE_DEC; state <= S_ARM_K;
        end

        // ---------------- Algorithm 18: Decaps ---------------------------
        S_DE_DEC: begin
          own_bus <= 1'b1;
          cp_src <= MSG_BASE; cp_dst <= GIN_BASE; cp_len <= 7'd32; cp_i <= 7'd0;
          seq_rd <= MSG_BASE; ret_state <= S_DE_STG2;
          state <= S_CPY_W;
        end
        S_DE_STG2: begin
          cp_src <= HEK_BASE; cp_dst <= GIN_BASE + 12'd32;
          cp_len <= 7'd32; cp_i <= 7'd0;
          seq_rd <= HEK_BASE; ret_state <= S_DE_GGO;
          state <= S_CPY_W;
        end
        S_DE_GGO: begin
          own_bus <= 1'b0;
          h_sel <= 2'd1; h_ib <= GIN_BASE; h_il <= 13'd64;
          h_ob <= G_BASE; h_start <= 1'b1;
          ret_state <= S_DE_G; state <= S_ARM_H;
        end
        S_DE_G: begin
          cp_src <= G_BASE + 12'd32; cp_dst <= COINS_BASE; cp_len <= 7'd32;
          cp_i <= 7'd0; own_bus <= 1'b1; ret_state <= S_DE_J;
          seq_rd <= G_BASE + 12'd32;
          state <= S_CPY_W;
        end
        S_DE_J: begin
          own_bus <= 1'b0;
          // Kbar = J(z || c). z sits immediately before the ciphertext copy
          // the caller staged at Z_BASE.
          h_sel <= 2'd2; h_ib <= Z_BASE; h_il <= 13'd800;
          h_ob <= KBAR_BASE; h_start <= 1'b1;
          state <= S_ARM_H;
          ret_state <= S_DE_REENC;
        end
        S_DE_REENC: begin
          k_op <= 2'd1; k_start <= 1'b1;   // re-encrypt with m', r'
          state <= S_ARM_K;
          ret_state <= S_DE_VER;
        end
        // v_start must be a ONE-CYCLE pulse. Asserting it every cycle while
        // waiting restarts verify_cmov continuously and it never completes.
        S_DE_VER: begin
          v_start <= 1'b1;
          state   <= S_ARM_V;
        end
        S_ARM_V: if (v_busy) state <= S_DE_VWAIT;
        S_DE_VWAIT: if (!v_busy) begin
          reject <= v_fail;
          state  <= S_FIN;
        end

        // ---------------- helpers ----------------------------------------
        S_ARM_K:  if (k_busy) state <= S_WAIT_K;
        S_WAIT_K: if (!k_busy) state <= ret_state;
        S_ARM_H:  if (h_busy) state <= S_WAIT_H;
        S_WAIT_H: if (!h_busy) state <= ret_state;

        // Byte copy: read is registered, so data for the address driven last
        // cycle is available now.
        // One cycle for the registered read to present cp_src[cp_i].
        S_CPY_W: state <= S_CPY;

        S_CPY: begin
          seq_wr <= cp_dst + {6'd0, cp_i};
          seq_wd <= byte_rd_data;
          seq_we <= 1'b1;
          if (cp_i == cp_len - 7'd1) state <= ret_state;
          else begin
            seq_rd <= cp_src + {6'd0, cp_i} + 12'd1;
            cp_i <= cp_i + 7'd1;
            state <= S_CPY_W;
          end
        end

        S_FIN: begin
          own_bus <= 1'b0;
          busy <= 1'b0; done <= 1'b1;
          state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule : mlkem_system
