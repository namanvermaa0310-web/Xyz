// =============================================================================
// sample_ntt.sv -- FIPS 203 Algorithm 7: SampleNTT
// -----------------------------------------------------------------------------
// Converts a SHAKE-128 output stream into 256 coefficients uniformly
// distributed in Z_q via rejection sampling. Per the spec, each 3-byte
// chunk (b0, b1, b2) yields two 12-bit candidates:
//
//   d1 = b0 + 256 * (b1 mod 16)   =  {b1[3:0], b0}
//   d2 = floor(b1 / 16) + 16 * b2 =  {b2, b1[7:4]}
//
// A candidate is ACCEPTED only if it is < q = 3329; otherwise it is
// discarded and the stream advances. Acceptance probability is
// 3329/4096 ~= 0.813, so 256 coefficients need ~473 bytes on average.
// The caller provides stream_len; if the stream is exhausted before 256
// coefficients are accepted, `error` is raised (with SHAKE-128's 672-byte
// output this is astronomically unlikely, but the spec's XOF is unbounded,
// so a real KeyGen would re-squeeze -- flagged honestly as a limitation).
//
// Reads bytes through a 1-cycle-latency memory port (matches shake128's
// out_mem interface). Writes accepted coefficients through a standard
// wr_addr/wr_data/wr_en port.
// =============================================================================
module sample_ntt (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [9:0]  stream_len,     // available XOF bytes

  // XOF byte stream read port (combinational memory on the far side)
  output reg  [9:0]  byte_rd_addr,
  input  wire [7:0]  byte_rd_data,

  // Accepted-coefficient write port
  output reg  [7:0]  coeff_wr_addr,
  output reg  [15:0] coeff_wr_data,
  output reg         coeff_wr_en,

  output reg         busy,
  output reg         done,
  output reg         error           // stream exhausted before 256 accepts
);
  localparam [11:0] Q12 = 12'd3329;

  localparam ST_IDLE = 3'd0;
  localparam ST_RA0  = 3'd1;   // issue address of b0 (and exhaustion check)
  localparam ST_RA1  = 3'd2;   // latch b0, issue address of b1
  localparam ST_RA2  = 3'd3;   // latch b1, issue address of b2
  localparam ST_EVAL = 3'd4;   // latch b2
  localparam ST_WR1  = 3'd5;   // evaluate/write d1
  localparam ST_WR2  = 3'd6;   // evaluate/write d2, loop or finish
  localparam ST_DONE = 3'd7;

  reg [2:0] state;
  reg [9:0] idx;               // byte offset into the XOF stream
  reg [8:0] j;                 // accepted coefficient count (0..256)
  reg [7:0] b0, b1, b2;

  wire [11:0] d1 = {b1[3:0], b0};
  wire [11:0] d2 = {b2, b1[7:4]};
  wire        acc1 = (d1 < Q12);
  wire        acc2 = (d2 < Q12);

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; error <= 1'b0;
      byte_rd_addr <= 10'd0; coeff_wr_addr <= 8'd0; coeff_wr_data <= 16'd0;
      coeff_wr_en <= 1'b0; idx <= 10'd0; j <= 9'd0;
      b0 <= 8'd0; b1 <= 8'd0; b2 <= 8'd0;
    end else begin
      coeff_wr_en <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            busy <= 1'b1; done <= 1'b0; error <= 1'b0;
            idx <= 10'd0; j <= 9'd0;
            state <= ST_RA0;
          end
        end

        ST_RA0: begin
          if (idx + 10'd3 > stream_len) begin
            // Stream exhausted -- should never happen with 672 bytes
            error <= 1'b1; busy <= 1'b0; done <= 1'b1;
            state <= ST_DONE;
          end else begin
            byte_rd_addr <= idx;
            state <= ST_RA1;
          end
        end

        ST_RA1: begin
          b0 <= byte_rd_data;
          byte_rd_addr <= idx + 10'd1;
          state <= ST_RA2;
        end

        ST_RA2: begin
          b1 <= byte_rd_data;
          byte_rd_addr <= idx + 10'd2;
          state <= ST_EVAL;
        end

        ST_EVAL: begin
          b2 <= byte_rd_data;
          state <= ST_WR1;
        end

        ST_WR1: begin
          if (acc1) begin
            coeff_wr_addr <= j[7:0];
            coeff_wr_data <= {4'd0, d1};
            coeff_wr_en   <= 1'b1;
            j <= j + 9'd1;
          end
          state <= ST_WR2;
        end

        ST_WR2: begin
          idx <= idx + 10'd3;
          if (acc2 && (j < 9'd256)) begin
            coeff_wr_addr <= j[7:0];
            coeff_wr_data <= {4'd0, d2};
            coeff_wr_en   <= 1'b1;
            j <= j + 9'd1;
            if (j + 9'd1 == 9'd256) begin
              busy <= 1'b0; done <= 1'b1; state <= ST_DONE;
            end else state <= ST_RA0;
          end else begin
            if (j == 9'd256) begin
              busy <= 1'b0; done <= 1'b1; state <= ST_DONE;
            end else state <= ST_RA0;
          end
        end

        ST_DONE: begin
          done <= 1'b1;
          if (start) begin
            busy <= 1'b1; done <= 1'b0; error <= 1'b0;
            idx <= 10'd0; j <= 9'd0;
            state <= ST_RA0;
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : sample_ntt
