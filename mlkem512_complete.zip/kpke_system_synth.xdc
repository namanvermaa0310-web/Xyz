## =============================================================================
## kpke_system_synth.xdc -- constraints for kpke_system synthesis + timing
## Target: xc7k325tffg900-2
## =============================================================================
## SCOPE: synthesis and implementation ONLY, to obtain WNS and utilisation.
## This design does NOT produce a bitstream and Generate Bitstream should not
## be run on it -- see the note at the bottom.
##
## kpke_system has 304 top-level port bits (a 256-bit rho_out, an 11-bit byte
## address, a 6-bit debug state, and so on). It is an internal block driven by
## the FO layer, not a chip top, so there is nothing meaningful to pin. A board
## wrapper (IBUFDS + MMCM + reset synchroniser + UART bridge) exposing four
## real pins is what gets a pin XDC, exactly as Phases 1-3 have.
## =============================================================================

## -----------------------------------------------------------------------------
## Clock: 10 ns = 100 MHz, matching Phases 1-3
## -----------------------------------------------------------------------------
create_clock -period 10.000 -name clk [get_ports clk]

## Reset is asynchronous; it is synchronised in the board wrapper, which does
## not exist at this level.
set_false_path -from [get_ports rst_n]

## -----------------------------------------------------------------------------
## Unconstrained I/O
## -----------------------------------------------------------------------------
## Without PACKAGE_PIN / IOSTANDARD on the ports, Write Bitstream stops with
##   [DRC NSTD-1] Unspecified I/O Standard  (304 of 304 logical ports)
##   [DRC UCIO-1] Unconstrained Logical Port
## Those checks exist to stop a bitstream shipping with undefined I/O levels.
## Correct for a board build, irrelevant here because no bitstream is wanted.
## Downgrading them lets implementation finish so the timing report is real.
##
## Do NOT copy these two lines into a board XDC. If they ever fire on a design
## that is going onto hardware, fix the pins instead.
set_property SEVERITY {Warning} [get_drc_checks NSTD-1]
set_property SEVERITY {Warning} [get_drc_checks UCIO-1]

## -----------------------------------------------------------------------------
## Keep pad paths out of the timing picture
## -----------------------------------------------------------------------------
## With no input/output delays the tool would otherwise report meaningless
## paths from unconstrained pads. What matters here is the internal logic: the
## NTT butterfly, the Keccak round, the basemul chain and the memory paths.
set_false_path -from [all_inputs]    -to [all_registers]
set_false_path -from [all_registers] -to [all_outputs]

## -----------------------------------------------------------------------------
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 2.5 [current_design]

## =============================================================================
## HOW TO RUN THIS
##   Run Synthesis  -> Run Implementation  -> Report Timing Summary.  STOP.
##   Do not run Generate Bitstream. There are no pins; a bitstream would be
##   meaningless even if the DRC let it through.
##
## For reference, kpke_top (the datapath alone, one level down) closed at
## WNS = +0.449 ns with 0 failing endpoints of 56,684. kpke_system adds only
## kpke_engine, a small FSM, so a similar or slightly tighter number is
## expected. If WNS drops sharply, the engine's byte_base arithmetic or the
## unit_* fanout is the place to look.
## =============================================================================
