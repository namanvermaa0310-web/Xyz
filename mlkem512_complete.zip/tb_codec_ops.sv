`timescale 1ns/1ps
// Verify the NEW kpke_datapath codec ops in isolation:
//   ByteDecode_12, Compress_10 + pack, unpack + Decompress_10
module tb_codec_ops;
  localparam ADDR_W=13;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [2:0] usel,uop; reg [7:0] ua0,ua1,ua2; reg ustart; wire udone;
  wire [ADDR_W-1:0] ps_a,ps_b,ps_w; wire [15:0] ps_wd; wire ps_we;
  wire [15:0] ps_ad, ps_bd;
  wire [10:0] bw_a, br_a; wire [7:0] bw_d; wire bw_en; reg [7:0] br_d;
  reg [10:0] bbase; wire [5:0] dbg;

  poly_slots #(.NUM_SLOTS(24),.ADDR_W(ADDR_W)) u_s(.clk(clk),
    .a_addr(ps_a),.a_data(ps_ad),.b_addr(ps_b),.b_data(ps_bd),
    .w_addr(ps_w),.w_data(ps_wd),.w_en(ps_we));
  kpke_datapath #(.K_PARAM(2),.ADDR_W(ADDR_W)) dut(.clk(clk),.rst_n(rst_n),
    .unit_sel(usel),.unit_op(uop),.unit_a0(ua0),.unit_a1(ua1),.unit_a2(ua2),
    .unit_start(ustart),.unit_done(udone),
    .ps_a_addr(ps_a),.ps_a_data(ps_ad),.ps_b_addr(ps_b),.ps_b_data(ps_bd),
    .ps_w_addr(ps_w),.ps_w_data(ps_wd),.ps_w_en(ps_we),
    .byte_wr_addr(bw_a),.byte_wr_data(bw_d),.byte_wr_en(bw_en),
    .byte_rd_addr(br_a),.byte_rd_data(br_d),
    .byte_base(bbase),.dbg_state(dbg));

  reg [7:0] bmem[0:2047];
  always @(posedge clk) begin br_d <= bmem[br_a]; if (bw_en) bmem[bw_a] <= bw_d; end

  reg [7:0] g_bytes[0:383], g_packed[0:319];
  reg [15:0] g_coeffs[0:255], g_decomp[0:255];
  integer errors=0, i;

  task call(input [2:0] u,input [2:0] o,input [7:0] a0,input [7:0] a1,input [7:0] a2);
    begin
      @(negedge clk); usel=u;uop=o;ua0=a0;ua1=a1;ua2=a2;ustart=1;
      @(negedge clk); ustart=0;
      while(!udone) @(negedge clk);
      @(posedge clk);
    end
  endtask

  initial begin
    $readmemh("cd_bytes.hex", g_bytes);
    $readmemh("cd_coeffs.hex", g_coeffs);
    $readmemh("cp_packed.hex", g_packed);
    $readmemh("cp_decomp.hex", g_decomp);
    for(i=0;i<384;i=i+1) bmem[i]=g_bytes[i];

    $display("============================================================");
    $display("  New kpke_datapath codec ops");
    $display("============================================================");
    rst_n=0;ustart=0;bbase=0;usel=0;uop=0;ua0=0;ua1=0;ua2=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);

    // ByteDecode_12: 384 bytes at 0 -> slot 16
    bbase=11'd0; call(3'd6,3'd1,8'd0,8'd0,8'd16);
    for(i=0;i<256;i=i+1)
      if (u_s.mem[16*256+i] !== g_coeffs[i]) begin
        if(errors<6) $display("[TB] FAIL DEC12[%0d]: got %0d want %0d",
                              i,u_s.mem[16*256+i],g_coeffs[i]);
        errors=errors+1;
      end
    if(errors==0) $display("[TB] ByteDecode_12: 256/256 coefficients match");

    // Compress_10 + pack from slot 16 -> bytes at 1024
    bbase=11'd1024; call(3'd6,3'd2,8'd10,8'd16,8'd0);
    for(i=0;i<320;i=i+1)
      if (bmem[1024+i] !== g_packed[i]) begin
        if(errors<6) $display("[TB] FAIL COMPR[%0d]: got %02h want %02h",
                              i,bmem[1024+i],g_packed[i]);
        errors=errors+1;
      end
    if(errors==0) $display("[TB] Compress_10 + pack: 320/320 bytes match");

    // unpack + Decompress_10 from 1024 -> slot 18
    bbase=11'd1024; call(3'd6,3'd3,8'd10,8'd0,8'd18);
    for(i=0;i<256;i=i+1)
      if (u_s.mem[18*256+i] !== g_decomp[i]) begin
        if(errors<6) $display("[TB] FAIL DECOMP[%0d]: got %0d want %0d",
                              i,u_s.mem[18*256+i],g_decomp[i]);
        errors=errors+1;
      end
    if(errors==0) $display("[TB] unpack + Decompress_10: 256/256 match");

    $display("============================================================");
    if(errors==0) $display("  PASS -- new codec ops match the golden model");
    else          $display("  FAIL -- %0d error(s)",errors);
    $display("============================================================");
    $finish;
  end
  initial begin #50_000_000; $display("TIMEOUT st=%0d",dbg); $finish; end
endmodule
