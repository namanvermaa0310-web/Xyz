#!/bin/bash
# Complete ML-KEM-512 regression.
set -e
K="mlkem_pkg.sv keccak_pkg.sv twiddle_rom.sv ntt_engine.sv basemul.sv poly_basemul.sv \
matvec_mul.sv poly_slots.sv kpke_datapath.sv keccak_round.sv keccak_f1600.sv \
sha3_512.sv shake128.sv shake256.sv sample_ntt.sv cbd_sampler.sv cbd_sampler_eta3.sv \
kpke_seed_unit.sv kpke_top.sv kpke_engine.sv kpke_system.sv"
M="$K sha3_256.sv mlkem_hash_unit.sv verify_cmov.sv mlkem_system.sv"

echo "########## 1. kpke_engine call sequences ##########"
iverilog -g2012 -o a.vvp mlkem_pkg.sv kpke_engine.sv tb_kpke_engine.sv && vvp a.vvp
echo ""
echo "########## 2. codec ops ##########"
iverilog -g2012 -o b.vvp mlkem_pkg.sv twiddle_rom.sv ntt_engine.sv basemul.sv \
  poly_basemul.sv matvec_mul.sv poly_slots.sv kpke_datapath.sv tb_codec_ops.sv && vvp b.vvp
echo ""
echo "########## 3. K-PKE KeyGen  (Alg 13) ##########"
iverilog -g2012 -o c.vvp $K tb_kpke_system.sv && vvp c.vvp
echo ""
echo "########## 4. K-PKE Encrypt (Alg 14) ##########"
iverilog -g2012 -o d.vvp $K tb_kpke_enc.sv && vvp d.vvp
echo ""
echo "########## 5. K-PKE Decrypt (Alg 15) ##########"
iverilog -g2012 -o e.vvp $K tb_kpke_dec.sv && vvp e.vvp
echo ""
echo "########## 6. FULL ML-KEM (Algs 16/17/18) ##########"
echo "     this one takes several minutes -- it runs Encaps and Decaps twice"
iverilog -g2012 -o f.vvp $M tb_mlkem_full.sv && vvp f.vvp
rm -f *.vvp
