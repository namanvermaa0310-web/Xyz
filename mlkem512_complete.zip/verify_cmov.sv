// =============================================================================
// verify_cmov.sv -- constant-time compare and conditional move
// FIPS 203 Algorithm 18 (ML-KEM.Decaps) support; C reference verify.c
// -----------------------------------------------------------------------------
// Decapsulation must decide between the real shared secret K' and the
// rejection value K_bar based on whether the re-encrypted ciphertext matches
// the received one. That decision MUST NOT leak through timing, or an
// attacker can mount a chosen-ciphertext attack and recover the secret key --
// this is the whole reason the Fujisaki-Okamoto transform exists.
//
// Two properties this module guarantees:
//
//   1. The comparison runs for exactly CT_BYTES cycles regardless of the
//      data. There is no early exit on first mismatch. The C reference does
//      the same thing:
//          for(i=0;i<len;i++) r |= a[i] ^ b[i];
//      accumulating with OR rather than branching.
//
//   2. The select is a MUX, not a branch. In RTL a mux is inherently
//      constant-time -- both inputs are always evaluated and the select line
//      only steers which one lands. The C reference has to work harder for
//      this (cmov with a computed mask) precisely because C has no muxes.
//
// The `fail` output is derived as (acc != 0) -> a single OR-reduce, again
// data-independent in timing.
//
// STREAMING INTERFACE: the two ciphertexts live in memories, read one byte
// per cycle. Read latency is handled explicitly (ST_WAIT) -- the same
// synchronous-read discipline used throughout this project.
// =============================================================================
module verify_cmov #(
  parameter integer CT_BYTES = 768,   // ML-KEM-512 ciphertext length
  parameter integer SS_BYTES = 32     // shared secret length
)(
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,

  // received ciphertext c
  output reg  [9:0]  c_rd_addr,
  input  wire [7:0]  c_rd_data,
  // re-encrypted ciphertext c'
  output reg  [9:0]  cp_rd_addr,
  input  wire [7:0]  cp_rd_data,

  // candidate secrets, both already computed by the caller
  output reg  [5:0]  k_rd_addr,       // shared index into both
  input  wire [7:0]  kprime_rd_data,  // K'   (real key)
  input  wire [7:0]  kbar_rd_data,    // Kbar (rejection value)

  // selected shared secret out
  output reg  [5:0]  ss_wr_addr,
  output reg  [7:0]  ss_wr_data,
  output reg         ss_wr_en,

  // 1 while the module is in its SELECT phase rather than its COMPARE phase.
  // The caller muxes shared buses on this: during compare it must present
  // ciphertext bytes, during select it must present K' and Kbar. Without an
  // explicit flag the caller has to guess from c_rd_addr, which stays parked
  // at its final value through the select phase.
  output reg         sel_phase,
  output reg         fail,            // 1 = ciphertexts differed
  output reg         busy,
  output reg         done
);

  localparam ST_IDLE   = 3'd0;
  localparam ST_CADDR  = 3'd1;   // drive compare addresses
  localparam ST_CWAIT  = 3'd2;   // read latency
  localparam ST_CACC   = 3'd3;   // accumulate the XOR
  localparam ST_SADDR  = 3'd4;   // drive select addresses
  localparam ST_SWAIT  = 3'd5;
  localparam ST_SEL    = 3'd6;   // mux and write one secret byte
  localparam ST_DONE   = 3'd7;

  reg [2:0] state;
  reg [9:0] idx;
  reg [7:0] acc;        // OR-accumulated differences; nonzero => mismatch

  // The verdict, derived DIRECTLY from the accumulator rather than from a
  // registered copy. Latching it at one specific state and reading it a cycle
  // later is fragile -- an earlier version did exactly that and the select
  // used the stale value, returning the real key for a ciphertext it had
  // correctly detected as corrupt. |acc is a reduction, not a branch, so this
  // is still constant-time.
  wire mismatch = |acc;

  // Constant-time select: a mux, evaluated every cycle regardless of verdict.
  wire [7:0] selected = mismatch ? kbar_rd_data : kprime_rd_data;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; fail <= 1'b0;
      idx <= 10'd0; acc <= 8'd0; sel_phase <= 1'b0;
      c_rd_addr <= 10'd0; cp_rd_addr <= 10'd0; k_rd_addr <= 6'd0;
      ss_wr_addr <= 6'd0; ss_wr_data <= 8'd0; ss_wr_en <= 1'b0;
    end else begin
      ss_wr_en <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            idx <= 10'd0; acc <= 8'd0; fail <= 1'b0; sel_phase <= 1'b0;
            busy <= 1'b1; done <= 1'b0;
            state <= ST_CADDR;
          end
        end

        // ---- constant-time compare over ALL CT_BYTES, no early exit ------
        ST_CADDR: begin
          c_rd_addr  <= idx;
          cp_rd_addr <= idx;
          state <= ST_CWAIT;
        end
        ST_CWAIT: state <= ST_CACC;
        ST_CACC: begin
          acc <= acc | (c_rd_data ^ cp_rd_data);
          if (idx == CT_BYTES-1) begin
            idx <= 10'd0;
            sel_phase <= 1'b1;
            state <= ST_SADDR;
          end else begin
            idx <= idx + 10'd1;
            state <= ST_CADDR;
          end
        end

        // ---- select and emit the shared secret ---------------------------
        ST_SADDR: begin
          k_rd_addr <= idx[5:0];
          state <= ST_SWAIT;
        end
        ST_SWAIT: state <= ST_SEL;
        ST_SEL: begin
          ss_wr_addr <= idx[5:0];
          ss_wr_data <= selected;      // mux, not a branch
          ss_wr_en   <= 1'b1;
          if (idx == SS_BYTES-1) state <= ST_DONE;
          else begin
            idx <= idx + 10'd1;
            state <= ST_SADDR;
          end
        end

        ST_DONE: begin
          fail      <= mismatch;   // report the verdict alongside done
          busy      <= 1'b0;
          done      <= 1'b1;
          sel_phase <= 1'b0;
          state     <= ST_IDLE;
        end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : verify_cmov
