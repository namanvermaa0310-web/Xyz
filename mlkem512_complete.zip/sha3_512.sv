// =============================================================================
// SHA3-512, multi-block. Rate 72 bytes (capacity 1024), 64-byte digest.
// Needed by FIPS 203 as the G function: (rho, sigma) = G(d || k).
// Forked from the fixed sha3_256.sv -- same sequential block load and
// ram_style=block msg_buf, only the rate, block width and digest differ.
// -----------------------------------------------------------------------------
// SYNTHESIS FIX (block-load restructure)
// The previous version built the current 136-byte rate block with a generate
// loop of 136 CONTINUOUS ASSIGNMENTS, each indexing msg_buf at its own
// computed address. That is 136 simultaneous read ports on one memory.
// Vivado cannot map that to block RAM (2 ports) or distributed RAM, so it
// reported
//     [Synth 8-4767] RAM "msg_buf_reg" dissolved into registers
// and built 512x8 = 4096 flip-flops plus 136 wide address multiplexers --
// which is why synthesis ran for over an hour and would never have met timing.
//
// That parallel-read pattern was originally adopted to work around an Icarus
// quirk (always@(*) over a memory array not re-triggering). It fixed the
// simulator and broke synthesis: a lesson in writing RTL that only one tool
// has ever seen.
//
// This version reads msg_buf SEQUENTIALLY, one byte per two cycles, into a
// packed 1088-bit block register, then XORs that into the sponge. msg_buf now
// has a single read port and a single write port, so it infers as real RAM.
// block_reg is declared as a packed vector (not an unpacked array) so the tool
// never attempts RAM inference on it -- it is plainly flops, which is correct
// since all 136 bytes are consumed at once.
//
// Cost: ~272 cycles to load each block instead of 0. At 100 MHz that is ~2.7 us
// per block, versus 24 cycles for the permutation itself. Absorb-dominated, but
// entirely acceptable -- and it is the difference between a design that
// synthesises and one that does not.
// =============================================================================
module sha3_512_mb #(
  parameter MAX_MSG_BYTES = 512
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [9:0]  msg_len,     // 0 .. MAX_MSG_BYTES
  // 11 bits, not 9: with MAX_MSG_BYTES > 512 a 9-bit address WRAPS and
  // silently overwrites the start of the message. The FO layer hashes ek
  // (800 B) and z||c (800 B), which is exactly that case.
  input  wire [10:0] wr_addr,
  input  wire [7:0]  wr_data,
  input  wire        wr_en,
  output reg         busy,
  output reg         done,
  output reg  [511:0] hash_out
);
  localparam RATE_BYTES = 72;

  // ---------------------------------------------------------------------------
  // Message buffer: ONE write port, ONE read port -> infers as RAM
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [7:0] msg_buf [0:MAX_MSG_BYTES-1];
  reg [10:0] mb_raddr;
  reg [7:0] mb_q;

  always @(posedge clk) begin
    if (wr_en) msg_buf[wr_addr] <= wr_data;
    mb_q <= msg_buf[mb_raddr];
  end

  function automatic logic [63:0] swap_bytes(input logic [63:0] v);
    swap_bytes = { v[7:0], v[15:8], v[23:16], v[31:24],
                    v[39:32], v[47:40], v[55:48], v[63:56] };
  endfunction

  reg  [9:0] msg_len_reg;
  reg  [7:0] blk_idx;
  wire [9:0] total_padded_len = msg_len_reg + 10'd1 + 10'((RATE_BYTES-1));
  wire [7:0] num_blocks = total_padded_len / RATE_BYTES;  // ceil((len+1)/136)

  reg [1599:0] sponge_state;

  // ---------------------------------------------------------------------------
  // Sequentially-loaded rate block. Packed vector -> flops, no RAM inference.
  // ---------------------------------------------------------------------------
  reg [575:0] block_reg;              // 72 bytes (rate for SHA3-512)
  reg [7:0]    ld_idx;                 // 0 .. RATE_BYTES-1
  wire [11:0]  gidx = blk_idx * RATE_BYTES + ld_idx;
  wire         is_last_block = (blk_idx == num_blocks - 8'd1);

  // Padding applied as the byte is stored (same rule as before):
  //   inside the message      -> the message byte
  //   exactly at msg_len      -> 0x06 domain byte
  //   beyond                  -> 0x00
  //   final byte of last block-> OR 0x80
  wire [7:0] raw_byte = (gidx <  {1'b0, msg_len_reg}) ? mb_q  :
                        (gidx == {1'b0, msg_len_reg}) ? 8'h06 : 8'h00;
  wire [7:0] padded_byte =
        (is_last_block && (ld_idx == RATE_BYTES-1)) ? (raw_byte | 8'h80)
                                                    : raw_byte;

  // Lane packing: byte j of the block goes to bits [8j +: 8] within its lane,
  // little-endian per lane, identical to the previous implementation.
  wire [1599:0] xored_state = sponge_state ^ {1024'd0, block_reg};

  reg          f_start;
  reg  [1599:0] f_state_in;
  wire [1599:0] f_state_out;
  wire         f_busy, f_done;

  keccak_f1600 u_f1600 (
    .clk(clk), .rst_n(rst_n), .start(f_start),
    .state_in(f_state_in), .state_out(f_state_out),
    .busy(f_busy), .done(f_done)
  );

  localparam ST_IDLE = 4'd0, ST_LD_A = 4'd1, ST_LD_W = 4'd2, ST_LD_B = 4'd3,
             ST_XOR  = 4'd4, ST_KICK = 4'd5, ST_RUN = 4'd6, ST_DONE = 4'd7;
  reg [3:0] state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; f_start <= 1'b0;
      hash_out <= 512'd0; f_state_in <= 1600'd0; sponge_state <= 1600'd0;
      blk_idx <= 8'd0; msg_len_reg <= 10'd0;
      block_reg <= 576'd0; ld_idx <= 8'd0; mb_raddr <= 9'd0;
    end else begin
      f_start <= 1'b0;
      case (state)
        ST_IDLE, ST_DONE: begin
          if (state == ST_DONE) done <= 1'b1;
          if (start) begin
            msg_len_reg  <= msg_len;
            blk_idx      <= 8'd0;
            sponge_state <= 1600'd0;
            block_reg    <= 1088'd0;
            ld_idx       <= 8'd0;
            busy         <= 1'b1;
            done         <= 1'b0;
            state        <= ST_LD_A;
          end
        end

        // ---- issue the read address for byte ld_idx of this block ----------
        ST_LD_A: begin
          mb_raddr <= gidx[10:0];
          state    <= ST_LD_W;
        end

        // mb_raddr only takes effect at the END of ST_LD_A, so the RAM read
        // it triggers does not land in mb_q until the end of THIS state.
        // Capturing in ST_LD_A+1 would latch the PREVIOUS byte -- an
        // off-by-one that showed up immediately as an all-X digest.
        ST_LD_W: state <= ST_LD_B;

        // ---- mb_q now holds that byte: pad it and store it -----------------
        ST_LD_B: begin
          block_reg[8*ld_idx +: 8] <= padded_byte;
          if (ld_idx == RATE_BYTES-1) begin
            ld_idx <= 8'd0;
            state  <= ST_XOR;
          end else begin
            ld_idx <= ld_idx + 8'd1;
            state  <= ST_LD_A;
          end
        end

        ST_XOR: begin
          f_state_in <= xored_state;
          f_start    <= 1'b1;
          state      <= ST_KICK;
        end

        ST_KICK: state <= ST_RUN;  // buffer cycle; avoids stale f_done race

        ST_RUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            if (blk_idx == num_blocks - 8'd1) begin
              hash_out <= { swap_bytes(f_state_out[64*0 +: 64]),
                            swap_bytes(f_state_out[64*1 +: 64]),
                            swap_bytes(f_state_out[64*2 +: 64]),
                            swap_bytes(f_state_out[64*3 +: 64]),
                            swap_bytes(f_state_out[64*4 +: 64]),
                            swap_bytes(f_state_out[64*5 +: 64]),
                            swap_bytes(f_state_out[64*6 +: 64]),
                            swap_bytes(f_state_out[64*7 +: 64]) };
              busy  <= 1'b0;
              done  <= 1'b1;
              state <= ST_DONE;
            end else begin
              blk_idx <= blk_idx + 8'd1;
              state   <= ST_LD_A;
            end
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : sha3_512_mb
