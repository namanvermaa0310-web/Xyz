package keccak_pkg;
  // Lane indexing convention: lane index = 5*y + x  (x,y in 0..4)
  // This matches the standard Keccak state layout, little-endian byte order
  // within each 64-bit lane.

  // 24 round constants for iota step
  function automatic logic [63:0] round_const(input int unsigned r);
    logic [63:0] rc [0:23];
    rc[0]  = 64'h0000000000000001; rc[1]  = 64'h0000000000008082;
    rc[2]  = 64'h800000000000808A; rc[3]  = 64'h8000000080008000;
    rc[4]  = 64'h000000000000808B; rc[5]  = 64'h0000000080000001;
    rc[6]  = 64'h8000000080008081; rc[7]  = 64'h8000000000008009;
    rc[8]  = 64'h000000000000008A; rc[9]  = 64'h0000000000000088;
    rc[10] = 64'h0000000080008009; rc[11] = 64'h000000008000000A;
    rc[12] = 64'h000000008000808B; rc[13] = 64'h800000000000008B;
    rc[14] = 64'h8000000000008089; rc[15] = 64'h8000000000008003;
    rc[16] = 64'h8000000000008002; rc[17] = 64'h8000000000000080;
    rc[18] = 64'h000000000000800A; rc[19] = 64'h800000008000000A;
    rc[20] = 64'h8000000080008081; rc[21] = 64'h8000000000008080;
    rc[22] = 64'h0000000080000001; rc[23] = 64'h8000000080008008;
    return rc[r];
  endfunction

  // Rotation offsets R[x][y], flattened as rot_offset(5*y+x)
  function automatic int unsigned rot_offset(input int unsigned lane_idx);
    int unsigned r [0:24];
    // indexed by 5*y+x
    r[5*0+0]=0;  r[5*0+1]=1;  r[5*0+2]=62; r[5*0+3]=28; r[5*0+4]=27;
    r[5*1+0]=36; r[5*1+1]=44; r[5*1+2]=6;  r[5*1+3]=55; r[5*1+4]=20;
    r[5*2+0]=3;  r[5*2+1]=10; r[5*2+2]=43; r[5*2+3]=25; r[5*2+4]=39;
    r[5*3+0]=41; r[5*3+1]=45; r[5*3+2]=15; r[5*3+3]=21; r[5*3+4]=8;
    r[5*4+0]=18; r[5*4+1]=2;  r[5*4+2]=61; r[5*4+3]=56; r[5*4+4]=14;
    return r[lane_idx];
  endfunction
endpackage : keccak_pkg
