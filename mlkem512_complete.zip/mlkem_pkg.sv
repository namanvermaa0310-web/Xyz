package mlkem_pkg;
  localparam int Q        = 3329;
  localparam int N        = 256;
  localparam int COEFF_W  = 16;
  localparam int ADDR_W   = 8;
  localparam int BARRETT_V     = 20159;
  localparam int BARRETT_SHIFT = 26;
  localparam int N_INV = 3303;
  localparam int NTT_STAGES = 7;
  localparam int TWIDDLE_ADDR_W = 7;
  localparam int TWIDDLE_COUNT  = 128;

  typedef enum logic [2:0] {
    IDLE    = 3'b000,
    READ    = 3'b001,
    MUL     = 3'b010,
    REDUCE  = 3'b011,
    ADDSUB  = 3'b100,
    WRITE   = 3'b101,
    DONE    = 3'b110
  } ntt_state_t;

  typedef enum logic {
    MODE_NTT  = 1'b0,
    MODE_INTT = 1'b1
  } ntt_mode_t;
endpackage : mlkem_pkg
