#!/usr/bin/env python3
"""
ML-KEM golden model -- FIPS 203 Algorithms 16, 17, 18 (ML-KEM-512).
Extends golden_kpke.py (Algorithm 13) with K-PKE Encrypt/Decrypt and the
full Fujisaki-Okamoto transform.

*** FIPS 203, NOT round-3 Kyber. ***
Round-3 ends Encaps/Decaps with  ss = KDF(pre_k || H(c)).
FIPS 203 REMOVED that final KDF: the shared secret is K directly.
Building against the round-3 form would produce a self-consistent but
non-conformant KEM.
"""
from hashlib import shake_128, shake_256, sha3_256, sha3_512
from golden_kpke import (Q, K, ETA1, ETA2, ZETAS, barrett, ntt, sample_ntt,
                         cbd, poly_basemul, poly_add, byte_encode12,
                         G, XOF, PRF, kpke_keygen)

DU, DV = 10, 4          # ML-KEM-512 compression parameters

# ---------------- hashes ----------------
def H(s): return sha3_256(s).digest()
def J(s): return shake_256(s).digest(32)

# ---------------- inverse NTT ----------------
def intt(f):
    f = list(f); ln = 2; i = 127
    while ln <= 128:
        for st in range(0, 256, 2*ln):
            z = ZETAS[i]; i -= 1
            for j in range(st, st+ln):
                t = f[j]
                f[j]      = (t + f[j+ln]) % Q
                f[j+ln]   = barrett(z * ((f[j+ln] - t) % Q))
        ln *= 2
    ninv = pow(128, -1, Q)
    return [barrett(c * ninv) for c in f]

def poly_sub(a, b): return [(x - y) % Q for x, y in zip(a, b)]

# ---------------- encode / compress ----------------
def byte_decode12(bs):
    out = []
    for i in range(0, len(bs), 3):
        b0, b1, b2 = bs[i], bs[i+1], bs[i+2]
        out.append(b0 | ((b1 & 0x0F) << 8))
        out.append((b1 >> 4) | (b2 << 4))
    return out

def compress(x, d):   return (((x << d) + Q//2)//Q) & ((1 << d) - 1)
def decompress(y, d): return (y*Q + (1 << (d-1))) >> d

def byte_encode(coeffs, d):
    bits = []
    for c in coeffs:
        for i in range(d): bits.append((c >> i) & 1)
    out = bytearray()
    for i in range(0, len(bits), 8):
        b = 0
        for j in range(8): b |= bits[i+j] << j
        out.append(b)
    return bytes(out)

def byte_decode(bs, d):
    bits = [(b >> k) & 1 for b in bs for k in range(8)]
    out = []
    for i in range(256):
        v = 0
        for j in range(d): v |= bits[d*i + j] << j
        out.append(v)
    return out

def msg_to_poly(m):
    bits = [(b >> k) & 1 for b in m for k in range(8)]
    return [decompress(bits[i], 1) for i in range(256)]

def poly_to_msg(p):
    bits = [compress(c, 1) for c in p]
    out = bytearray(32)
    for i in range(256):
        out[i//8] |= bits[i] << (i % 8)
    return bytes(out)

# ---------------- Algorithm 14: K-PKE.Encrypt ----------------
def kpke_encrypt(ek, m, r):
    t_hat = [byte_decode12(ek[384*i:384*(i+1)]) for i in range(K)]
    rho = ek[384*K:384*K+32]

    # A_hat[i][j] = SampleNTT(XOF(rho, j, i))  -- same as KeyGen
    A_hat = [[sample_ntt(XOF(rho, j, i)) for j in range(K)] for i in range(K)]

    N = 0
    y = []
    for i in range(K):
        y.append(cbd(PRF(ETA1, r, N), ETA1)); N += 1
    e1 = []
    for i in range(K):
        e1.append(cbd(PRF(ETA2, r, N), ETA2)); N += 1
    e2 = cbd(PRF(ETA2, r, N), ETA2)

    y_hat = [ntt(p) for p in y]

    # u = INTT(A_hat^T @ y_hat) + e1
    u = []
    for i in range(K):
        acc = [0]*256
        for j in range(K):
            acc = poly_add(acc, poly_basemul(A_hat[j][i], y_hat[j]))   # transpose
        u.append(poly_add(intt(acc), e1[i]))

    # v = INTT(t_hat^T @ y_hat) + e2 + msg
    acc = [0]*256
    for i in range(K):
        acc = poly_add(acc, poly_basemul(t_hat[i], y_hat[i]))
    v = poly_add(poly_add(intt(acc), e2), msg_to_poly(m))

    c1 = b"".join(byte_encode([compress(x, DU) for x in p], DU) for p in u)
    c2 = byte_encode([compress(x, DV) for x in v], DV)
    return c1 + c2

# ---------------- Algorithm 15: K-PKE.Decrypt ----------------
def kpke_decrypt(dk, c):
    c1len = 32 * DU * K
    u = [[decompress(x, DU) for x in byte_decode(c[32*DU*i:32*DU*(i+1)], DU)]
         for i in range(K)]
    v = [decompress(x, DV) for x in byte_decode(c[c1len:], DV)]
    s_hat = [byte_decode12(dk[384*i:384*(i+1)]) for i in range(K)]

    u_hat = [ntt(p) for p in u]
    acc = [0]*256
    for i in range(K):
        acc = poly_add(acc, poly_basemul(s_hat[i], u_hat[i]))
    w = poly_sub(v, intt(acc))
    return poly_to_msg(w)

# ---------------- Algorithm 16: ML-KEM.KeyGen_internal ----------------
def mlkem_keygen(d, z):
    ek_pke, dk_pke, _ = kpke_keygen(d)
    ek = ek_pke
    dk = dk_pke + ek + H(ek) + z
    return ek, dk

# ---------------- Algorithm 17: ML-KEM.Encaps_internal ----------------
def mlkem_encaps(ek, m):
    Kk, r = G(m + H(ek))
    c = kpke_encrypt(ek, m, r)
    return Kk, c          # NOTE: no final KDF -- that is round-3, not FIPS 203

# ---------------- Algorithm 18: ML-KEM.Decaps_internal ----------------
def mlkem_decaps(dk, c):
    dk_pke = dk[0:384*K]
    ek_pke = dk[384*K:768*K+32]
    h      = dk[768*K+32:768*K+64]
    z      = dk[768*K+64:]

    m_prime = kpke_decrypt(dk_pke, c)
    K_prime, r_prime = G(m_prime + h)
    K_bar = J(z + c)
    c_prime = kpke_encrypt(ek_pke, m_prime, r_prime)
    # constant-time select in hardware; plain compare here
    return K_prime if c == c_prime else K_bar

if __name__ == "__main__":
    d = bytes(range(32))
    z = bytes(range(32, 64))
    m = bytes(range(64, 96))

    ek, dk = mlkem_keygen(d, z)
    Kk, c  = mlkem_encaps(ek, m)
    Kd     = mlkem_decaps(dk, c)

    print(f"ek {len(ek)}B  dk {len(dk)}B  ct {len(c)}B  ss {len(Kk)}B")
    print(f"shared secret (encaps): {Kk.hex()}")
    print(f"shared secret (decaps): {Kd.hex()}")
    print("round trip K == K':", Kk == Kd)

    from kyber_py.ml_kem import ML_KEM_512
    ek2, dk2 = ML_KEM_512._keygen_internal(d, z)
    K2, c2   = ML_KEM_512._encaps_internal(ek2, m)
    K3       = ML_KEM_512._decaps_internal(dk2, c2)
    print()
    print("ek  matches kyber-py:", ek == ek2)
    print("dk  matches kyber-py:", dk == dk2)
    print("ct  matches kyber-py:", c  == c2)
    print("ss  matches kyber-py:", Kk == K2)
    print("decaps matches kyber-py:", Kd == K3)

    # implicit rejection path: corrupt the ciphertext
    bad = bytearray(c); bad[0] ^= 0xFF
    Kr  = mlkem_decaps(dk, bytes(bad))
    Kr2 = ML_KEM_512._decaps_internal(dk2, bytes(bad))
    print("implicit rejection differs from K:", Kr != Kk)
    print("implicit rejection matches kyber-py:", Kr == Kr2)
