// =============================================================================
// cbd_sampler.sv -- FIPS 203 Algorithm 8: SamplePolyCBD, eta = 2
// -----------------------------------------------------------------------------
// Converts 64*eta = 128 bytes of PRF output (SHAKE-256(sigma||N)) into a
// polynomial with coefficients from the centered binomial distribution:
//
//   f[i] = (bit[4i] + bit[4i+1]) - (bit[4i+2] + bit[4i+3])   (mod q)
//
// Bits are taken LSB-first within each byte (BytesToBits per FIPS 203), so
// one byte supplies exactly two coefficients:
//   low nibble  b[3:0] -> coeff 2k   : (b[0]+b[1]) - (b[2]+b[3])
//   high nibble b[7:4] -> coeff 2k+1 : (b[4]+b[5]) - (b[6]+b[7])
// Values are in {-2..2}, mapped into Z_q as {q-2, q-1, 0, 1, 2}.
//
// eta=2 covers ML-KEM-768 and ML-KEM-1024 (eta1 = eta2 = 2). ML-KEM-512
// additionally needs eta1 = 3 (3 coefficients per 3 bytes); that variant is
// NOT implemented here.
// =============================================================================
module cbd_sampler (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,

  // PRF byte stream read port (128 bytes)
  output reg  [6:0]  byte_rd_addr,
  input  wire [7:0]  byte_rd_data,

  // Coefficient write port
  output reg  [7:0]  coeff_wr_addr,
  output reg  [15:0] coeff_wr_data,
  output reg         coeff_wr_en,

  output reg         busy,
  output reg         done
);
  localparam [15:0] Q16 = 16'd3329;

  localparam ST_IDLE = 3'd0;
  localparam ST_RA   = 3'd1;   // issue byte address
  localparam ST_LT   = 3'd2;   // latch byte
  localparam ST_W0   = 3'd3;   // write coeff 2k (low nibble)
  localparam ST_W1   = 3'd4;   // write coeff 2k+1 (high nibble), loop
  localparam ST_DONE = 3'd5;

  reg [2:0] state;
  reg [6:0] k;                 // byte index 0..127
  reg [7:0] b;

  // CBD arithmetic for one nibble: (n[0]+n[1]) - (n[2]+n[3]) mod q
  function automatic [15:0] cbd_coeff(input [3:0] n);
    reg [1:0] x, y;
    begin
      x = {1'b0, n[0]} + {1'b0, n[1]};
      y = {1'b0, n[2]} + {1'b0, n[3]};
      cbd_coeff = (x >= y) ? {14'd0, x - y} : (Q16 - {14'd0, y - x});
    end
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0;
      byte_rd_addr <= 7'd0; coeff_wr_addr <= 8'd0;
      coeff_wr_data <= 16'd0; coeff_wr_en <= 1'b0;
      k <= 7'd0; b <= 8'd0;
    end else begin
      coeff_wr_en <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            busy <= 1'b1; done <= 1'b0; k <= 7'd0;
            state <= ST_RA;
          end
        end

        ST_RA: begin
          byte_rd_addr <= k;
          state <= ST_LT;
        end

        ST_LT: begin
          b <= byte_rd_data;
          state <= ST_W0;
        end

        ST_W0: begin
          coeff_wr_addr <= {k, 1'b0};          // 2k
          coeff_wr_data <= cbd_coeff(b[3:0]);
          coeff_wr_en   <= 1'b1;
          state <= ST_W1;
        end

        ST_W1: begin
          coeff_wr_addr <= {k, 1'b1};          // 2k + 1
          coeff_wr_data <= cbd_coeff(b[7:4]);
          coeff_wr_en   <= 1'b1;
          if (k == 7'd127) begin
            busy <= 1'b0; done <= 1'b1;
            state <= ST_DONE;
          end else begin
            k <= k + 7'd1;
            state <= ST_RA;
          end
        end

        ST_DONE: begin
          done <= 1'b1;
          if (start) begin
            busy <= 1'b1; done <= 1'b0; k <= 7'd0;
            state <= ST_RA;
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : cbd_sampler
