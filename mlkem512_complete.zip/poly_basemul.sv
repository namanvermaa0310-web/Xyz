// =============================================================================
// poly_basemul.sv -- Multiply two polynomials in the NTT domain
// FIPS 203 Algorithm 12 (MultiplyNTTs)
// -----------------------------------------------------------------------------
// A polynomial in NTT domain is 128 independent degree-1 polynomials, each
// living in Z_q[X]/(X^2 - zeta_i). This module walks all 128 of them, calling
// the basemul core (Algorithm 11) on each pair.
//
// The zeta used alternates in SIGN between consecutive pairs, exactly as the
// C reference does:
//     basemul(&r[4i],   &a[4i],   &b[4i],    zetas[64+i]);
//     basemul(&r[4i+2], &a[4i+2], &b[4i+2], -zetas[64+i]);
// so each iteration of the loop handles FOUR coefficients (two degree-1
// polynomials) and consumes one zeta.
//
// -zeta mod q is computed as (q - zeta), valid because every stored zeta is
// already reduced into [0, q).
//
// ARITHMETIC: plain Barrett, no Montgomery. Verified equivalent to the C
// reference's montgomery+tomont pipeline: the reference's
// pointwise_acc_montgomery yields (sum a_i*b_i)*R^-1 and poly_tomont then
// multiplies by R, so the net result is the plain product -- which is what
// this module computes directly, with no tomont step needed.
//
// MEMORY INTERFACE: two read ports (one per input polynomial) and one write
// port, all with registered addresses and one-cycle synchronous read latency.
// The FSM accounts for that latency explicitly (see ST_RD_WAIT) rather than
// assuming a single settle cycle -- the same class of bug that produced an
// all-X digest in Phase 2 and wrong coefficients in the eta=3 sampler.
// =============================================================================
module poly_basemul (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,

  // polynomial A read port
  output reg  [7:0]  a_rd_addr,
  input  wire [15:0] a_rd_data,
  // polynomial B read port
  output reg  [7:0]  b_rd_addr,
  input  wire [15:0] b_rd_data,
  // result write port
  output reg  [7:0]  r_wr_addr,
  output reg  [15:0] r_wr_data,
  output reg         r_wr_en,

  output reg         busy,
  output reg         done
);
  import mlkem_pkg::*;

  // ---------------------------------------------------------------------------
  // zetas[64..127] -- the 64 roots used by Algorithm 12.
  // Same values as twiddle_rom entries 64..127; kept as a local ROM so this
  // module has no dependency on the NTT's twiddle addressing scheme.
  // ---------------------------------------------------------------------------
  // zetas[64..127] as a case-statement ROM.
  // Previously loaded with $readmemh("golden_zeta64.hex") in an initial
  // block. Vivado can infer a ROM from that, but only if the hex file is
  // added as a design source and its relative path resolves -- a fragile
  // dependency for a 64-entry constant table. Inlining it removes the
  // external file from the synthesis flow entirely.
  function automatic [15:0] zeta64_rom(input [5:0] a);
    case (a)
      6'd0 : zeta64_rom = 16'd17;
      6'd1 : zeta64_rom = 16'd2761;
      6'd2 : zeta64_rom = 16'd583;
      6'd3 : zeta64_rom = 16'd2649;
      6'd4 : zeta64_rom = 16'd1637;
      6'd5 : zeta64_rom = 16'd723;
      6'd6 : zeta64_rom = 16'd2288;
      6'd7 : zeta64_rom = 16'd1100;
      6'd8 : zeta64_rom = 16'd1409;
      6'd9 : zeta64_rom = 16'd2662;
      6'd10: zeta64_rom = 16'd3281;
      6'd11: zeta64_rom = 16'd233;
      6'd12: zeta64_rom = 16'd756;
      6'd13: zeta64_rom = 16'd2156;
      6'd14: zeta64_rom = 16'd3015;
      6'd15: zeta64_rom = 16'd3050;
      6'd16: zeta64_rom = 16'd1703;
      6'd17: zeta64_rom = 16'd1651;
      6'd18: zeta64_rom = 16'd2789;
      6'd19: zeta64_rom = 16'd1789;
      6'd20: zeta64_rom = 16'd1847;
      6'd21: zeta64_rom = 16'd952;
      6'd22: zeta64_rom = 16'd1461;
      6'd23: zeta64_rom = 16'd2687;
      6'd24: zeta64_rom = 16'd939;
      6'd25: zeta64_rom = 16'd2308;
      6'd26: zeta64_rom = 16'd2437;
      6'd27: zeta64_rom = 16'd2388;
      6'd28: zeta64_rom = 16'd733;
      6'd29: zeta64_rom = 16'd2337;
      6'd30: zeta64_rom = 16'd268;
      6'd31: zeta64_rom = 16'd641;
      6'd32: zeta64_rom = 16'd1584;
      6'd33: zeta64_rom = 16'd2298;
      6'd34: zeta64_rom = 16'd2037;
      6'd35: zeta64_rom = 16'd3220;
      6'd36: zeta64_rom = 16'd375;
      6'd37: zeta64_rom = 16'd2549;
      6'd38: zeta64_rom = 16'd2090;
      6'd39: zeta64_rom = 16'd1645;
      6'd40: zeta64_rom = 16'd1063;
      6'd41: zeta64_rom = 16'd319;
      6'd42: zeta64_rom = 16'd2773;
      6'd43: zeta64_rom = 16'd757;
      6'd44: zeta64_rom = 16'd2099;
      6'd45: zeta64_rom = 16'd561;
      6'd46: zeta64_rom = 16'd2466;
      6'd47: zeta64_rom = 16'd2594;
      6'd48: zeta64_rom = 16'd2804;
      6'd49: zeta64_rom = 16'd1092;
      6'd50: zeta64_rom = 16'd403;
      6'd51: zeta64_rom = 16'd1026;
      6'd52: zeta64_rom = 16'd1143;
      6'd53: zeta64_rom = 16'd2150;
      6'd54: zeta64_rom = 16'd2775;
      6'd55: zeta64_rom = 16'd886;
      6'd56: zeta64_rom = 16'd1722;
      6'd57: zeta64_rom = 16'd1212;
      6'd58: zeta64_rom = 16'd1874;
      6'd59: zeta64_rom = 16'd1029;
      6'd60: zeta64_rom = 16'd2110;
      6'd61: zeta64_rom = 16'd2935;
      6'd62: zeta64_rom = 16'd885;
      6'd63: zeta64_rom = 16'd2154;
      default: zeta64_rom = 16'd0;
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // basemul core
  // ---------------------------------------------------------------------------
  reg         bm_start;
  reg  [15:0] bm_a0, bm_a1, bm_b0, bm_b1, bm_zeta;
  wire [15:0] bm_r0, bm_r1;
  wire        bm_done, bm_busy;

  basemul u_bm (
    .clk(clk), .rst_n(rst_n), .start(bm_start),
    .a0(bm_a0), .a1(bm_a1), .b0(bm_b0), .b1(bm_b1), .zeta(bm_zeta),
    .r0(bm_r0), .r1(bm_r1), .done(bm_done), .busy(bm_busy)
  );

  // ---------------------------------------------------------------------------
  // FSM
  // Each of the 64 iterations does TWO basemuls (the +zeta pair and the
  // -zeta pair), covering coefficients 4i .. 4i+3.
  // ---------------------------------------------------------------------------
  localparam ST_IDLE    = 4'd0;
  localparam ST_RD_ADDR = 4'd1;   // drive addresses for the 4 coefficients
  localparam ST_RD_W1   = 4'd2;   // read latency
  localparam ST_RD_C0   = 4'd3;   // capture coeff 0 (a) / 0 (b)
  localparam ST_RD_C1   = 4'd4;   // capture coeff 1
  localparam ST_RD_C2   = 4'd5;   // capture coeff 2
  localparam ST_RD_C3   = 4'd6;   // capture coeff 3
  localparam ST_BM_GO   = 4'd7;   // kick basemul
  localparam ST_BM_WAIT = 4'd8;   // wait for it
  localparam ST_WR0     = 4'd9;   // write first result coefficient
  localparam ST_WR1     = 4'd10;  // write second
  localparam ST_NEXT    = 4'd11;  // advance pair / iteration
  localparam ST_DONE    = 4'd12;

  reg [3:0] state;
  reg [5:0] idx;        // 0..63, which zeta / which group of 4
  reg       half;       // 0 = first pair (+zeta), 1 = second pair (-zeta)
  reg [1:0] rd_step;    // which of the 4 coefficients we're fetching

  reg [15:0] a_c [0:3];
  reg [15:0] b_c [0:3];

  wire [7:0] base = {idx, 2'b00};     // 4*idx
  wire [15:0] zeta_pos = zeta64_rom(idx);
  wire [15:0] zeta_neg = 16'd3329 - zeta64_rom(idx);

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0;
      idx <= 6'd0; half <= 1'b0; rd_step <= 2'd0;
      a_rd_addr <= 8'd0; b_rd_addr <= 8'd0;
      r_wr_addr <= 8'd0; r_wr_data <= 16'd0; r_wr_en <= 1'b0;
      bm_start <= 1'b0;
      bm_a0 <= 16'd0; bm_a1 <= 16'd0; bm_b0 <= 16'd0; bm_b1 <= 16'd0;
      bm_zeta <= 16'd0;
    end else begin
      r_wr_en  <= 1'b0;
      bm_start <= 1'b0;
      // `done` must be a ONE-CYCLE PULSE. Leaving it level-held meant a
      // caller polling it (matvec_mul) saw the PREVIOUS column's completion
      // and skipped the next multiply entirely -- the product memory still
      // held stale data and the accumulator added the same column twice.
      done     <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            idx <= 6'd0; half <= 1'b0; rd_step <= 2'd0;
            busy <= 1'b1; done <= 1'b0;
            state <= ST_RD_ADDR;
          end
        end

        // Fetch the 4 coefficients of this group, one per pass.
        ST_RD_ADDR: begin
          a_rd_addr <= base + {6'd0, rd_step};
          b_rd_addr <= base + {6'd0, rd_step};
          state <= ST_RD_W1;
        end
        ST_RD_W1: begin
          // one cycle for the registered address + synchronous read
          state <= ST_RD_C0 + {2'd0, rd_step};
        end
        ST_RD_C0: begin a_c[0] <= a_rd_data; b_c[0] <= b_rd_data;
                        rd_step <= 2'd1; state <= ST_RD_ADDR; end
        ST_RD_C1: begin a_c[1] <= a_rd_data; b_c[1] <= b_rd_data;
                        rd_step <= 2'd2; state <= ST_RD_ADDR; end
        ST_RD_C2: begin a_c[2] <= a_rd_data; b_c[2] <= b_rd_data;
                        rd_step <= 2'd3; state <= ST_RD_ADDR; end
        ST_RD_C3: begin a_c[3] <= a_rd_data; b_c[3] <= b_rd_data;
                        rd_step <= 2'd0; state <= ST_BM_GO; end

        ST_BM_GO: begin
          if (!half) begin
            bm_a0 <= a_c[0]; bm_a1 <= a_c[1];
            bm_b0 <= b_c[0]; bm_b1 <= b_c[1];
            bm_zeta <= zeta_pos;
          end else begin
            bm_a0 <= a_c[2]; bm_a1 <= a_c[3];
            bm_b0 <= b_c[2]; bm_b1 <= b_c[3];
            bm_zeta <= zeta_neg;
          end
          bm_start <= 1'b1;
          state <= ST_BM_WAIT;
        end

        ST_BM_WAIT: if (bm_done) state <= ST_WR0;

        ST_WR0: begin
          r_wr_addr <= base + (half ? 8'd2 : 8'd0);
          r_wr_data <= bm_r0;
          r_wr_en   <= 1'b1;
          state <= ST_WR1;
        end
        ST_WR1: begin
          r_wr_addr <= base + (half ? 8'd3 : 8'd1);
          r_wr_data <= bm_r1;
          r_wr_en   <= 1'b1;
          state <= ST_NEXT;
        end

        ST_NEXT: begin
          if (!half) begin
            half <= 1'b1;
            state <= ST_BM_GO;        // second pair reuses the same 4 coeffs
          end else begin
            half <= 1'b0;
            if (idx == 6'd63) state <= ST_DONE;
            else begin
              idx <= idx + 6'd1;
              state <= ST_RD_ADDR;
            end
          end
        end

        ST_DONE: begin busy <= 1'b0; done <= 1'b1; state <= ST_IDLE; end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : poly_basemul
