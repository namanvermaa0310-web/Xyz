// =============================================================================
// kpke_datapath.sv -- arithmetic + coding half of the K-PKE service interface
// -----------------------------------------------------------------------------
// Implements every non-hashing service call kpke_engine can issue:
//
//   U_NTT     forward / inverse NTT, with copy-in and copy-out engines
//   U_MATVEC  sum over k of mat[j] o vec[j], with four addressing MODES
//   U_POLY    add / subtract / add-message, coefficient-wise mod q
//   U_CODEC   ByteEncode_12, ByteDecode_12, Compress_d + pack,
//             unpack + Decompress_d, and Compress_1 to a 32-byte message
//
// (U_HASH / U_XOF / U_PRF live in kpke_seed_unit.)
//
// -----------------------------------------------------------------------------
// MATVEC ADDRESSING MODES (unit_op)
// matvec_mul emits {jcol, coeff}; this module rebases it to {slot, coeff}.
// The transpose Encrypt needs is therefore purely an addressing change here --
// matvec_mul itself is untouched and stays exactly as verified.
//
//   0  KeyGen    t_hat[i] = sum_j A_hat[i][j] o s_hat[j]
//                base = SLOT_A + i*k,  stride 1   (walk a ROW)
//   1  Encrypt u u_hat[i] = sum_j A_hat[j][i] o y_hat[j]
//                base = SLOT_A + i,    stride k   (walk a COLUMN = transpose)
//   2  Encrypt v v_hat   = sum_i t_hat[i]   o y_hat[i]
//                base = SLOT_T,        stride 1
//   3  Decrypt   w_hat   = sum_i s_hat[i]   o u_hat[i]
//                base = SLOT_T,        stride 1   (s_hat is decoded into
//                                                  SLOT_T, unused in Decrypt)
//
// -----------------------------------------------------------------------------
// BIT PACKING
// Compress_d and its inverse are not byte-aligned: d = 10 for the ciphertext
// vector u and d = 4 for v, so coefficients straddle byte boundaries. Both
// directions use a shift accumulator (bitbuf/bitcnt) rather than trying to
// compute byte positions arithmetically -- the arithmetic version is where
// off-by-one errors hide, and this project has produced enough of those.
//
// Division by q is the multiply-shift identity floor(n/3329) == (n*2580335)>>33,
// verified exhaustively over every n that can arise. A literal divider would be
// enormous in fabric.
//
// -----------------------------------------------------------------------------
// READ LATENCY (the recurring hazard in this project)
//   poly_slots  : REGISTERED  -> one settle cycle after driving the address
//   byte memory : REGISTERED  -> one settle cycle
//   ntt_rd_data : continuous assign -> valid immediately, NO offset
//   matvec acc  : continuous assign -> valid immediately, NO offset
// Mixing these up produced shifted polynomials earlier; each is handled
// explicitly below.
// =============================================================================
module kpke_datapath #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13
)(
  input  wire        clk,
  input  wire        rst_n,

  input  wire [2:0]  unit_sel,
  input  wire [2:0]  unit_op,
  input  wire [7:0]  unit_a0,
  input  wire [7:0]  unit_a1,
  input  wire [7:0]  unit_a2,
  input  wire        unit_start,
  output reg         unit_done,

  // polynomial slot memory
  output wire [ADDR_W-1:0] ps_a_addr,
  input  wire [15:0]       ps_a_data,
  output wire [ADDR_W-1:0] ps_b_addr,
  input  wire [15:0]       ps_b_data,
  output reg  [ADDR_W-1:0] ps_w_addr,
  output reg  [15:0]       ps_w_data,
  output reg               ps_w_en,

  // byte buffer -- write
  output reg  [12:0] byte_wr_addr,
  output reg  [7:0]  byte_wr_data,
  output reg         byte_wr_en,
  // byte buffer -- read (needed by ByteDecode / Decompress / add-message)
  output reg  [12:0] byte_rd_addr,
  input  wire [7:0]  byte_rd_data,

  input  wire [12:0] byte_base,

  output reg  [5:0]  dbg_state
);
  import mlkem_pkg::*;

  localparam U_NTT    = 3'd3;
  localparam U_MATVEC = 3'd4;
  localparam U_POLY   = 3'd5;
  localparam U_CODEC  = 3'd6;

  localparam OP_NTT_FWD = 3'd0;
  localparam OP_NTT_INV = 3'd1;
  localparam OP_ADD     = 3'd0;
  localparam OP_SUB     = 3'd1;
  localparam OP_ADDMSG  = 3'd2;
  localparam OP_ENC12   = 3'd0;
  localparam OP_DEC12   = 3'd1;
  localparam OP_COMPR   = 3'd2;
  localparam OP_DECOMP  = 3'd3;
  localparam OP_TOMSG   = 3'd4;

  localparam [7:0] SLOT_A = 8'd0;
  localparam [7:0] SLOT_T = 8'd16;

  // Division by q without a divider.
  localparam [21:0] DIV_M = 22'd2580335;   // ceil(2^33 / 3329)
  function automatic [15:0] div_q(input [31:0] n);
    logic [63:0] p;
    p = n * DIV_M;
    div_q = p[33 +: 16];
  endfunction
  function automatic [15:0] compress_d(input [15:0] x, input [3:0] d);
    logic [31:0] n;
    n = ({16'd0, x} << d) + 32'd1664;      // + q/2, round to nearest
    compress_d = div_q(n) & ((16'd1 << d) - 16'd1);
  endfunction
  function automatic [15:0] decompress_d(input [15:0] y, input [3:0] d);
    logic [31:0] t;
    t = ({16'd0, y} * 32'd3329) + (32'd1 << (d - 1));
    decompress_d = t[31:0] >> d;
  endfunction

  reg [2:0] r_sel, r_op;
  reg [7:0] r_a0, r_a1, r_a2;

  // ---------------------------------------------------------------------------
  // NTT engine + copy engines
  // ---------------------------------------------------------------------------
  reg         ntt_start, ntt_mode;
  reg  [7:0]  ntt_wr_addr;
  reg  [15:0] ntt_wr_data;
  reg         ntt_wr_en;
  reg  [7:0]  ntt_rd_addr;
  wire [15:0] ntt_rd_data;
  wire        ntt_busy, ntt_done;

  ntt_engine u_ntt (
    .clk(clk), .rst_n(rst_n), .start(ntt_start), .mode(ntt_mode),
    .done(ntt_done), .busy(ntt_busy),
    .wr_addr(ntt_wr_addr), .wr_data(ntt_wr_data), .wr_en(ntt_wr_en),
    .rd_addr(ntt_rd_addr), .rd_data(ntt_rd_data));

  // ---------------------------------------------------------------------------
  // matvec, with mode-dependent slot base and stride
  // ---------------------------------------------------------------------------
  reg         mv_start;
  wire [9:0]  mv_mat_addr, mv_vec_addr;
  reg  [7:0]  mv_acc_addr;
  wire [15:0] mv_acc_data;
  wire        mv_busy, mv_done;

  matvec_mul #(.K_PARAM(K_PARAM)) u_mv (
    .clk(clk), .rst_n(rst_n), .start(mv_start),
    .mat_rd_addr(mv_mat_addr), .mat_rd_data(ps_a_data),
    .vec_rd_addr(mv_vec_addr), .vec_rd_data(ps_b_data),
    .acc_rd_addr(mv_acc_addr), .acc_rd_data(mv_acc_data),
    .busy(mv_busy), .done(mv_done));

  reg [7:0] mat_base, vec_base, mat_stride;

  // ---------------------------------------------------------------------------
  // Modular add / subtract, and the message term
  // ---------------------------------------------------------------------------
  wire [16:0] add_raw = ps_a_data + ps_b_data;
  wire [15:0] add_q   = (add_raw >= 17'd3329) ? (add_raw - 17'd3329) : add_raw[15:0];
  wire signed [16:0] sub_raw = $signed({1'b0, ps_a_data}) - $signed({1'b0, ps_b_data});
  wire [15:0] sub_q   = sub_raw[16] ? (sub_raw[15:0] + 16'd3329) : sub_raw[15:0];

  // Decompress_1: message bit -> 0 or (q+1)/2
  reg  [7:0]  msg_byte;
  wire        msg_bit  = msg_byte[idx[2:0]];
  wire [15:0] msg_term = msg_bit ? 16'd1665 : 16'd0;
  wire [16:0] addmsg_raw = ps_a_data + msg_term;
  wire [15:0] addmsg_q = (addmsg_raw >= 17'd3329) ? (addmsg_raw - 17'd3329)
                                                  : addmsg_raw[15:0];

  // ---------------------------------------------------------------------------
  // Bit accumulator for the non-byte-aligned codings
  // ---------------------------------------------------------------------------
  reg [31:0] bitbuf;
  reg [5:0]  bitcnt;
  reg [12:0] bcnt;          // byte offset within the current buffer
  reg [8:0]  idx;           // coefficient index 0..255
  reg [15:0] c0_reg, c1_reg;
  wire [3:0] dwidth = r_a0[3:0];
  wire [15:0] tomsg_c = compress_d(ps_a_data, 4'd1);
  wire        tomsg_bit = tomsg_c[0];

  // ---------------------------------------------------------------------------
  // States
  // ---------------------------------------------------------------------------
  localparam ST_IDLE    = 6'd0;
  localparam ST_NTT_LD  = 6'd1;
  localparam ST_NTT_IN  = 6'd2;
  localparam ST_NTT_GO  = 6'd3;
  localparam ST_NTT_RUN = 6'd4;
  localparam ST_NTT_OUT = 6'd5;
  localparam ST_MV_GO   = 6'd6;
  localparam ST_MV_ARM  = 6'd7;
  localparam ST_MV_WAIT = 6'd8;
  localparam ST_MV_COPY = 6'd9;
  localparam ST_PL_RD   = 6'd10;
  localparam ST_PL_WR   = 6'd11;
  // ByteEncode_12
  localparam ST_CE_A0   = 6'd12;
  localparam ST_CE_W0   = 6'd13;
  localparam ST_CE_C0   = 6'd14;
  localparam ST_CE_W1   = 6'd15;
  localparam ST_CE_C1   = 6'd16;
  localparam ST_CE_B0   = 6'd17;
  localparam ST_CE_B1   = 6'd18;
  localparam ST_CE_B2   = 6'd19;
  // ByteDecode_12
  localparam ST_CD_A    = 6'd20;
  localparam ST_CD_W    = 6'd21;
  localparam ST_CD_C    = 6'd22;
  localparam ST_CD_E    = 6'd23;
  // Compress_d + pack
  localparam ST_CP_A    = 6'd24;
  localparam ST_CP_W    = 6'd25;
  localparam ST_CP_C    = 6'd26;
  localparam ST_CP_E    = 6'd27;
  // unpack + Decompress_d
  localparam ST_DP_A    = 6'd28;
  localparam ST_DP_W    = 6'd29;
  localparam ST_DP_C    = 6'd30;
  localparam ST_DP_E    = 6'd31;
  // add-message
  localparam ST_AM_BA   = 6'd32;
  localparam ST_AM_BW   = 6'd33;
  localparam ST_AM_A    = 6'd34;
  localparam ST_AM_W    = 6'd35;
  localparam ST_AM_C    = 6'd36;
  // Compress_1 -> 32-byte message
  localparam ST_TM_A    = 6'd37;
  localparam ST_TM_W    = 6'd38;
  localparam ST_TM_C    = 6'd39;
  localparam ST_TM_E    = 6'd40;
  localparam ST_FIN     = 6'd41;

  reg [5:0] state;
  reg [ADDR_W-1:0] seq_a_addr, seq_b_addr;

  wire mv_active = (state == ST_MV_GO) || (state == ST_MV_ARM)
                || (state == ST_MV_WAIT);
  // Rebase matvec's {jcol, coeff} onto {base + jcol*stride, coeff}.
  assign ps_a_addr = mv_active
                   ? {(mat_base + ({6'd0, mv_mat_addr[9:8]} * mat_stride)),
                      mv_mat_addr[7:0]}
                   : seq_a_addr;
  assign ps_b_addr = mv_active
                   ? {(vec_base + {6'd0, mv_vec_addr[9:8]}), mv_vec_addr[7:0]}
                   : seq_b_addr;

  always @(*) dbg_state = state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; unit_done <= 1'b0;
      r_sel <= 3'd0; r_op <= 3'd0; r_a0 <= 8'd0; r_a1 <= 8'd0; r_a2 <= 8'd0;
      ntt_start <= 1'b0; ntt_mode <= 1'b0; ntt_wr_en <= 1'b0;
      ntt_wr_addr <= 8'd0; ntt_wr_data <= 16'd0; ntt_rd_addr <= 8'd0;
      mv_start <= 1'b0; mv_acc_addr <= 8'd0;
      mat_base <= 8'd0; vec_base <= 8'd0; mat_stride <= 8'd1;
      seq_a_addr <= {ADDR_W{1'b0}}; seq_b_addr <= {ADDR_W{1'b0}};
      ps_w_addr <= {ADDR_W{1'b0}}; ps_w_data <= 16'd0; ps_w_en <= 1'b0;
      byte_wr_addr <= 13'd0; byte_wr_data <= 8'd0; byte_wr_en <= 1'b0;
      byte_rd_addr <= 13'd0; msg_byte <= 8'd0;
      idx <= 9'd0; bcnt <= 13'd0; bitbuf <= 32'd0; bitcnt <= 6'd0;
      c0_reg <= 16'd0; c1_reg <= 16'd0;
    end else begin
      unit_done  <= 1'b0;
      ps_w_en    <= 1'b0;
      byte_wr_en <= 1'b0;
      ntt_wr_en  <= 1'b0;
      ntt_start  <= 1'b0;
      mv_start   <= 1'b0;

      case (state)
        ST_IDLE: if (unit_start) begin
          r_sel <= unit_sel; r_op <= unit_op;
          r_a0  <= unit_a0;  r_a1 <= unit_a1; r_a2 <= unit_a2;
          idx <= 9'd0; bcnt <= 13'd0; bitbuf <= 32'd0; bitcnt <= 6'd0;
          case (unit_sel)
            U_NTT: begin
              ntt_mode   <= (unit_op == OP_NTT_INV);
              seq_a_addr <= {unit_a1, 8'd0};
              state      <= ST_NTT_LD;
            end
            U_MATVEC: begin
              vec_base <= unit_a1;
              case (unit_op)
                3'd0: begin mat_base <= SLOT_A + (unit_a0 * K_PARAM[7:0]);
                            mat_stride <= 8'd1; end
                3'd1: begin mat_base <= SLOT_A + unit_a0;          // transpose
                            mat_stride <= K_PARAM[7:0]; end
                default: begin mat_base <= SLOT_T; mat_stride <= 8'd1; end
              endcase
              state <= ST_MV_GO;
            end
            U_POLY: begin
              if (unit_op == OP_ADDMSG) begin
                byte_rd_addr <= byte_base;
                state <= ST_AM_BW;
              end else begin
                seq_a_addr <= {unit_a0, 8'd0};
                seq_b_addr <= {unit_a1, 8'd0};
                state <= ST_PL_RD;
              end
            end
            U_CODEC: case (unit_op)
              OP_ENC12: begin seq_a_addr <= {unit_a1, 8'd0}; state <= ST_CE_W0; end
              OP_DEC12: begin byte_rd_addr <= byte_base;      state <= ST_CD_W; end
              OP_COMPR: begin seq_a_addr <= {unit_a1, 8'd0};  state <= ST_CP_W; end
              OP_DECOMP:begin byte_rd_addr <= byte_base;      state <= ST_DP_W; end
              OP_TOMSG: begin seq_a_addr <= {unit_a1, 8'd0};  state <= ST_TM_W; end
              default:  state <= ST_FIN;
            endcase
            default: state <= ST_FIN;
          endcase
        end

        // ================= NTT =============================================
        ST_NTT_LD: begin seq_a_addr <= {r_a1, 8'd1}; state <= ST_NTT_IN; end
        ST_NTT_IN: begin
          ntt_wr_addr <= idx[7:0];
          ntt_wr_data <= ps_a_data;
          ntt_wr_en   <= 1'b1;
          if (idx == 9'd255) begin
            idx <= 9'd0; ntt_start <= 1'b1; state <= ST_NTT_GO;
          end else begin
            seq_a_addr <= {r_a1, idx[7:0] + 8'd2};
            idx <= idx + 9'd1;
          end
        end
        // Gate on busy: ntt_engine's `done` is level-held.
        ST_NTT_GO:  if (ntt_busy) state <= ST_NTT_RUN;
        ST_NTT_RUN: if (!ntt_busy) begin
          ntt_rd_addr <= 8'd0; idx <= 9'd0; state <= ST_NTT_OUT;
        end
        ST_NTT_OUT: begin        // ntt_rd_data is combinational: no offset
          ps_w_addr <= {r_a2, ntt_rd_addr};
          ps_w_data <= ntt_rd_data;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin ntt_rd_addr <= ntt_rd_addr + 8'd1; idx <= idx + 9'd1; end
        end

        // ================= MATVEC ==========================================
        ST_MV_GO:  begin mv_start <= 1'b1; state <= ST_MV_ARM; end
        ST_MV_ARM: if (mv_busy) state <= ST_MV_WAIT;
        ST_MV_WAIT: if (!mv_busy) begin
          mv_acc_addr <= 8'd0; idx <= 9'd0; state <= ST_MV_COPY;
        end
        ST_MV_COPY: begin        // acc_rd_data is combinational: no offset
          ps_w_addr <= {r_a2, mv_acc_addr};
          ps_w_data <= mv_acc_data;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin mv_acc_addr <= mv_acc_addr + 8'd1; idx <= idx + 9'd1; end
        end

        // ================= POLY add / sub ==================================
        ST_PL_RD: state <= ST_PL_WR;
        ST_PL_WR: begin
          ps_w_addr <= {r_a2, idx[7:0]};
          ps_w_data <= (r_op == OP_SUB) ? sub_q : add_q;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin
            seq_a_addr <= {r_a0, idx[7:0] + 8'd1};
            seq_b_addr <= {r_a1, idx[7:0] + 8'd1};
            idx <= idx + 9'd1;
            state <= ST_PL_RD;
          end
        end

        // ================= ByteEncode_12 ===================================
        ST_CE_W0: state <= ST_CE_A0;
        ST_CE_A0: begin
          c0_reg     <= ps_a_data;
          seq_a_addr <= {r_a1, idx[6:0], 1'b1};
          state <= ST_CE_W1;
        end
        ST_CE_W1: state <= ST_CE_C1;
        ST_CE_C1: begin c1_reg <= ps_a_data; state <= ST_CE_B0; end
        ST_CE_B0: begin
          byte_wr_addr <= byte_base + bcnt; byte_wr_data <= c0_reg[7:0];
          byte_wr_en <= 1'b1; bcnt <= bcnt + 13'd1; state <= ST_CE_B1;
        end
        ST_CE_B1: begin
          byte_wr_addr <= byte_base + bcnt;
          byte_wr_data <= {c1_reg[3:0], c0_reg[11:8]};
          byte_wr_en <= 1'b1; bcnt <= bcnt + 13'd1; state <= ST_CE_B2;
        end
        ST_CE_B2: begin
          byte_wr_addr <= byte_base + bcnt; byte_wr_data <= c1_reg[11:4];
          byte_wr_en <= 1'b1; bcnt <= bcnt + 13'd1;
          if (idx == 9'd127) state <= ST_FIN;
          else begin
            seq_a_addr <= {r_a1, idx[6:0] + 7'd1, 1'b0};
            idx <= idx + 9'd1;
            state <= ST_CE_W0;
          end
        end

        // ================= ByteDecode_12 ===================================
        // Three bytes -> two 12-bit coefficients. Read one byte per pass into
        // the bit accumulator; emit a coefficient whenever 12 bits are held.
        ST_CD_W: state <= ST_CD_C;
        ST_CD_C: begin
          bitbuf <= bitbuf | ({24'd0, byte_rd_data} << bitcnt);
          bitcnt <= bitcnt + 6'd8;
          bcnt   <= bcnt + 13'd1;
          state  <= ST_CD_E;
        end
        ST_CD_E: begin
          if (bitcnt >= 6'd12) begin
            ps_w_addr <= {r_a2, idx[7:0]};
            ps_w_data <= {4'd0, bitbuf[11:0]};
            ps_w_en   <= 1'b1;
            bitbuf <= bitbuf >> 12;
            bitcnt <= bitcnt - 6'd12;
            if (idx == 9'd255) state <= ST_FIN;
            else idx <= idx + 9'd1;
          end else begin
            byte_rd_addr <= byte_base + bcnt;
            state <= ST_CD_W;
          end
        end

        // ================= Compress_d + pack ===============================
        ST_CP_W: state <= ST_CP_C;
        ST_CP_C: begin
          bitbuf <= bitbuf
                  | ({16'd0, compress_d(ps_a_data, dwidth)} << bitcnt);
          bitcnt <= bitcnt + {2'd0, dwidth};
          state  <= ST_CP_E;
        end
        ST_CP_E: begin
          if (bitcnt >= 6'd8) begin
            byte_wr_addr <= byte_base + bcnt;
            byte_wr_data <= bitbuf[7:0];
            byte_wr_en   <= 1'b1;
            bitbuf <= bitbuf >> 8;
            bitcnt <= bitcnt - 6'd8;
            bcnt   <= bcnt + 13'd1;
          end else if (idx == 9'd255) begin
            state <= ST_FIN;      // 256*d is a multiple of 8 for d=4 and 10
          end else begin
            seq_a_addr <= {r_a1, idx[7:0] + 8'd1};
            idx <= idx + 9'd1;
            state <= ST_CP_W;
          end
        end

        // ================= unpack + Decompress_d ===========================
        ST_DP_W: state <= ST_DP_C;
        ST_DP_C: begin
          bitbuf <= bitbuf | ({24'd0, byte_rd_data} << bitcnt);
          bitcnt <= bitcnt + 6'd8;
          bcnt   <= bcnt + 13'd1;
          state  <= ST_DP_E;
        end
        ST_DP_E: begin
          if (bitcnt >= {2'd0, dwidth}) begin
            ps_w_addr <= {r_a2, idx[7:0]};
            ps_w_data <= decompress_d(bitbuf[15:0] & ((16'd1 << dwidth) - 16'd1),
                                      dwidth);
            ps_w_en   <= 1'b1;
            bitbuf <= bitbuf >> dwidth;
            bitcnt <= bitcnt - {2'd0, dwidth};
            if (idx == 9'd255) state <= ST_FIN;
            else idx <= idx + 9'd1;
          end else begin
            byte_rd_addr <= byte_base + bcnt;
            state <= ST_DP_W;
          end
        end

        // ================= add-message =====================================
        // v = v + Decompress_1(m). One message byte covers eight coefficients.
        ST_AM_BW: state <= ST_AM_BA;
        ST_AM_BA: begin
          msg_byte   <= byte_rd_data;
          seq_a_addr <= {r_a0, idx[7:0]};
          state <= ST_AM_W;
        end
        ST_AM_W: state <= ST_AM_C;
        ST_AM_C: begin
          ps_w_addr <= {r_a2, idx[7:0]};
          ps_w_data <= addmsg_q;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin
            idx <= idx + 9'd1;
            if (idx[2:0] == 3'd7) begin           // next message byte
              byte_rd_addr <= byte_base + bcnt + 13'd1;
              bcnt  <= bcnt + 13'd1;
              state <= ST_AM_BW;
            end else begin
              seq_a_addr <= {r_a0, idx[7:0] + 8'd1};
              state <= ST_AM_W;
            end
          end
        end

        // ================= Compress_1 -> 32-byte message ===================
        ST_TM_W: state <= ST_TM_C;
        ST_TM_C: begin
          // A function result cannot be bit-selected inline; take bit 0 of a
          // named wire instead. Compress_1 yields a single bit per coefficient.
          bitbuf <= bitbuf | ({31'd0, tomsg_bit} << bitcnt);
          bitcnt <= bitcnt + 6'd1;
          state  <= ST_TM_E;
        end
        ST_TM_E: begin
          if (bitcnt >= 6'd8) begin
            byte_wr_addr <= byte_base + bcnt;
            byte_wr_data <= bitbuf[7:0];
            byte_wr_en   <= 1'b1;
            bitbuf <= bitbuf >> 8;
            bitcnt <= bitcnt - 6'd8;
            bcnt   <= bcnt + 13'd1;
            if (idx == 9'd255) state <= ST_FIN;
          end else if (idx == 9'd255) state <= ST_FIN;
          else begin
            seq_a_addr <= {r_a1, idx[7:0] + 8'd1};
            idx <= idx + 9'd1;
            state <= ST_TM_W;
          end
        end

        ST_FIN: begin unit_done <= 1'b1; state <= ST_IDLE; end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : kpke_datapath
