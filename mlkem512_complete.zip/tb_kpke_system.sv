`timescale 1ns/1ps
// =============================================================================
// tb_kpke_system.sv -- KeyGen driven by kpke_engine through the real datapath.
// The testbench now only asserts start/op and waits -- it issues NO service
// calls. Every one of the 21 calls comes from the FSM.
// =============================================================================
module tb_kpke_system;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg [1:0] op; reg start;
  wire busy, done, serr;
  wire [5:0] d_ra; reg [7:0] d_rd;
  wire [10:0] bw_addr; wire [7:0] bw_data; wire bw_en;
  wire [255:0] rho_out; wire [5:0] dbg;

  kpke_system #(.K_PARAM(2), .ADDR_W(13)) dut(
    .clk(clk), .rst_n(rst_n), .op(op), .start(start),
    .busy(busy), .done(done),
    .d_rd_data(d_rd), .d_rd_addr(d_ra),
    .byte_wr_addr(bw_addr), .byte_wr_data(bw_data), .byte_wr_en(bw_en),
    .rho_out(rho_out), .sample_error(serr), .dbg_engine_state(dbg));

  reg [7:0] dmem[0:63];
  always @(posedge clk) d_rd <= dmem[d_ra];
  reg [7:0] bytemem[0:2047];
  always @(posedge clk) if (bw_en) bytemem[bw_addr] <= bw_data;

  reg [7:0] g_ek[0:799], g_dk[0:767];
  integer errors=0, i;

  initial begin
    $readmemh("kg_d.hex", dmem);
    $readmemh("kg_ek.hex", g_ek);
    $readmemh("kg_dk.hex", g_dk);
    for (i=0;i<2048;i=i+1) bytemem[i]=8'hxx;

    $display("============================================================");
    $display("  kpke_engine driving kpke_top: full KeyGen, FSM-controlled");
    $display("============================================================");
    rst_n=0; start=0; op=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);

    @(negedge clk); op=2'd0; start=1'b1;
    @(negedge clk); start=1'b0;
    while(!busy) @(negedge clk);
    $display("[TB] engine started, running KeyGen unaided...");
    while(busy) @(negedge clk);
    repeat(4) @(posedge clk);
    $display("[TB] engine reported done");

    for (i=0;i<768;i=i+1)
      if (bytemem[i] !== g_ek[i]) begin
        if (errors<6) $display("[TB] FAIL ek[%0d]: got %02h want %02h",
                               i, bytemem[i], g_ek[i]);
        errors=errors+1;
      end
    if (errors==0) $display("[TB] ek: 768/768 encoded bytes match");

    for (i=0;i<32;i=i+1)
      if (rho_out[(31-i)*8 +: 8] !== g_ek[768+i]) begin
        if (errors<10) $display("[TB] FAIL rho[%0d]", i);
        errors=errors+1;
      end
    if (errors==0) $display("[TB] ek: rho tail matches -> full 800 B ek");

    for (i=0;i<768;i=i+1)
      if (bytemem[1024+i] !== g_dk[i]) begin
        if (errors<6) $display("[TB] FAIL dk[%0d]: got %02h want %02h",
                               i, bytemem[1024+i], g_dk[i]);
        errors=errors+1;
      end
    if (errors==0) $display("[TB] dk: 768/768 encoded bytes match");

    if (serr) begin $display("[TB] FAIL: sample_error"); errors=errors+1; end

    $display("============================================================");
    if (errors==0)
      $display("  PASS -- sequencer + datapath produce a correct key pair");
    else
      $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #900_000_000; $display("TIMEOUT engine_state=%0d",dbg); $finish; end
endmodule
