#!/usr/bin/env python3
"""
K-PKE KeyGen golden model, FIPS 203 Algorithm 13, ML-KEM-512 (k=2).
Written in the SAME conventions the RTL uses: plain (non-Montgomery)
arithmetic with Barrett reduction. Verified byte-for-byte against kyber-py.
"""
from hashlib import shake_128, shake_256, sha3_512

Q = 3329
K = 2          # ML-KEM-512
ETA1 = 3       # secret/error sampling for ML-KEM-512
ETA2 = 2

def br7(i): return int(f"{i:07b}"[::-1], 2)
ZETAS = [pow(17, br7(i), Q) for i in range(128)]

# ---------------- primitives (mirror the RTL exactly) ----------------
def barrett(x):
    t = ((x * 20159) + (1 << 25)) >> 26
    r = x - t * Q
    if r < 0:  r += Q
    if r >= Q: r -= Q
    return r

def ntt(f):
    f = list(f); i = 1; ln = 128
    while ln >= 2:
        for st in range(0, 256, 2 * ln):
            z = ZETAS[i]; i += 1
            for j in range(st, st + ln):
                t = barrett(z * f[j + ln])
                f[j + ln] = (f[j] - t) % Q
                f[j]      = (f[j] + t) % Q
        ln //= 2
    return f

def sample_ntt(xof_bytes):
    """Algorithm 7"""
    a = []; i = 0
    while len(a) < 256:
        b0, b1, b2 = xof_bytes[i], xof_bytes[i+1], xof_bytes[i+2]; i += 3
        d1 = b0 + 256 * (b1 % 16)
        d2 = (b1 // 16) + 16 * b2
        if d1 < Q: a.append(d1)
        if d2 < Q and len(a) < 256: a.append(d2)
    return a

def cbd(buf, eta):
    """Algorithm 8, eta in {2,3}"""
    bits = [(b >> k) & 1 for b in buf for k in range(8)]
    out = []
    for i in range(256):
        a = sum(bits[2*eta*i + j]       for j in range(eta))
        b = sum(bits[2*eta*i + eta + j] for j in range(eta))
        out.append((a - b) % Q)
    return out

def basemul(a0, a1, b0, b1, zeta):
    """Algorithm 11, plain arithmetic"""
    r0 = (barrett(barrett(a1 * b1) * zeta) + barrett(a0 * b0)) % Q
    r1 = (barrett(a0 * b1) + barrett(a1 * b0)) % Q
    return r0, r1

def poly_basemul(a, b):
    """Algorithm 12: 128 basemuls with alternating +/- zeta"""
    r = [0] * 256
    for i in range(64):
        z = ZETAS[64 + i]
        r[4*i],   r[4*i+1] = basemul(a[4*i],   a[4*i+1], b[4*i],   b[4*i+1],  z)
        r[4*i+2], r[4*i+3] = basemul(a[4*i+2], a[4*i+3], b[4*i+2], b[4*i+3], (Q - z) % Q)
    return r

def poly_add(a, b): return [(x + y) % Q for x, y in zip(a, b)]

def byte_encode12(coeffs):
    """Algorithm 4 (d=12): two coefficients per 3 bytes"""
    out = bytearray()
    for i in range(0, len(coeffs), 2):
        c0, c1 = coeffs[i], coeffs[i+1]
        out.append(c0 & 0xFF)
        out.append(((c0 >> 8) | (c1 << 4)) & 0xFF)
        out.append((c1 >> 4) & 0xFF)
    return bytes(out)

# ---------------- seed expansion (FIPS 203) ----------------
def G(s):
    h = sha3_512(s).digest()
    return h[:32], h[32:]

def XOF(rho, i, j):
    return shake_128(rho + bytes([i]) + bytes([j])).digest(840)

def PRF(eta, sigma, n):
    return shake_256(sigma + bytes([n])).digest(eta * 64)

# ---------------- Algorithm 13: K-PKE.KeyGen ----------------
def kpke_keygen(d):
    # NOTE: FIPS 203 appends the parameter k for domain separation.
    # Round-3 Kyber does NOT do this -- a real divergence at K-PKE level.
    rho, sigma = G(d + bytes([K]))

    # A_hat[i][j] = SampleNTT(XOF(rho, j, i))   <- note the j,i order
    A_hat = [[sample_ntt(XOF(rho, j, i)) for j in range(K)] for i in range(K)]

    N = 0
    s = []
    for i in range(K):
        s.append(cbd(PRF(ETA1, sigma, N), ETA1)); N += 1
    e = []
    for i in range(K):
        e.append(cbd(PRF(ETA1, sigma, N), ETA1)); N += 1

    s_hat = [ntt(p) for p in s]
    e_hat = [ntt(p) for p in e]

    # t_hat = A_hat @ s_hat + e_hat
    t_hat = []
    for i in range(K):
        acc = [0] * 256
        for j in range(K):
            acc = poly_add(acc, poly_basemul(A_hat[i][j], s_hat[j]))
        t_hat.append(poly_add(acc, e_hat[i]))

    ek = b"".join(byte_encode12(p) for p in t_hat) + rho
    dk = b"".join(byte_encode12(p) for p in s_hat)
    return ek, dk, dict(rho=rho, sigma=sigma, A_hat=A_hat,
                        s=s, e=e, s_hat=s_hat, e_hat=e_hat, t_hat=t_hat)

if __name__ == "__main__":
    d = bytes(range(32))
    ek, dk, dbg = kpke_keygen(d)
    print(f"ek: {len(ek)} bytes, first 16: {ek[:16].hex()}")
    print(f"dk: {len(dk)} bytes, first 16: {dk[:16].hex()}")

    # ---- verify against kyber-py ----
    from kyber_py.ml_kem import ML_KEM_512
    ek2, dk2 = ML_KEM_512._k_pke_keygen(d)
    print()
    print("ek matches kyber-py:", ek == ek2)
    print("dk matches kyber-py:", dk == dk2)
    if ek != ek2:
        for i,(x,y) in enumerate(zip(ek,ek2)):
            if x!=y: print(f"  first ek diff at byte {i}: {x:02x} vs {y:02x}"); break
