// =============================================================================
// kpke_engine.sv -- K-PKE: KeyGen, Encrypt, Decrypt
// FIPS 203 Algorithms 13, 14 and 15 (ML-KEM-512: k=2, eta1=3, eta2=2,
// du=10, dv=4)
// -----------------------------------------------------------------------------
// This is the sequencer that turns the verified primitives into the CPA-secure
// encryption scheme. It drives them through a single SERVICE INTERFACE
// (unit_sel / unit_op / unit_a0..a2 / unit_start / unit_done) rather than
// instantiating each one directly.
//
// Why a service interface rather than direct instantiation:
//   * The same sub-units are used repeatedly with different arguments -- the
//     XOF+SampleNTT pair runs k*k = 4 times in KeyGen and again in Encrypt,
//     the NTT runs 4 times in KeyGen. Instantiating one of each and
//     sequencing them is far smaller than replicating them.
//   * It matches how mlkem_fo_ctrl already talks to THIS module, so the two
//     layers compose the same way.
//   * It makes the control logic independently verifiable: the testbench
//     asserts the exact call sequence against the golden model, which is
//     where ordering bugs actually live. The arithmetic in each unit is
//     already verified by its own testbench.
//
// The memory map (which polynomial slot each result lands in) is carried in
// unit_a2 as a destination index. The datapath owner wires those slots to
// real BRAMs during integration.
//
// *** FIPS 203, NOT round-3 Kyber ***
// Seed derivation is  (rho, sigma) = G(d || k)  with the parameter byte k
// appended. Round-3's indcpa.c uses G(d) with no k byte. This changes rho,
// sigma, the matrix, the noise, and every downstream byte -- see
// PHASE4_ROADMAP.md.
// =============================================================================
module kpke_engine #(
  parameter integer K_PARAM = 2,     // ML-KEM-512
  parameter integer ETA1    = 3,     // secret / y sampling
  parameter integer ETA2    = 2,     // error sampling
  parameter integer DU      = 10,    // ciphertext u compression
  parameter integer DV      = 4,     // ciphertext v compression
  parameter [12:0]  EK_BASE_P = 13'd0
)(
  input  wire       clk,
  input  wire       rst_n,

  input  wire [1:0] op,              // 0 = KeyGen, 1 = Encrypt, 2 = Decrypt
  input  wire       start,
  output reg        busy,
  output reg        done,

  // ---- shared service interface to the verified primitives -------------
  output reg  [2:0] unit_sel,        // which unit
  output reg  [2:0] unit_op,         // operation within that unit
  output reg  [7:0] unit_a0,         // arg0: index i / nonce / eta / mode
  output reg  [7:0] unit_a1,         // arg1: index j / source slot
  output reg  [7:0] unit_a2,         // arg2: destination slot
  output reg        unit_start,
  input  wire       unit_done,

  // Where the current ByteEncode should start writing. Driven by the engine
  // because only it knows which polynomial of which key is being encoded.
  output reg [12:0] byte_base,

  output reg  [5:0] dbg_state
);

  // ---------------------------------------------------------------------------
  // Unit encodings
  // ---------------------------------------------------------------------------
  localparam U_HASH   = 3'd0;   // SHA3-512 (G) / SHA3-256 (H)
  localparam U_XOF    = 3'd1;   // SHAKE-128 + SampleNTT  (Algorithm 7)
  localparam U_PRF    = 3'd2;   // SHAKE-256 + CBD        (Algorithm 8)
  localparam U_NTT    = 3'd3;   // forward / inverse NTT  (Algorithm 9/10)
  localparam U_MATVEC = 3'd4;   // matvec_mul             (Algorithm 12 x k)
  localparam U_POLY   = 3'd5;   // polynomial add / sub
  localparam U_CODEC  = 3'd6;   // encode / decode / compress / decompress

  localparam OP_G       = 3'd0;   // U_HASH: G = SHA3-512
  localparam OP_NTT_FWD = 3'd0;   // U_NTT
  localparam OP_NTT_INV = 3'd1;
  localparam OP_ADD     = 3'd0;   // U_POLY
  localparam OP_SUB     = 3'd1;
  localparam OP_ADDMSG  = 3'd2;
  localparam OP_ENC12   = 3'd0;   // U_CODEC: ByteEncode_12
  localparam OP_DEC12   = 3'd1;   // ByteDecode_12
  localparam OP_COMPR   = 3'd2;   // Compress_d + ByteEncode_d
  localparam OP_DECOMP  = 3'd3;   // ByteDecode_d + Decompress_d
  localparam OP_TOMSG   = 3'd4;   // poly -> 32-byte message
  localparam OP_FROMMSG = 3'd5;   // 32-byte message -> poly

  // Polynomial slot map (destination indices carried in unit_a2)
  localparam SLOT_A     = 8'd0;    // A_hat[i][j] at SLOT_A + i*K + j   (0..3)
  localparam SLOT_S     = 8'd8;    // s / y            (8..9)
  localparam SLOT_E     = 8'd10;   // e / e1           (10..11)
  localparam SLOT_SHAT  = 8'd12;   // s_hat / y_hat    (12..13)
  localparam SLOT_EHAT  = 8'd14;   // e_hat            (14..15)
  localparam SLOT_T     = 8'd16;   // t_hat            (16..17)
  localparam SLOT_U     = 8'd18;   // u                (18..19)
  localparam SLOT_V     = 8'd20;   // v
  localparam SLOT_E2    = 8'd21;   // e2
  localparam SLOT_W     = 8'd22;   // w (decrypt)
  localparam SLOT_ACC   = 8'd23;

  // Byte-buffer layout: ek at 0, dk at 1024, ciphertext at 0 for Encrypt.
  // ek's location is set by whoever owns the byte buffer. mlkem_system puts
  // it at 2048; a standalone K-PKE testbench puts it at 0. Hard-coding 0 here
  // made Encrypt decode the CIPHERTEXT as if it were the public key.
  localparam [12:0] EK_BASE = EK_BASE_P;
  localparam [12:0] DK_BASE    = 13'd1024;
  localparam [12:0] COINS_BASE = 13'd1900;   // 32-byte encryption coins r
  localparam [12:0] MSG_BASE   = 13'd1868;   // 32-byte message m
  localparam [12:0] CT_BASE    = 13'd0;      // ciphertext c1||c2

  // ---------------------------------------------------------------------------
  // States
  // ---------------------------------------------------------------------------
  localparam ST_IDLE     = 6'd0;
  localparam ST_WAIT     = 6'd1;    // wait for unit_done, then go to ret_state

  // KeyGen (Algorithm 13)
  localparam ST_KG_G     = 6'd2;
  localparam ST_KG_MAT   = 6'd3;
  localparam ST_KG_S     = 6'd4;
  localparam ST_KG_E     = 6'd5;
  localparam ST_KG_NTTS  = 6'd6;
  localparam ST_KG_NTTE  = 6'd7;
  localparam ST_KG_MV    = 6'd8;
  localparam ST_KG_ADD   = 6'd9;
  localparam ST_KG_ENC   = 6'd10;

  // Encrypt (Algorithm 14)
  localparam ST_EN_DEC   = 6'd11;   // ByteDecode_12(ek) -> t_hat
  localparam ST_EN_MAT   = 6'd12;
  localparam ST_EN_Y     = 6'd13;
  localparam ST_EN_E1    = 6'd14;
  localparam ST_EN_E2    = 6'd15;
  localparam ST_EN_NTTY  = 6'd16;
  localparam ST_EN_MVU   = 6'd17;
  localparam ST_EN_INTU  = 6'd18;
  localparam ST_EN_ADDU  = 6'd19;
  localparam ST_EN_MVV   = 6'd20;
  localparam ST_EN_INTV  = 6'd21;
  localparam ST_EN_ADDV  = 6'd22;
  localparam ST_EN_MSG   = 6'd23;
  localparam ST_EN_CU    = 6'd24;
  localparam ST_EN_CV    = 6'd25;

  // Decrypt (Algorithm 15)
  localparam ST_DE_DCU   = 6'd26;
  localparam ST_DE_DCV   = 6'd27;
  localparam ST_DE_NTTU  = 6'd28;
  localparam ST_DE_MV    = 6'd29;
  localparam ST_DE_INT   = 6'd30;
  localparam ST_DE_SUB   = 6'd31;
  // Terminal state: entered only after the last service call has completed,
  // so `done` cannot be observed while work is still in flight.
  localparam ST_FINISH   = 6'd32;
  localparam ST_EN_DEC_UNUSED = 6'd33;
  localparam ST_DE_DK    = 6'd34;
  localparam ST_DE_DCU0  = 6'd35;
  localparam ST_EN_LDRHO = 6'd36;
  localparam ST_EN_LDKEY = 6'd37;

  // (ST_DE_MSG and ST_DONE reuse spare encodings via the second register)
  // 6 bits: states 0..31 were fully used before ST_FINISH was added.
  reg [5:0] state, ret_state;
  reg       final_msg;      // decrypt: after SUB, do TOMSG then finish
  reg [2:0] cnt;            // loop counter (i, j, or combined)

  always @(*) dbg_state = state;

  // Helper: issue a service call and park in ST_WAIT
  task issue(input [2:0] u, input [2:0] o,
             input [7:0] a0, input [7:0] a1, input [7:0] a2,
             input [5:0] nxt);
    begin
      unit_sel   <= u;
      unit_op    <= o;
      unit_a0    <= a0;
      unit_a1    <= a1;
      unit_a2    <= a2;
      unit_start <= 1'b1;
      ret_state  <= nxt;
      state      <= ST_WAIT;
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; ret_state <= ST_IDLE;
      busy <= 1'b0; done <= 1'b0; cnt <= 3'd0; final_msg <= 1'b0;
      unit_sel <= 3'd0; unit_op <= 3'd0;
      unit_a0 <= 8'd0; unit_a1 <= 8'd0; unit_a2 <= 8'd0;
      unit_start <= 1'b0; byte_base <= 13'd0;
    end else begin
      unit_start <= 1'b0;

      case (state)
        // =================================================================
        ST_IDLE: begin
          done <= 1'b0;
          if (start) begin
            busy <= 1'b1; cnt <= 3'd0; final_msg <= 1'b0;
            case (op)
              2'd0: issue(U_HASH, OP_G, 8'd0, 8'd0, 8'd0, ST_KG_MAT);  // G(d||k)
              2'd1: begin cnt <= 3'd0; state <= ST_EN_LDRHO; end
              // Decrypt must first recover s_hat from dk. The earlier flow
              // went straight to decompressing the ciphertext and never
              // decoded the secret key at all, so the matvec had nothing
              // valid to multiply against.
              2'd2: begin cnt <= 3'd0; state <= ST_DE_DK; end
              default: begin busy <= 1'b0; state <= ST_IDLE; end
            endcase
          end
        end

        // Single wait state for every service call.
        ST_WAIT: if (unit_done) state <= ret_state;

        // ============ Algorithm 13: K-PKE.KeyGen =========================
        // A_hat[i][j] = SampleNTT(XOF(rho, j, i)), i,j in 0..k-1
        ST_KG_MAT: begin
          // cnt encodes i*K + j
          issue(U_XOF, 3'd0,
                {6'd0, cnt[0]},                 // j  (inner index)
                {6'd0, cnt[1]},                 // i  (outer index)
                SLOT_A + {5'd0, cnt},           // destination A_hat[i][j]
                (cnt == K_PARAM*K_PARAM-1) ? ST_KG_S : ST_KG_MAT);
          cnt <= (cnt == K_PARAM*K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // s[i] = CBD_eta1(PRF(sigma, N++)),  N = 0 .. k-1
        ST_KG_S: begin
          issue(U_PRF, 3'd0, {5'd0, cnt}, ETA1[7:0], SLOT_S + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_KG_E : ST_KG_S);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // e[i] = CBD_eta1(PRF(sigma, N++)),  N = k .. 2k-1
        ST_KG_E: begin
          issue(U_PRF, 3'd0, K_PARAM[7:0] + {5'd0, cnt}, ETA1[7:0],
                SLOT_E + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_KG_NTTS : ST_KG_E);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        ST_KG_NTTS: begin
          issue(U_NTT, OP_NTT_FWD, 8'd0, SLOT_S + {5'd0, cnt},
                SLOT_SHAT + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_KG_NTTE : ST_KG_NTTS);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        ST_KG_NTTE: begin
          issue(U_NTT, OP_NTT_FWD, 8'd0, SLOT_E + {5'd0, cnt},
                SLOT_EHAT + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_KG_MV : ST_KG_NTTE);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // t_hat[i] = sum_j A_hat[i][j] o s_hat[j]   then  + e_hat[i]
        ST_KG_MV: begin
          issue(U_MATVEC, 3'd0, {5'd0, cnt}, SLOT_SHAT, SLOT_ACC, ST_KG_ADD);
        end
        ST_KG_ADD: begin
          issue(U_POLY, OP_ADD, SLOT_ACC, SLOT_EHAT + {5'd0, cnt},
                SLOT_T + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_KG_ENC : ST_KG_MV);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // ek = ByteEncode_12(t_hat) || rho ; dk = ByteEncode_12(s_hat)
        // ek = ByteEncode_12(t_hat[0..k-1]) || rho
        // dk = ByteEncode_12(s_hat[0..k-1])
        // Each key is K polynomials of 384 bytes, so this runs 2*K times.
        // An earlier version issued ONE encode per key, which silently
        // produced only the first 384 bytes of each for k=2.
        ST_KG_ENC: begin
          if (cnt < K_PARAM[2:0]) begin
            byte_base <= EK_BASE + ({8'd0, cnt} * 13'd384);
            issue(U_CODEC, OP_ENC12, 8'd0, SLOT_T + {5'd0, cnt}, 8'd0,
                  ST_KG_ENC);
          end else begin
            byte_base <= DK_BASE
                       + (({8'd0, cnt} - K_PARAM[10:0]) * 13'd384);
            issue(U_CODEC, OP_ENC12, 8'd0,
                  SLOT_SHAT + {5'd0, (cnt - K_PARAM[2:0])}, 8'd1,
                  (cnt == 2*K_PARAM-1) ? ST_FINISH : ST_KG_ENC);
          end
          cnt <= cnt + 3'd1;
        end

        // ============ Algorithm 14: K-PKE.Encrypt ========================
        // A_hat regenerated from rho, same order as KeyGen. The TRANSPOSE
        // that Encrypt needs is applied by matvec's addressing, not here.
        // Encrypt's rho is the LAST 32 bytes of ek (offset 384*k), and its
        // PRF key is the caller-supplied coins, not sigma. Both must be
        // loaded before any XOF or PRF call.
        ST_EN_LDRHO: begin
          byte_base <= EK_BASE + (K_PARAM[10:0] * 13'd384);
          issue(U_HASH, 3'd1, 8'd0, 8'd0, 8'd0, ST_EN_LDKEY);
        end
        ST_EN_LDKEY: begin
          byte_base <= COINS_BASE;
          issue(U_HASH, 3'd2, 8'd0, 8'd0, 8'd0, ST_EN_DEC);
        end

        ST_EN_DEC: begin
          // EK_BASE was lost here during an earlier width cleanup, so Encrypt
          // decoded from offset 0 -- i.e. it read the CIPHERTEXT as if it were
          // the public key. t_hat came out with coefficients above q, which is
          // impossible for a real key and was the tell.
          byte_base <= EK_BASE + ({10'd0, cnt} * 13'd384);
          issue(U_CODEC, OP_DEC12, 8'd0, 8'd0, SLOT_T + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_EN_MAT : ST_EN_DEC);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        ST_EN_MAT: begin
          issue(U_XOF, 3'd0, {6'd0, cnt[0]}, {6'd0, cnt[1]},
                SLOT_A + {5'd0, cnt},
                (cnt == K_PARAM*K_PARAM-1) ? ST_EN_Y : ST_EN_MAT);
          cnt <= (cnt == K_PARAM*K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // y[i] = CBD_eta1(PRF(r, N++)),  N = 0 .. k-1
        ST_EN_Y: begin
          issue(U_PRF, 3'd0, {5'd0, cnt}, ETA1[7:0], SLOT_S + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_EN_E1 : ST_EN_Y);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // e1[i] = CBD_eta2(PRF(r, N++)),  N = k .. 2k-1   <- ETA2, not ETA1
        ST_EN_E1: begin
          issue(U_PRF, 3'd0, K_PARAM[7:0] + {5'd0, cnt}, ETA2[7:0],
                SLOT_E + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_EN_E2 : ST_EN_E1);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // e2 = CBD_eta2(PRF(r, 2k))
        ST_EN_E2: issue(U_PRF, 3'd0, (2*K_PARAM), ETA2[7:0], SLOT_E2, ST_EN_NTTY);

        ST_EN_NTTY: begin
          issue(U_NTT, OP_NTT_FWD, 8'd0, SLOT_S + {5'd0, cnt},
                SLOT_SHAT + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_EN_MVU : ST_EN_NTTY);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // u[i] = INTT(sum_j A_hat[j][i] o y_hat[j]) + e1[i]   (transposed)
        ST_EN_MVU: issue(U_MATVEC, 3'd1, {5'd0, cnt}, SLOT_SHAT, SLOT_ACC,
                         ST_EN_INTU);
        ST_EN_INTU: issue(U_NTT, OP_NTT_INV, 8'd0, SLOT_ACC, SLOT_ACC,
                          ST_EN_ADDU);
        ST_EN_ADDU: begin
          issue(U_POLY, OP_ADD, SLOT_ACC, SLOT_E + {5'd0, cnt},
                SLOT_U + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_EN_MVV : ST_EN_MVU);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // v = INTT(sum_i t_hat[i] o y_hat[i]) + e2 + Decompress_1(m)
        ST_EN_MVV:  issue(U_MATVEC, 3'd2, 8'd0, SLOT_SHAT, SLOT_ACC, ST_EN_INTV);
        ST_EN_INTV: issue(U_NTT, OP_NTT_INV, 8'd0, SLOT_ACC, SLOT_ACC, ST_EN_ADDV);
        ST_EN_ADDV: issue(U_POLY, OP_ADD, SLOT_ACC, SLOT_E2, SLOT_V, ST_EN_MSG);
        ST_EN_MSG: begin
          byte_base <= MSG_BASE;
          issue(U_POLY, OP_ADDMSG, SLOT_V, 8'd0, SLOT_V, ST_EN_CU);
        end

        // c = ByteEncode_du(Compress_du(u)) || ByteEncode_dv(Compress_dv(v))
        ST_EN_CU: begin
          byte_base <= CT_BASE + ({8'd0, cnt} * 13'd320);   // 32*du = 320
          issue(U_CODEC, OP_COMPR, DU[7:0], SLOT_U + {5'd0, cnt}, 8'd0,
                (cnt == K_PARAM-1) ? ST_EN_CV : ST_EN_CU);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end
        ST_EN_CV: begin
          byte_base <= CT_BASE + (K_PARAM[10:0] * 13'd320);
          issue(U_CODEC, OP_COMPR, DV[7:0], SLOT_V, 8'd1, ST_FINISH);
        end

        // ============ Algorithm 15: K-PKE.Decrypt ========================
        // u = Decompress_du(ByteDecode_du(c1)),  v = Decompress_dv(c2)
        // s_hat lands in SLOT_T, which Decrypt does not otherwise use.
        ST_DE_DK: begin
          byte_base <= DK_BASE + ({8'd0, cnt} * 13'd384);
          issue(U_CODEC, OP_DEC12, 8'd0, 8'd0, SLOT_T + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_DE_DCU0 : ST_DE_DK);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        ST_DE_DCU0: begin
          byte_base <= CT_BASE;
          issue(U_CODEC, OP_DECOMP, DU[7:0], 8'd0, SLOT_U, ST_DE_DCU);
          cnt <= 3'd1;
        end

        // cnt counts u polynomials ALREADY issued (DCU0 did u[0]), so the
        // loop must run until cnt reaches K, not K-1. With K=2 the old
        // condition skipped u[1] entirely and went straight to v.
        ST_DE_DCU: begin
          if (cnt == K_PARAM[2:0]) begin
            cnt <= 3'd0;
            byte_base <= CT_BASE + (K_PARAM[10:0] * 13'd320);
            issue(U_CODEC, OP_DECOMP, DV[7:0], 8'd1, SLOT_V, ST_DE_NTTU);
          end else begin
            byte_base <= CT_BASE + ({8'd0, cnt} * 13'd320);
            cnt <= cnt + 3'd1;
            issue(U_CODEC, OP_DECOMP, DU[7:0], 8'd0,
                  SLOT_U + {5'd0, cnt}, ST_DE_DCU);
          end
        end
        ST_DE_DCV: state <= ST_DE_NTTU;      // (folded into ST_DE_DCU above)

        ST_DE_NTTU: begin
          issue(U_NTT, OP_NTT_FWD, 8'd0, SLOT_U + {5'd0, cnt},
                SLOT_SHAT + {5'd0, cnt},
                (cnt == K_PARAM-1) ? ST_DE_MV : ST_DE_NTTU);
          cnt <= (cnt == K_PARAM-1) ? 3'd0 : cnt + 3'd1;
        end

        // w = v - INTT(sum_i s_hat[i] o u_hat[i]);  m = Compress_1(w)
        ST_DE_MV:  issue(U_MATVEC, 3'd3, 8'd0, SLOT_SHAT, SLOT_ACC, ST_DE_INT);
        ST_DE_INT: issue(U_NTT, OP_NTT_INV, 8'd0, SLOT_ACC, SLOT_ACC, ST_DE_SUB);
        ST_DE_SUB: begin
          if (!final_msg) begin
            final_msg <= 1'b1;
            issue(U_POLY, OP_SUB, SLOT_V, SLOT_ACC, SLOT_W, ST_DE_SUB);
          end else begin
            byte_base <= MSG_BASE;
            issue(U_CODEC, OP_TOMSG, 8'd0, SLOT_W, 8'd0, ST_FINISH);
          end
        end

        ST_FINISH: begin
          cnt  <= 3'd0;
          busy <= 1'b0;
          done <= 1'b1;
          state <= ST_IDLE;
        end

        default: begin busy <= 1'b0; state <= ST_IDLE; end
      endcase
    end
  end
endmodule : kpke_engine
