module keccak_round (
  input  wire [1599:0] state_in,
  input  wire [4:0]    round_idx,   // 0..23
  output reg  [1599:0] state_out
);
  import keccak_pkg::*;

  // Unpack into 25 lanes, lane index = 5*y + x
  logic [63:0] a [0:24];
  logic [63:0] c [0:4];
  logic [63:0] d [0:4];
  logic [63:0] b [0:24];   // after rho+pi
  logic [63:0] s2[0:24];   // after chi
  integer x, y;

  function automatic logic [63:0] rotl64(input logic [63:0] v, input int unsigned n);
    if (n == 0) rotl64 = v;
    else        rotl64 = (v << n) | (v >> (64 - n));
  endfunction

  always @(*) begin
    // unpack
    for (x = 0; x < 5; x = x + 1)
      for (y = 0; y < 5; y = y + 1)
        a[5*y+x] = state_in[64*(5*y+x) +: 64];

    // theta
    for (x = 0; x < 5; x = x + 1)
      c[x] = a[5*0+x] ^ a[5*1+x] ^ a[5*2+x] ^ a[5*3+x] ^ a[5*4+x];
    for (x = 0; x < 5; x = x + 1)
      d[x] = c[(x+4)%5] ^ rotl64(c[(x+1)%5], 1);
    for (x = 0; x < 5; x = x + 1)
      for (y = 0; y < 5; y = y + 1)
        a[5*y+x] = a[5*y+x] ^ d[x];

    // rho + pi: output lane (X=y, Y=(2x+3y)%5) = rotl(a[x,y], offset(x,y))
    for (x = 0; x < 5; x = x + 1)
      for (y = 0; y < 5; y = y + 1)
        b[5*((2*x+3*y)%5) + y] = rotl64(a[5*y+x], rot_offset(5*y+x));

    // chi
    for (x = 0; x < 5; x = x + 1)
      for (y = 0; y < 5; y = y + 1)
        s2[5*y+x] = b[5*y+x] ^ ((~b[5*y+((x+1)%5)]) & b[5*y+((x+2)%5)]);

    // iota
    s2[0] = s2[0] ^ round_const(round_idx);

    // pack
    for (x = 0; x < 5; x = x + 1)
      for (y = 0; y < 5; y = y + 1)
        state_out[64*(5*y+x) +: 64] = s2[5*y+x];
  end
endmodule : keccak_round
