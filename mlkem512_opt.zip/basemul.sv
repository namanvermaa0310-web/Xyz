// =============================================================================
// basemul.sv -- FIPS 203 Algorithm 11, PIPELINED
// Degree-2 polynomial multiply in Z_q[X]/(X^2 - zeta):
//     r0 = (a0*b0 + a1*b1*zeta) mod q
//     r1 = (a0*b1 + a1*b0)      mod q
// -----------------------------------------------------------------------------
// WHY THIS IS FASTER THAN THE ORIGINAL
//
// The original ran five multiply-and-reduce sequences strictly one after
// another, each taking three states (MUL -> EST -> CORR), for ~20 cycles.
// But look at the dependencies:
//
//     t1 = a1*b1   ---+
//     t2 = t1*zeta <--+   the ONLY real dependency
//     t3 = a0*b0   ---+
//     t4 = a0*b1      |   independent of everything
//     t5 = a1*b0   ---+
//
// Four of the five products depend on nothing. Running them sequentially left
// the multiplier idle two cycles out of every three.
//
// MUL -> EST -> CORR is already a three-stage pipeline in disguise. Making it
// a real one lets a new product be issued EVERY cycle:
//
//     cycle 0  issue a1*b1   (tag 0)
//     cycle 1  issue a0*b0   (tag 1)
//     cycle 2  issue a0*b1   (tag 2)
//     cycle 3  issue a1*b0   (tag 3)   <- t1 lands here
//     cycle 4  issue t1*zeta (tag 4)
//     cycles 5-7  drain
//     cycle 8  r0 = t2+t3, r1 = t4+t5
//
// ~20 cycles -> ~10. NO extra multipliers: the same DSP is used every cycle
// instead of one cycle in three. Each pipeline stage still contains at most
// one multiply, so the timing discipline that made the design close at
// 100 MHz is preserved.
//
// Results are collected BY TAG rather than by arrival order, so the schedule
// can be changed without breaking the collection logic.
// =============================================================================
module basemul (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,        // pulse to begin one basemul
  input  wire [15:0] a0, a1,       // first polynomial:  a0 + a1*X
  input  wire [15:0] b0, b1,       // second polynomial: b0 + b1*X
  input  wire [15:0] zeta,         // reduction polynomial root
  output reg  [15:0] r0, r1,       // result: r0 + r1*X
  output reg         done,
  output wire        busy
);

  // ---------------------------------------------------------------------------
  // Latched inputs
  // ---------------------------------------------------------------------------
  reg [15:0] a0_r, a1_r, b0_r, b1_r, zeta_r;

  // ---------------------------------------------------------------------------
  // Three-stage Barrett pipeline.
  //   S1: multiply
  //   S2: quotient estimate   (x * 20159) >> 26
  //   S3: correct             x - t*q, then conditional +/- q
  // A tag travels with each product so results can be sorted on arrival.
  // ---------------------------------------------------------------------------
  reg        s1_v, s2_v, s3_v;
  reg [2:0]  s1_tag, s2_tag, s3_tag;
  reg [31:0] s1_prod;
  reg [38:0] s2_est;
  reg [23:0] s2_prod;
  reg [15:0] s3_out;

  // Stage-1 operands, selected by the schedule below.
  reg [15:0] mul_x, mul_y;
  reg [2:0]  mul_tag;
  reg        mul_issue;

  wire [38:0] est_next  = (s1_prod[23:0] * 24'd20159) + 26'd33554432;
  wire [12:0] tval      = s2_est[38:26];
  wire [24:0] bar_diff  = {1'b0, s2_prod} - (tval * 25'd3329);
  wire [15:0] bar_out   = bar_diff[24]            ? (bar_diff[15:0] + 16'd3329) :
                          (bar_diff >= 25'd3329)  ? (bar_diff[15:0] - 16'd3329) :
                                                     bar_diff[15:0];

  // ---------------------------------------------------------------------------
  // Collected partial products
  // ---------------------------------------------------------------------------
  reg [15:0] t1, t2, t3, t4, t5;
  reg        t1_rdy, t2_rdy, t3_rdy, t4_rdy, t5_rdy;

  localparam TAG_T1 = 3'd0;   // a1*b1
  localparam TAG_T3 = 3'd1;   // a0*b0
  localparam TAG_T4 = 3'd2;   // a0*b1
  localparam TAG_T5 = 3'd3;   // a1*b0
  localparam TAG_T2 = 3'd4;   // t1*zeta

  localparam S_IDLE = 3'd0;
  localparam S_RUN  = 3'd1;
  localparam S_FIN  = 3'd2;

  reg [2:0] state;
  reg [3:0] cnt;              // schedule step

  assign busy = (state != S_IDLE);

  // Modular add for the two final sums
  function automatic [15:0] addq(input [15:0] x, input [15:0] y);
    reg [16:0] s;
    begin
      s = x + y;
      addq = (s >= 17'd3329) ? (s - 17'd3329) : s[15:0];
    end
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; cnt <= 4'd0; done <= 1'b0;
      r0 <= 16'd0; r1 <= 16'd0;
      s1_v <= 1'b0; s2_v <= 1'b0; s3_v <= 1'b0;
      s1_tag <= 3'd0; s2_tag <= 3'd0; s3_tag <= 3'd0;
      s1_prod <= 32'd0; s2_est <= 39'd0; s2_prod <= 24'd0; s3_out <= 16'd0;
      mul_x <= 16'd0; mul_y <= 16'd0; mul_tag <= 3'd0; mul_issue <= 1'b0;
      t1 <= 16'd0; t2 <= 16'd0; t3 <= 16'd0; t4 <= 16'd0; t5 <= 16'd0;
      t1_rdy <= 1'b0; t2_rdy <= 1'b0; t3_rdy <= 1'b0;
      t4_rdy <= 1'b0; t5_rdy <= 1'b0;
      a0_r <= 16'd0; a1_r <= 16'd0; b0_r <= 16'd0; b1_r <= 16'd0; zeta_r <= 16'd0;
    end else begin
      done      <= 1'b0;
      mul_issue <= 1'b0;

      // ---- pipeline advance, every cycle regardless of the FSM ----
      s1_v    <= mul_issue;
      s1_tag  <= mul_tag;
      s1_prod <= mul_x * mul_y;

      s2_v    <= s1_v;
      s2_tag  <= s1_tag;
      s2_est  <= est_next;
      s2_prod <= s1_prod[23:0];

      s3_v    <= s2_v;
      s3_tag  <= s2_tag;
      s3_out  <= bar_out;

      // ---- collect results by tag as they emerge ----
      if (s3_v) begin
        case (s3_tag)
          TAG_T1: begin t1 <= s3_out; t1_rdy <= 1'b1; end
          TAG_T2: begin t2 <= s3_out; t2_rdy <= 1'b1; end
          TAG_T3: begin t3 <= s3_out; t3_rdy <= 1'b1; end
          TAG_T4: begin t4 <= s3_out; t4_rdy <= 1'b1; end
          default: begin t5 <= s3_out; t5_rdy <= 1'b1; end
        endcase
      end

      case (state)
        S_IDLE: if (start) begin
          a0_r <= a0; a1_r <= a1; b0_r <= b0; b1_r <= b1; zeta_r <= zeta;
          t1_rdy <= 1'b0; t2_rdy <= 1'b0; t3_rdy <= 1'b0;
          t4_rdy <= 1'b0; t5_rdy <= 1'b0;
          cnt   <= 4'd0;
          state <= S_RUN;
        end

        S_RUN: begin
          cnt <= cnt + 4'd1;
          case (cnt)
            // Four independent products, one issued per cycle.
            4'd0: begin mul_x <= a1_r; mul_y <= b1_r;
                        mul_tag <= TAG_T1; mul_issue <= 1'b1; end
            4'd1: begin mul_x <= a0_r; mul_y <= b0_r;
                        mul_tag <= TAG_T3; mul_issue <= 1'b1; end
            4'd2: begin mul_x <= a0_r; mul_y <= b1_r;
                        mul_tag <= TAG_T4; mul_issue <= 1'b1; end
            4'd3: begin mul_x <= a1_r; mul_y <= b0_r;
                        mul_tag <= TAG_T5; mul_issue <= 1'b1; end
            // t1's result is present on s3_out DURING cnt=4, but the collect
            // block only latches it into the t1 register at the END of that
            // cycle. Reading t1 here would take the stale value; forwarding
            // from s3_out uses it a cycle earlier. This is a standard operand
            // bypass, and it is safe because the schedule guarantees the T1
            // product is the one in stage 3 at this exact point -- asserted
            // below rather than assumed.
            4'd4: begin mul_x <= s3_out; mul_y <= zeta_r;
                        mul_tag <= TAG_T2; mul_issue <= 1'b1;
                      end
            default: begin
              // Drain, then combine once every partial product is in.
              if (t1_rdy && t2_rdy && t3_rdy && t4_rdy && t5_rdy) begin
                r0    <= addq(t2, t3);
                r1    <= addq(t4, t5);
                state <= S_FIN;
              end
            end
          endcase
        end

        S_FIN: begin
          done  <= 1'b1;
          state <= S_IDLE;
        end

        default: state <= S_IDLE;
      endcase
    end
  end
  // Guard the operand bypass above. The schedule guarantees that stage 3
  // holds the T1 product exactly when cnt==4; this fails loudly in simulation
  // if a future schedule change breaks that.
  // synthesis translate_off
  always @(posedge clk)
    if (rst_n && state == S_RUN && cnt == 4'd4 && !(s3_v && s3_tag == TAG_T1))
      $display("BASEMUL BYPASS ERROR: stage 3 not T1 at cnt=4 (v=%b tag=%0d)",
               s3_v, s3_tag);
  // synthesis translate_on

endmodule : basemul
