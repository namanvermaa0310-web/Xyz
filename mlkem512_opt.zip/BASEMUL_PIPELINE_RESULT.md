# basemul pipelining -- result

## What changed

`basemul` ran five multiply-and-reduce sequences strictly one after another,
each three states (MUL -> EST -> CORR), for ~20 cycles. Only ONE of the five
products actually depends on another:

    t1 = a1*b1   ---+
    t2 = t1*zeta <--+   the only real dependency
    t3 = a0*b0   ---+
    t4 = a0*b1      |   independent
    t5 = a1*b0   ---+

MUL -> EST -> CORR is a three-stage pipeline in disguise. Making it a real one
issues a new product every cycle. A tag travels with each product so results
are collected by identity rather than arrival order.

An operand bypass forwards t1 from the pipeline output to the dependent
multiply, saving one more cycle. A simulation-only assertion guards it: if a
future schedule change means stage 3 no longer holds T1 at that point, it
fails loudly instead of silently computing the wrong thing.

**20 cycles -> 12. No extra DSPs** -- the same multiplier is used every cycle
instead of one cycle in three. Each stage still contains at most one multiply,
so the timing discipline that closed 100 MHz is preserved.

## Measured result

    KeyGen before : 68,526 cycles = 685 us
    KeyGen after  : 64,942 cycles = 649 us
    Saving        :  3,584 cycles = 5.2%

    matvec before : 18,966 cycles (27.7% of KeyGen)
    matvec after  : 15,382 cycles (23.7%)

## I predicted 14%. It delivered 5.2%. Here is why.

The arithmetic was right -- 512 basemul calls in KeyGen, 8 cycles saved each,
4,096 predicted, 3,584 measured. What was wrong was the assumption that
basemul dominated matvec.

It does not:

    basemul work in matvec now : 512 x 12 = 6,144 cycles (40%)
    poly_basemul loop overhead :            9,238 cycles (60%)

**Sixty percent of matvec is the loop around basemul, not basemul itself** --
memory reads, address generation, state transitions per iteration. Speeding up
the inner operation by 40% could never yield more than it did while that
overhead stands.

This is worth recording because it changes where the next effort should go.

## Revised optimisation targets

    NTT engine       21,504   33.1%   <- now the largest single item
    matvec           15,382   23.7%   (60% of which is loop overhead)
    XOF+SampleNTT     8,934   13.8%
    PRF+CBD           6,968   10.7%
    overhead          7,665   11.8%
    G/H hashes        4,489    6.9%

1. **NTT butterfly overlap** -- 6 cycles/butterfly with no overlap, 896
   butterflies x 4 transforms. Butterflies within a stage are independent, so
   the same pipelining argument applies and the prize is larger.
   Estimated 21,504 -> ~4,000.

2. **poly_basemul loop overhead** -- now a bigger target than basemul was.
   The per-iteration memory reads could overlap with the basemul pipeline
   instead of serialising against it.

Both should be measured the same way rather than estimated: the lesson from
this exercise is that an inner-loop speedup is capped by whatever surrounds it.

## Verification after the change

    NIST ACVP keyGen vector : ek 768/768, rho tail 32/32, dk_pke and H(ek) OK
    Full ML-KEM regression  : shared secret agreement + implicit rejection PASS
    basemul unit test       : 40 random vectors, all match

## Still to do

Re-synthesise and check WNS. The pipeline adds registers, which usually helps
timing by shortening paths, but it also adds routing. Board margin was
+0.122 ns, so this must be confirmed rather than assumed -- and the NIST
vectors must be re-run on the new bitstream before the result is trusted.
