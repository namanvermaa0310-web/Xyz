`timescale 1ns/1ps
module tb_ntt_pipe;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg start, mode, wr_en; reg [7:0] wr_addr, rd_addr; reg [15:0] wr_data;
  wire done, busy; wire [15:0] rd_data;
  ntt_engine dut(.clk(clk),.rst_n(rst_n),.start(start),.mode(mode),
    .done(done),.busy(busy),.wr_addr(wr_addr),.wr_data(wr_data),.wr_en(wr_en),
    .rd_addr(rd_addr),.rd_data(rd_data));

  reg [15:0] in_v[0:1023], fwd_v[0:1023], inv_v[0:1023];
  integer p, i, errors, cyc, e_f, e_i;

  task load(input integer base, input integer which);
    begin
      for (i=0;i<256;i=i+1) begin
        @(negedge clk); wr_en=1; wr_addr=i[7:0];
        wr_data = in_v[base+i];
      end
      @(negedge clk); wr_en=0;
    end
  endtask

  task run(input m);
    begin
      @(negedge clk); mode=m; start=1;
      @(negedge clk); start=0;
      cyc=0;
      while(!busy) @(posedge clk);
      while(busy) begin @(posedge clk); cyc=cyc+1; end
    end
  endtask

  initial begin
    $readmemh("nt_in.hex",  in_v);
    $readmemh("nt_fwd.hex", fwd_v);
    $readmemh("nt_inv.hex", inv_v);
    errors=0; start=0; wr_en=0; mode=0; wr_addr=0; wr_data=0; rd_addr=0;
    repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);

    for (p=0;p<4;p=p+1) begin
      // ---- forward NTT ----
      load(p*256, 0);
      run(1'b0);
      e_f=0;
      for (i=0;i<256;i=i+1) begin
        rd_addr=i[7:0]; #1;
        if (rd_data !== fwd_v[p*256+i]) begin
          if (e_f<3) $display("[TB] poly %0d NTT[%0d] got %0d want %0d",
                              p, i, rd_data, fwd_v[p*256+i]);
          e_f=e_f+1;
        end
      end
      if (p==0) $display("[TB] forward NTT: %0d cycles", cyc);

      // ---- inverse NTT of the same input ----
      load(p*256, 0);
      run(1'b1);
      e_i=0;
      for (i=0;i<256;i=i+1) begin
        rd_addr=i[7:0]; #1;
        if (rd_data !== inv_v[p*256+i]) begin
          if (e_i<3) $display("[TB] poly %0d INTT[%0d] got %0d want %0d",
                              p, i, rd_data, inv_v[p*256+i]);
          e_i=e_i+1;
        end
      end
      if (p==0) $display("[TB] inverse NTT: %0d cycles", cyc);
      errors = errors + e_f + e_i;
    end

    $display("============================================================");
    if (errors==0)
      $display("  PASS -- 4 polys, NTT and INTT, 2048/2048 coefficients exact");
    else
      $display("  FAIL -- %0d coefficient error(s)", errors);
    $display("  original engine: 5,376 cycles per transform");
    $display("============================================================");
    $finish;
  end
  initial begin #50_000_000; $display("TIMEOUT"); $finish; end
endmodule
