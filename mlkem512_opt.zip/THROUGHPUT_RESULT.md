# Throughput work -- results

## Summary

    KeyGen   68,526 cycles  685 us   original
             64,942 cycles  649 us   + basemul pipelined      (-5.2%)
             47,302 cycles  473 us   + NTT pipelined          (-27%)

    Overall: 1.45x faster (31% less time), all correctness preserved.

## NTT pipeline -- the big win

    per transform:  5,376 -> 967 cycles   (5.6x)
    KeyGen share:   21,504 -> 3,864 cycles

The original ran one butterfly at a time, six cycles each, so every stage of
its sequence was busy one cycle in six. Within one NTT stage the 128
butterflies touch disjoint coefficient pairs -- fully independent -- so they
now issue one per cycle and overlap.

Between stages there IS a dependency (stage s+1 reads what stage s wrote), so
the pipeline drains 10 cycles before the next stage's first read:

    7 stages x (128 butterflies + 10 drain) + tail  =  967 cycles

**The timing rule is preserved.** Every pipeline stage still holds at most one
multiply -- the rule that took this module from WNS -17.6 ns to closure in
Phase 1. The N^-1 scaling runs through its own stages for every butterfly and
is bypassed when not needed, giving uniform latency so the drain is a constant.

**Interface unchanged.** Same ports, same butterfly visiting order, same
twiddles, same arithmetic. rd_data stays a continuous assign (kpke_datapath
depends on zero read latency). kpke_datapath needed no change.

## This time the prediction held

The basemul work predicted 14% and delivered 5.2%, because the loop around it
dominated. That lesson was applied here: the NTT's memory access pattern was
checked BEFORE redesigning, and the estimate was built from the real schedule.

## Verification

    NTT unit test         4 random polys, NTT and INTT, 2048/2048 exact
    NIST ACVP keyGen      ek 768/768, rho 32/32, dk_pke + H(ek) exact
    Full ML-KEM           shared secret agreement + implicit rejection PASS

## Where the time goes now

    matvec           15,382   32.5%   <- now the largest item
    XOF+SampleNTT     8,934   18.9%
    other/overhead    7,665   16.2%   includes 512 cycles/NTT of copy-in/out
    PRF+CBD           6,968   14.7%
    G/H hashes        4,489    9.5%
    NTT engine        3,864    8.2%   was 31.4%

The bottleneck has moved. Next targets, in order:
  1. poly_basemul loop overhead -- 60% of matvec is the loop around basemul
  2. NTT copy engines -- 512 cycles per transform just moving data in and out;
     the NTT itself now costs less than its own copies
  3. Keccak: sequential byte load was the fix for the Phase 2 synthesis
     failure, and it now shows up as a real cost

## MUST CHECK IN VIVADO BEFORE TRUSTING THIS

1. **Memory inference changed.** The pipelined NTT reads two coefficients AND
   writes two per cycle. That cannot map to a single dual-port BRAM, so
   coeff_mem (256 x 16) will be built from registers plus read muxes -- about
   4,096 flip-flops. The original's ram_style="block" hint was removed because
   it cannot be honoured. Expect FF and LUT to rise.

2. **WNS.** Board margin was +0.122 ns. Pipelining shortens paths, which
   usually helps, but the register-built memory adds wide read muxes. Check it.

3. **Re-run the NIST vectors on the new bitstream.** Simulation passing is
   necessary, not sufficient -- three real bugs on this project only appeared
   on hardware.

If area or timing is a problem, the fallback is one butterfly every TWO
cycles, which fits a dual-port BRAM (two reads one cycle, two writes the next)
and still gives ~2.9x on the NTT.
