`timescale 1ns/1ps
module tb_bm_pipe;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg start; reg [15:0] a0,a1,b0,b1,zeta;
  wire [15:0] r0,r1; wire done, busy;
  basemul dut(.clk(clk),.rst_n(rst_n),.start(start),
    .a0(a0),.a1(a1),.b0(b0),.b1(b1),.zeta(zeta),
    .r0(r0),.r1(r1),.done(done),.busy(busy));

  integer fd, i, errors, code, cyc, total, worst;
  reg [15:0] va0,va1,vb0,vb1,vz,er0,er1;

  initial begin
    errors=0; total=0; worst=0;
    fd = $fopen("bm_vec.hex","r");
    rst_n=0; start=0; repeat(5)@(posedge clk); rst_n=1; repeat(2)@(posedge clk);

    for (i=0;i<40;i=i+1) begin
      code = $fscanf(fd,"%h %h %h %h %h %h %h",va0,va1,vb0,vb1,vz,er0,er1);
      if (code != 7) i = 40;
      else begin
        @(negedge clk);
        a0=va0; a1=va1; b0=vb0; b1=vb1; zeta=vz; start=1'b1;
        @(negedge clk); start=1'b0;
        cyc=0;
        while(!done) begin @(posedge clk); cyc=cyc+1; end
        total = total + cyc;
        if (cyc > worst) worst = cyc;
        if (r0 !== er0 || r1 !== er1) begin
          if (errors<5) $display("[TB] FAIL vec %0d: got (%0d,%0d) want (%0d,%0d)",
                                 i, r0, r1, er0, er1);
          errors = errors+1;
        end
        @(posedge clk);
      end
    end
    $fclose(fd);
    $display("============================================================");
    $display("  basemul pipelined: %0d vectors", 40);
    $display("  cycles per basemul: avg %0d, worst %0d", total/40, worst);
    if (errors==0) $display("  PASS -- all results match the reference computation");
    else           $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #2_000_000; $display("TIMEOUT"); $finish; end
endmodule
