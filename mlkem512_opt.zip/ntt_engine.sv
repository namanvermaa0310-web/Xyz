// =============================================================================
// ntt_engine.sv -- FIPS 203 Algorithms 9 / 10, PIPELINED
// -----------------------------------------------------------------------------
// Same interface, same butterfly visiting order, same twiddles and same
// arithmetic as the original -- only the SCHEDULE changes.
//
// THE ORIGINAL
//   One butterfly at a time, 6 cycles each (READ, MUL, R1, R2, BFLY, WRITE),
//   plus 3 more for the N^-1 scaling on the last INTT stage:
//       896 butterflies x 6 = 5,376 cycles per transform.
//   Every stage of that sequence was busy for ONE cycle in six.
//
// THIS VERSION
//   The same six-step sequence becomes a real pipeline and a new butterfly is
//   issued EVERY cycle. Within one NTT stage the 128 butterflies touch
//   disjoint coefficient pairs, so they are fully independent and overlap
//   freely.
//
//   Between stages there IS a dependency -- stage s+1 reads coefficients that
//   stage s wrote -- so the pipeline is drained (DRAIN cycles) before the next
//   stage issues its first read. That costs DRAIN cycles x 7 stages, which is
//   small next to the 128 butterflies per stage it overlaps.
//
//       128 butterflies + DRAIN, x 7 stages  ~=  7 x (128 + 10)  ~= 966 cycles
//
// THE TIMING RULE IS PRESERVED
//   Every pipeline stage still contains AT MOST ONE multiply. That rule is what
//   took this module from WNS -17.6 ns to closure in Phase 1; pipelining keeps
//   it rather than trading it away. The N^-1 scaling runs through its own
//   three stages for every butterfly and is simply bypassed when not needed,
//   which gives UNIFORM latency and makes the drain count a constant.
//
// INTERFACE CONTRACT -- unchanged, because kpke_datapath depends on it:
//   * rd_data is a CONTINUOUS assign off coeff_mem[rd_addr] (no read latency)
//   * busy is high from start until the last write has committed
//   * done is LEVEL-HELD once idle after a completed transform -- callers
//     gate on busy, which is the rule this project adopted after seven
//     level-held-done bugs
// =============================================================================
module ntt_engine (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire        mode,        // 0 = NTT, 1 = INTT
  output wire        done,
  output wire        busy,
  input  wire [7:0]  wr_addr,
  input  wire [15:0] wr_data,
  input  wire        wr_en,
  input  wire [7:0]  rd_addr,
  output wire [15:0] rd_data
);
  import mlkem_pkg::*;

  // Pipeline depth from issue to write commit, plus margin. The drain between
  // stages must cover it so the next stage never reads a stale coefficient.
  localparam integer DRAIN = 10;

  // ---------------------------------------------------------------------------
  // Coefficient memory. Two reads (issue stage) and two writes (commit stage)
  // per cycle, plus the external write port while idle.
  // ---------------------------------------------------------------------------
  reg [15:0] coeff_mem [0:255];
  integer i;
  initial for (i = 0; i < 256; i = i + 1) coeff_mem[i] = 16'd0;

  assign rd_data = coeff_mem[rd_addr];

  // ---------------------------------------------------------------------------
  // Twiddle ROM
  // ---------------------------------------------------------------------------
  wire [6:0]  twiddle_addr;
  wire [15:0] twiddle_data;
  twiddle_rom u_twiddle_rom (.addr(twiddle_addr), .data(twiddle_data));

  // ---------------------------------------------------------------------------
  // Issue-side counters and control
  // ---------------------------------------------------------------------------
  localparam ST_IDLE  = 2'd0;
  localparam ST_ISSUE = 2'd1;
  localparam ST_DRAIN = 2'd2;
  localparam ST_FINAL = 2'd3;

  reg [1:0] state;
  reg [2:0] stage;
  reg [6:0] group;
  reg [7:0] offset;
  reg [3:0] drain_cnt;
  reg       was_last;

  assign busy = (state != ST_IDLE);
  assign done = (state == ST_IDLE) && was_last;

  // Stage tables -- copied verbatim from the original so the butterfly order
  // and twiddle selection are identical.
  wire [7:0] len;
  wire [6:0] num_groups;
  wire [6:0] intt_prev_groups;
  assign len = (mode == MODE_NTT) ?
    ((stage == 3'd0) ? 8'd128 : (stage == 3'd1) ? 8'd64  : (stage == 3'd2) ? 8'd32  :
     (stage == 3'd3) ? 8'd16  : (stage == 3'd4) ? 8'd8   : (stage == 3'd5) ? 8'd4   :
     (stage == 3'd6) ? 8'd2   : 8'd128) :
    ((stage == 3'd0) ? 8'd2   : (stage == 3'd1) ? 8'd4   : (stage == 3'd2) ? 8'd8   :
     (stage == 3'd3) ? 8'd16  : (stage == 3'd4) ? 8'd32  : (stage == 3'd5) ? 8'd64  :
     (stage == 3'd6) ? 8'd128 : 8'd2);

  assign num_groups = (mode == MODE_NTT) ?
    ((stage == 3'd0) ? 7'd1  : (stage == 3'd1) ? 7'd2  : (stage == 3'd2) ? 7'd4  :
     (stage == 3'd3) ? 7'd8  : (stage == 3'd4) ? 7'd16 : (stage == 3'd5) ? 7'd32 :
     (stage == 3'd6) ? 7'd64 : 7'd1) :
    ((stage == 3'd0) ? 7'd64 : (stage == 3'd1) ? 7'd32 : (stage == 3'd2) ? 7'd16 :
     (stage == 3'd3) ? 7'd8  : (stage == 3'd4) ? 7'd4  : (stage == 3'd5) ? 7'd2  :
     (stage == 3'd6) ? 7'd1  : 7'd64);

  assign intt_prev_groups = (mode == MODE_NTT) ? 7'd0 :
    ((stage == 3'd0) ? 7'd0   : (stage == 3'd1) ? 7'd64  : (stage == 3'd2) ? 7'd96  :
     (stage == 3'd3) ? 7'd112 : (stage == 3'd4) ? 7'd120 : (stage == 3'd5) ? 7'd124 :
     (stage == 3'd6) ? 7'd126 : 7'd0);

  wire last_offset = ({1'b0, offset} == (len - 8'd1));
  wire last_group  = (group == (num_groups - 7'd1));
  wire last_stage  = (stage == 3'd6);

  wire [15:0] start_addr_calc = {1'b0, group} * (len << 1);
  wire [7:0]  addr_a = start_addr_calc[7:0] + offset[7:0];
  wire [7:0]  addr_b = addr_a + len[7:0];

  assign twiddle_addr = mode ? (7'd127 - intt_prev_groups - group)
                             : ((7'd1 << stage) + {1'b0, group});

  wire issue = (state == ST_ISSUE);

  // ---------------------------------------------------------------------------
  // Pipeline registers. Each stage carries: valid, both write addresses, and
  // whether this butterfly needs the N^-1 scaling.
  // ---------------------------------------------------------------------------
  // P1 -- operands
  reg        v1, nn1;  reg [7:0] a1, b1;
  reg [15:0] da, db, z;
  // P2 -- multiply
  reg        v2, nn2;  reg [7:0] a2, b2;
  reg [31:0] prod;     reg [15:0] keep2;
  // P3 -- Barrett estimate
  reg        v3, nn3;  reg [7:0] a3, b3;
  reg [12:0] tval;     reg [23:0] hold;  reg [15:0] keep3;
  // P4 -- Barrett correct
  reg        v4, nn4;  reg [7:0] a4, b4;
  reg [15:0] t4, keep4;
  // P5 -- butterfly combine
  reg        v5, nn5;  reg [7:0] a5, b5;
  reg [15:0] oa5, ob5;
  // P6 -- N^-1 multiply
  reg        v6, nn6;  reg [7:0] a6, b6;
  reg [31:0] np_a, np_b; reg [15:0] oa6, ob6;
  // P7 -- N^-1 estimate
  reg        v7, nn7;  reg [7:0] a7, b7;
  reg [12:0] nt_a, nt_b; reg [23:0] nh_a, nh_b; reg [15:0] oa7, ob7;
  // P8 -- final values ready to write
  reg        v8;       reg [7:0] a8, b8;
  reg [15:0] wa8, wb8;

  // ---- P1 -> P2 combinational: pre-multiply adds (no multiplier) ----
  wire [16:0] sum_ab   = da + db;
  wire [15:0] sum_ab_q = (sum_ab >= 17'd3329) ? (sum_ab - 17'd3329) : sum_ab[15:0];
  wire signed [16:0] sub_ba = $signed({1'b0,db}) - $signed({1'b0,da});
  wire [15:0] sub_ba_q = sub_ba[16] ? (sub_ba[15:0] + 16'd3329) : sub_ba[15:0];
  wire [15:0] mul_in = mode ? sub_ba_q : db;
  wire [15:0] keep_a = mode ? sum_ab_q : da;

  // ---- P2 -> P3: Barrett estimate (one multiply) ----
  wire [38:0] bar_est = (prod[23:0] * 24'd20159) + 26'd33554432;

  // ---- P3 -> P4: Barrett correct (one multiply) ----
  wire [24:0] bar_diff = {1'b0, hold} - (tval * 25'd3329);
  wire [15:0] bar_out  = bar_diff[24] ? (bar_diff[15:0] + 16'd3329) :
                         (bar_diff >= 25'd3329) ? (bar_diff[15:0] - 16'd3329) :
                         bar_diff[15:0];

  // ---- P4 -> P5: butterfly combine (adds/subs only) ----
  wire [16:0] fin_sum = keep4 + t4;
  wire [15:0] ntt_a   = (fin_sum >= 17'd3329) ? (fin_sum - 17'd3329) : fin_sum[15:0];
  wire signed [16:0] fin_sub = $signed({1'b0,keep4}) - $signed({1'b0,t4});
  wire [15:0] ntt_b   = fin_sub[16] ? (fin_sub[15:0] + 16'd3329) : fin_sub[15:0];
  wire [15:0] pre_a   = mode ? keep4 : ntt_a;
  wire [15:0] pre_b   = mode ? t4    : ntt_b;

  // ---- P6 -> P7: N^-1 Barrett estimate ----
  wire [38:0] ne_a = (np_a[23:0] * 24'd20159) + 26'd33554432;
  wire [38:0] ne_b = (np_b[23:0] * 24'd20159) + 26'd33554432;

  // ---- P7 -> P8: N^-1 Barrett correct ----
  wire [24:0] nd_a  = {1'b0, nh_a} - (nt_a * 25'd3329);
  wire [15:0] no_a  = nd_a[24] ? (nd_a[15:0] + 16'd3329) :
                      (nd_a >= 25'd3329) ? (nd_a[15:0] - 16'd3329) : nd_a[15:0];
  wire [24:0] nd_b  = {1'b0, nh_b} - (nt_b * 25'd3329);
  wire [15:0] no_b  = nd_b[24] ? (nd_b[15:0] + 16'd3329) :
                      (nd_b >= 25'd3329) ? (nd_b[15:0] - 16'd3329) : nd_b[15:0];

  // ---------------------------------------------------------------------------
  // ONE always block for memory, counters and every pipeline register --
  // splitting drivers across blocks caused DRC MDRV-1 in an earlier phase.
  // ---------------------------------------------------------------------------
  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; stage <= 3'd0; group <= 7'd0; offset <= 8'd0;
      drain_cnt <= 4'd0; was_last <= 1'b0;
      v1 <= 1'b0; v2 <= 1'b0; v3 <= 1'b0; v4 <= 1'b0;
      v5 <= 1'b0; v6 <= 1'b0; v7 <= 1'b0; v8 <= 1'b0;
    end else begin
      // ---------------- memory ----------------
      if (v8) begin
        coeff_mem[a8] <= wa8;
        coeff_mem[b8] <= wb8;
      end else if (state == ST_IDLE && wr_en) begin
        coeff_mem[wr_addr] <= wr_data;
      end

      // ---------------- P1: operand fetch ----------------
      v1  <= issue;
      nn1 <= mode && last_stage;
      a1  <= addr_a;  b1 <= addr_b;
      da  <= coeff_mem[addr_a];
      db  <= coeff_mem[addr_b];
      z   <= twiddle_data;

      // ---------------- P2: multiply ----------------
      v2 <= v1; nn2 <= nn1; a2 <= a1; b2 <= b1;
      prod  <= z * mul_in;
      keep2 <= keep_a;

      // ---------------- P3: Barrett estimate ----------------
      v3 <= v2; nn3 <= nn2; a3 <= a2; b3 <= b2;
      tval  <= bar_est[38:26];
      hold  <= prod[23:0];
      keep3 <= keep2;

      // ---------------- P4: Barrett correct ----------------
      v4 <= v3; nn4 <= nn3; a4 <= a3; b4 <= b3;
      t4    <= bar_out;
      keep4 <= keep3;

      // ---------------- P5: butterfly combine ----------------
      v5 <= v4; nn5 <= nn4; a5 <= a4; b5 <= b4;
      oa5 <= pre_a;
      ob5 <= pre_b;

      // ---------------- P6: N^-1 multiply ----------------
      v6 <= v5; nn6 <= nn5; a6 <= a5; b6 <= b5;
      np_a <= oa5 * 16'd3303;
      np_b <= ob5 * 16'd3303;
      oa6  <= oa5; ob6 <= ob5;

      // ---------------- P7: N^-1 estimate ----------------
      v7 <= v6; nn7 <= nn6; a7 <= a6; b7 <= b6;
      nt_a <= ne_a[38:26]; nt_b <= ne_b[38:26];
      nh_a <= np_a[23:0];  nh_b <= np_b[23:0];
      oa7  <= oa6; ob7 <= ob6;

      // ---------------- P8: select scaled or unscaled ----------------
      v8  <= v7; a8 <= a7; b8 <= b7;
      wa8 <= nn7 ? no_a : oa7;
      wb8 <= nn7 ? no_b : ob7;

      // ---------------- issue control ----------------
      case (state)
        ST_IDLE: if (start) begin
          stage <= 3'd0; group <= 7'd0; offset <= 8'd0;
          was_last <= 1'b0;
          state <= ST_ISSUE;
        end

        ST_ISSUE: begin
          if (!last_offset) begin
            offset <= offset + 8'd1;
          end else begin
            offset <= 8'd0;
            if (!last_group) begin
              group <= group + 7'd1;
            end else begin
              // Last butterfly of this stage has just been issued.
              group <= 7'd0;
              drain_cnt <= 4'd0;
              if (last_stage) state <= ST_FINAL;
              else begin
                stage <= stage + 3'd1;
                state <= ST_DRAIN;
              end
            end
          end
        end

        // Wait for every write of this stage to commit before the next stage
        // reads anything -- the inter-stage dependency.
        ST_DRAIN: begin
          if (drain_cnt == DRAIN[3:0] - 4'd1) state <= ST_ISSUE;
          else drain_cnt <= drain_cnt + 4'd1;
        end

        ST_FINAL: begin
          if (drain_cnt == DRAIN[3:0] - 4'd1) begin
            was_last <= 1'b1;
            state    <= ST_IDLE;
          end else drain_cnt <= drain_cnt + 4'd1;
        end

        default: state <= ST_IDLE;
      endcase
    end
  end

endmodule : ntt_engine
