# ML-KEM-512 as AXI4-Lite IP

The UART bridge proved the design on the bench, but a bespoke serial protocol
is not something another engineer can drop into a block design.
`mlkem_axi_core.sv` exposes the identical engine behind AXI4-Lite so it can be
packaged as IP and driven by a MicroBlaze, a Zynq PS, or any AXI master.

**Same engine.** `mlkem_system` is instantiated unchanged, with the same 8 KB
two-read-port byte buffer, the same seed memory, the same cycle counter and
the same soft reset. Only the transport differs, so everything the NIST
vectors established about the UART path carries over.

## Register map (byte addresses, 32-bit access)

    0x0000  CTRL    W   [1:0] op   0=KeyGen 1=Encaps 2=Decaps
                        [2]   start (self-clearing)
                        [3]   soft reset
    0x0004  STATUS  R   [0] busy  [1] done (STICKY)  [2] reject  [3] err
    0x0008  CYCLES  R   cycle count of the last completed operation
    0x000C  ID      R   0x4D4B454D ("MKEM")
    0x1000  SEED    RW  16 words = the 64-byte seed memory (d)
    0x2000  MEM     RW  2048 words = the 8 KB byte buffer, little-endian

Byte-buffer offsets are unchanged from `mlkem_system`; add them to 0x2000:

    +0      ciphertext c (768)     +2048   ek (800)
    +1024   dk_pke (768)           +2900   H(ek) (32)
    +1868   m (32)                 +3100   z, then c for J(z||c)
    +1900   coins r (32)           +3900   shared secret K (32)

## STATUS[1] is sticky, and that matters

`sys_done` in `mlkem_system` is a ONE-CYCLE PULSE, so software polling a
register can never catch it. That is exactly what made a 473 us KeyGen look
like a hang over UART once the NTT was pipelined.

STATUS[1] here is a **latch**: set when the engine finishes, cleared when the
next operation starts or on soft reset. Poll it; it cannot be missed. `irq`
is also brought out for an interrupt controller.

## Driver sequence

    write CTRL  = 0x8            soft reset
    write SEED  = d              16 words
    write MEM+3100 = z           8 words
    write CTRL  = 0x4            op=0 (KeyGen), start
    poll  STATUS until bit 1     sticky done
    read  MEM+2048, 200 words    ek
    read  CYCLES                 latency in core clocks

Encaps and Decaps are identical but for the op field and which regions are
staged first -- see the byte map above.

## Bus arbitration

The host owns both memories while no operation is running. Once started, the
engine owns them for the whole operation and a write to MEM returns SLVERR
rather than corrupting state mid-run. This is the same `op_pending` /
`op_started` handshake that fixed a real race on the UART core: without it,
ownership could return to the host in the window between `start` dropping and
`busy` rising.

## Verification

    tb_mlkem_axi.sv -- an AXI4-Lite BFM stages the NIST ACVP keyGen vector
    through the bus, starts the engine, polls the sticky done bit and reads
    ek back over the bus:

        ID = 4d4b454d
        seed readback OK
        STATUS: done=1 busy=0 reject=0 err=0
        KeyGen over AXI4-Lite: 47367 cycles = 473 us @ 100 MHz
        PASS -- ek 800/800 bytes match the NIST ACVP vector

47,367 cycles against 47,319 measured on the KC705 over UART: the transport
adds nothing to the computation, as it should not.

## What this is NOT, stated plainly

Verified in simulation against a bus functional model. It has **not** been
exercised by a real AXI master on hardware -- the KC705 has no hard processor,
so that needs a MicroBlaze instantiated in a block design. The protocol
handling is deliberately simple (one outstanding transaction, no bursts), which
is correct for AXI4-Lite but means it has not been run against an aggressive
master that pipelines addresses.

Nor is it packaged as a Vivado IP yet (no `component.xml`). Package IP in the
IP Packager points at this module and needs no RTL change; the AXI signal names
follow the convention the packager infers from.

## A caution about area

The byte buffer keeps `ram_style = "block"`, but the pipelined `ntt_engine`
can no longer use BRAM for its coefficient memory (two reads AND two writes per
cycle), so the whole design's FF and LUT counts rose with the throughput work.
Check utilisation and WNS after adding this wrapper, and remember board margin
was thin.
