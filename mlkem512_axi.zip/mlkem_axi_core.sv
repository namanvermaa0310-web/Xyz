// =============================================================================
// mlkem_axi_core.sv -- ML-KEM-512 as an AXI4-Lite slave
// -----------------------------------------------------------------------------
// The UART bridge (mlkem_uart_core) proved the design on the bench, but a
// bespoke serial protocol is not something another engineer can drop into a
// block design. This exposes the identical engine behind AXI4-Lite so it can
// be packaged as IP and driven by a MicroBlaze, a Zynq PS, or any AXI master.
//
// SAME ENGINE. mlkem_system is instantiated unchanged, with the same 8 KB
// two-read-port byte buffer, the same seed memory, the same cycle counter and
// the same soft reset. Only the transport differs, so everything the NIST
// vectors established about the UART path holds here too.
//
// REGISTER MAP (byte addresses, 32-bit access)
//   0x0000  CTRL    W   [1:0] op, [2] start (self-clearing), [3] soft reset
//   0x0004  STATUS  R   [0] busy, [1] done, [2] reject, [3] sample_error
//   0x0008  CYCLES  R   cycle count of the last completed operation
//   0x000C  ID      R   0x4D4B454D ("MKEM"), for probing that the core is there
//   0x1000  SEED    RW  16 words = the 64-byte seed memory (d)
//   0x2000  MEM     RW  2048 words = the 8 KB byte buffer, little-endian
//
// The byte buffer map inside MEM is unchanged from mlkem_system:
//   0x2000 + 0      ciphertext c        0x2000 + 2048   ek
//   0x2000 + 1024   dk_pke              0x2000 + 2900   H(ek)
//   0x2000 + 1868   m                   0x2000 + 3900   shared secret K
// (add the byte offset to 0x2000; word address = 0x2000 + (byte_off & ~3))
//
// DONE IS A PULSE. mlkem_system asserts done for one cycle, so software that
// polls STATUS will never see it -- exactly the trap that made a 473 us
// KeyGen look like a hang over UART. STATUS[1] here is a STICKY latch: set
// when the engine finishes, cleared when the next operation starts or on
// soft reset. Poll it; it cannot be missed.
// =============================================================================
module mlkem_axi_core #(
  parameter integer K_PARAM   = 2,
  parameter integer ADDR_W    = 13,     // byte buffer: 8192 bytes
  parameter integer C_ADDR_W  = 16      // AXI address width
)(
  input  wire                   clk,
  input  wire                   rst_n,     // active low (AXI ARESETN)

  // ---- AXI4-Lite write address ----
  input  wire [C_ADDR_W-1:0]    s_awaddr,
  input  wire                   s_awvalid,
  output reg                    s_awready,
  // ---- AXI4-Lite write data ----
  input  wire [31:0]            s_wdata,
  input  wire [3:0]             s_wstrb,
  input  wire                   s_wvalid,
  output reg                    s_wready,
  // ---- AXI4-Lite write response ----
  output reg  [1:0]             s_bresp,
  output reg                    s_bvalid,
  input  wire                   s_bready,
  // ---- AXI4-Lite read address ----
  input  wire [C_ADDR_W-1:0]    s_araddr,
  input  wire                   s_arvalid,
  output reg                    s_arready,
  // ---- AXI4-Lite read data ----
  output reg  [31:0]            s_rdata,
  output reg  [1:0]             s_rresp,
  output reg                    s_rvalid,
  input  wire                   s_rready,

  // ---- status, for LEDs or an interrupt controller ----
  output wire                   irq,       // pulses when an operation finishes
  output wire                   o_busy,
  output wire                   o_reject
);

  localparam [31:0] CORE_ID = 32'h4D4B_454D;   // "MKEM"

  // Address decode: which region a transaction targets.
  localparam [2:0] RGN_REG  = 3'd0;
  localparam [2:0] RGN_SEED = 3'd1;
  localparam [2:0] RGN_MEM  = 3'd2;
  localparam [2:0] RGN_NONE = 3'd7;

  function automatic [2:0] region(input [C_ADDR_W-1:0] a);
    begin
      if      (a[15:12] == 4'h0) region = RGN_REG;
      else if (a[15:12] == 4'h1) region = RGN_SEED;
      else if (a[15:13] == 3'b001) region = RGN_MEM;   // 0x2000..0x3FFF
      else                        region = RGN_NONE;
    end
  endfunction

  // ---------------------------------------------------------------------------
  // Soft reset and the engine
  // ---------------------------------------------------------------------------
  reg  [3:0] soft_rst_cnt;
  wire       kem_rst_n = rst_n & ~(|soft_rst_cnt);

  reg  [1:0] sys_op;
  reg        sys_start;
  wire       sys_busy, sys_done, sys_reject, sys_err;

  wire [12:0] sys_rd_addr, sys_rd2_addr, sys_wr_addr;
  wire [7:0]  sys_wr_data;
  wire        sys_wr_en;
  reg  [7:0]  sys_rd_data, sys_rd2_data;
  wire [5:0]  d_rd_addr;
  reg  [7:0]  d_rd_data;
  wire [255:0] rho_unused;
  wire [4:0]   dbg_unused;

  mlkem_system #(.K_PARAM(K_PARAM), .ADDR_W(ADDR_W)) u_kem (
    .clk(clk), .rst_n(kem_rst_n),
    .op(sys_op), .start(sys_start), .busy(sys_busy), .done(sys_done),
    .d_rd_data(d_rd_data), .d_rd_addr(d_rd_addr),
    .byte_rd_addr(sys_rd_addr),  .byte_rd_data(sys_rd_data),
    .byte_rd2_addr(sys_rd2_addr), .byte_rd2_data(sys_rd2_data),
    .byte_wr_addr(sys_wr_addr), .byte_wr_data(sys_wr_data),
    .byte_wr_en(sys_wr_en),
    .rho_out(rho_unused), .sample_error(sys_err),
    .reject(sys_reject), .dbg_state(dbg_unused)
  );

  assign o_busy   = sys_busy;
  assign o_reject = sys_reject;

  // ---------------------------------------------------------------------------
  // Memories. The host owns them while no operation is running, exactly as in
  // the UART core -- the engine must not have the bus pulled out from under it
  // mid-operation, and the host must not read a half-written result.
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [7:0] byte_mem [0:(1<<ADDR_W)-1];
  reg [7:0] seed_mem [0:63];
  integer i;
  initial begin
    for (i = 0; i < (1<<ADDR_W); i = i + 1) byte_mem[i] = 8'h00;
    for (i = 0; i < 64; i = i + 1)          seed_mem[i] = 8'h00;
  end

  reg         host_owns;
  reg         op_pending, op_started;

  // Host-side access, driven by the AXI channels below.
  reg  [12:0] host_addr;
  reg  [7:0]  host_wdata;
  reg         host_we;
  reg  [5:0]  seed_addr;
  reg  [7:0]  seed_wdata;
  reg         seed_we;

  wire [12:0] bm_wr_addr = host_owns ? host_addr  : sys_wr_addr;
  wire [7:0]  bm_wr_data = host_owns ? host_wdata : sys_wr_data;
  wire        bm_wr_en   = host_owns ? host_we    : sys_wr_en;

  reg  [7:0]  host_rdata;          // registered read, byte buffer
  reg  [7:0]  seed_rdata;          // registered read, seed memory

  always @(posedge clk) begin
    if (bm_wr_en) byte_mem[bm_wr_addr] <= bm_wr_data;
    sys_rd_data  <= byte_mem[sys_rd_addr];
    sys_rd2_data <= byte_mem[sys_rd2_addr];
    host_rdata   <= byte_mem[host_addr];
    if (seed_we) seed_mem[seed_addr] <= seed_wdata;
    d_rd_data    <= seed_mem[d_rd_addr];
    seed_rdata   <= seed_mem[seed_addr];
  end

  // ---------------------------------------------------------------------------
  // Cycle counter and the STICKY done latch
  // ---------------------------------------------------------------------------
  reg [31:0] cyc_run, cyc_last;
  reg        busy_d;
  reg        done_sticky;

  assign irq = sys_done;

  // ---------------------------------------------------------------------------
  // AXI4-Lite. Kept deliberately simple: one outstanding transaction, no
  // bursts, no narrow-transfer trickery beyond wstrb on the register file.
  // A word write to MEM or SEED takes four cycles, one byte per cycle, because
  // both memories are byte-wide -- handled by the small sequencer below.
  // ---------------------------------------------------------------------------
  localparam [2:0] W_IDLE = 3'd0, W_DATA = 3'd1, W_EXEC = 3'd2, W_RESP = 3'd3;
  // Reads need TWO cycles after R_EXEC drives the address register: one for
// that register to update, one for the memory's own registered output. A
// single wait state latched the PREVIOUS byte and shifted the whole word.
localparam [2:0] R_IDLE = 3'd0, R_EXEC = 3'd1, R_WAIT = 3'd2,
                 R_LATCH = 3'd3, R_RESP = 3'd4;

  reg [2:0]  wstate, rstate;
  reg [C_ADDR_W-1:0] waddr_r, raddr_r;
  reg [31:0] wdata_r, rdata_acc;
  reg [3:0]  wstrb_r;
  reg [1:0]  bcnt;                 // which byte of a word is being moved
  reg [2:0]  wrgn, rrgn;

  always @(posedge clk) begin
    if (!rst_n) begin
      s_awready <= 1'b0; s_wready <= 1'b0; s_bvalid <= 1'b0; s_bresp <= 2'b00;
      s_arready <= 1'b0; s_rvalid <= 1'b0; s_rresp <= 2'b00; s_rdata <= 32'd0;
      wstate <= W_IDLE; rstate <= R_IDLE; bcnt <= 2'd0;
      sys_op <= 2'd0; sys_start <= 1'b0;
      host_owns <= 1'b1; op_pending <= 1'b0; op_started <= 1'b0;
      soft_rst_cnt <= 4'd0;
      cyc_run <= 32'd0; cyc_last <= 32'd0; busy_d <= 1'b0; done_sticky <= 1'b0;
      host_we <= 1'b0; seed_we <= 1'b0; host_addr <= 13'd0; seed_addr <= 6'd0;
    end else begin
      sys_start <= 1'b0;
      host_we   <= 1'b0;
      seed_we   <= 1'b0;
      if (|soft_rst_cnt) soft_rst_cnt <= soft_rst_cnt - 4'd1;

      // ---- cycle counter ----
      busy_d <= sys_busy;
      if (sys_busy && !busy_d)      cyc_run  <= 32'd1;
      else if (sys_busy)            cyc_run  <= cyc_run + 32'd1;
      else if (!sys_busy && busy_d) cyc_last <= cyc_run;

      // ---- sticky done ----
      if (sys_done) done_sticky <= 1'b1;

      // ---- bus arbitration: hand the memory over for the whole operation ----
      if (op_pending && !op_started) begin
        host_owns  <= 1'b0;
        sys_start  <= 1'b1;
        op_started <= 1'b1;
      end else if (op_started && sys_busy) begin
        op_pending <= 1'b0;
      end else if (op_started && !sys_busy && !op_pending) begin
        host_owns  <= 1'b1;
        op_started <= 1'b0;
      end

      // ======================= WRITE CHANNEL =======================
      case (wstate)
        W_IDLE: begin
          s_bvalid <= 1'b0;
          if (s_awvalid) begin
            waddr_r   <= s_awaddr;
            wrgn      <= region(s_awaddr);
            s_awready <= 1'b1;
            s_wready  <= 1'b1;
            wstate    <= W_DATA;
          end
        end

        W_DATA: begin
          s_awready <= 1'b0;
          if (s_wvalid) begin
            wdata_r  <= s_wdata;
            wstrb_r  <= s_wstrb;
            s_wready <= 1'b0;
            bcnt     <= 2'd0;
            wstate   <= W_EXEC;
          end
        end

        W_EXEC: begin
          s_bresp <= 2'b00;
          case (wrgn)
            RGN_REG: begin
              if (waddr_r[11:0] == 12'h000) begin        // CTRL
                if (wdata_r[3]) begin                    // soft reset
                  soft_rst_cnt <= 4'd8;
                  op_pending <= 1'b0; op_started <= 1'b0;
                  host_owns  <= 1'b1; done_sticky <= 1'b0;
                end
                if (wdata_r[2] && !sys_busy && !op_pending) begin
                  sys_op      <= wdata_r[1:0];
                  op_pending  <= 1'b1;
                  done_sticky <= 1'b0;                   // clear on start
                end
              end else begin
                s_bresp <= 2'b10;                        // SLVERR: read-only
              end
              wstate <= W_RESP;
            end

            // Byte-wide memories: move one byte per cycle, honouring wstrb.
            RGN_SEED, RGN_MEM: begin
              if (wrgn == RGN_SEED) begin
                seed_addr  <= {waddr_r[5:2], bcnt};
                seed_wdata <= wdata_r[bcnt*8 +: 8];
                seed_we    <= wstrb_r[bcnt];
              end else begin
                host_addr  <= {waddr_r[12:2], bcnt};
                host_wdata <= wdata_r[bcnt*8 +: 8];
                host_we    <= wstrb_r[bcnt] & host_owns;
                if (!host_owns) s_bresp <= 2'b10;        // engine owns the bus
              end
              if (bcnt == 2'd3) wstate <= W_RESP;
              bcnt <= bcnt + 2'd1;
            end

            default: begin s_bresp <= 2'b10; wstate <= W_RESP; end
          endcase
        end

        W_RESP: begin
          s_bvalid <= 1'b1;
          if (s_bvalid && s_bready) begin
            s_bvalid <= 1'b0;
            wstate   <= W_IDLE;
          end
        end

        default: wstate <= W_IDLE;
      endcase

      // ======================= READ CHANNEL =======================
      case (rstate)
        R_IDLE: begin
          s_rvalid <= 1'b0;
          if (s_arvalid) begin
            raddr_r   <= s_araddr;
            rrgn      <= region(s_araddr);
            s_arready <= 1'b1;
            bcnt      <= 2'd0;
            rdata_acc <= 32'd0;
            rstate    <= R_EXEC;
          end
        end

        R_EXEC: begin
          s_arready <= 1'b0;
          s_rresp   <= 2'b00;
          case (rrgn)
            RGN_REG: begin
              case (raddr_r[11:0])
                12'h000: s_rdata <= {28'd0, 1'b0, sys_start, sys_op};
                12'h004: s_rdata <= {28'd0, sys_err, sys_reject,
                                     done_sticky, sys_busy};
                12'h008: s_rdata <= cyc_last;
                12'h00C: s_rdata <= CORE_ID;
                default: begin s_rdata <= 32'd0; s_rresp <= 2'b10; end
              endcase
              rstate <= R_RESP;
            end

            // Byte-wide: present an address, wait one cycle for the
            // registered memory output, then latch it. Four times per word.
            RGN_SEED, RGN_MEM: begin
              host_addr <= {raddr_r[12:2], bcnt};
              seed_addr <= {raddr_r[5:2], bcnt};
              rstate    <= R_WAIT;
            end

            default: begin s_rdata <= 32'd0; s_rresp <= 2'b10;
                           rstate <= R_RESP; end
          endcase
        end

        // Address register has just updated; the memory samples it this
        // cycle and presents data the next one.
        R_WAIT: rstate <= R_LATCH;

        // Data is valid now. Assemble the word a byte at a time; on the
        // fourth, hand the whole thing to s_rdata.
        R_LATCH: begin
          if (bcnt == 2'd3) begin
            s_rdata <= {(rrgn == RGN_SEED) ? seed_rdata : host_rdata,
                        rdata_acc[23:0]};
            rstate  <= R_RESP;
          end else begin
            rdata_acc[bcnt*8 +: 8] <= (rrgn == RGN_SEED) ? seed_rdata
                                                         : host_rdata;
            bcnt   <= bcnt + 2'd1;
            rstate <= R_EXEC;
          end
        end

        R_RESP: begin
          s_rvalid <= 1'b1;
          if (s_rvalid && s_rready) begin
            s_rvalid <= 1'b0;
            rstate   <= R_IDLE;
          end
        end

        default: rstate <= R_IDLE;
      endcase
    end
  end

endmodule : mlkem_axi_core
