`timescale 1ns/1ps
// =============================================================================
// tb_mlkem_axi.sv -- drive the AXI4-Lite wrapper the way a real master would,
// and check the result against the same NIST ACVP keyGen vector that
// validated the UART path. If this passes, the two transports are equivalent.
// =============================================================================
module tb_mlkem_axi;
  reg clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  reg  [15:0] awaddr, araddr;  reg awvalid, arvalid;
  reg  [31:0] wdata;           reg [3:0] wstrb;
  reg         wvalid, bready, rready;
  wire awready, wready, bvalid, arready, rvalid, irq, o_busy, o_reject;
  wire [1:0]  bresp, rresp;
  wire [31:0] rdata;

  mlkem_axi_core dut (
    .clk(clk), .rst_n(rst_n),
    .s_awaddr(awaddr), .s_awvalid(awvalid), .s_awready(awready),
    .s_wdata(wdata), .s_wstrb(wstrb), .s_wvalid(wvalid), .s_wready(wready),
    .s_bresp(bresp), .s_bvalid(bvalid), .s_bready(bready),
    .s_araddr(araddr), .s_arvalid(arvalid), .s_arready(arready),
    .s_rdata(rdata), .s_rresp(rresp), .s_rvalid(rvalid), .s_rready(rready),
    .irq(irq), .o_busy(o_busy), .o_reject(o_reject)
  );

  localparam [15:0] REG_CTRL = 16'h0000, REG_STAT = 16'h0004;
  localparam [15:0] REG_CYC  = 16'h0008, REG_ID   = 16'h000C;
  localparam [15:0] SEED_BASE = 16'h1000, MEM_BASE = 16'h2000;

  reg [31:0] rd_val;
  reg [7:0]  d_v [0:63];
  reg [7:0]  z_v [0:31];
  reg [7:0]  ek_g [0:799];
  reg [7:0]  got  [0:799];
  integer i, e, guard;

  task axi_write(input [15:0] a, input [31:0] d);
    begin
      @(negedge clk); awaddr = a; awvalid = 1'b1;
      while (!awready) @(negedge clk);
      @(negedge clk); awvalid = 1'b0;
      wdata = d; wstrb = 4'hF; wvalid = 1'b1;
      while (!wready) @(negedge clk);
      @(negedge clk); wvalid = 1'b0; bready = 1'b1;
      while (!bvalid) @(negedge clk);
      @(negedge clk); bready = 1'b0;
    end
  endtask

  task axi_read(input [15:0] a);
    begin
      @(negedge clk); araddr = a; arvalid = 1'b1;
      while (!arready) @(negedge clk);
      @(negedge clk); arvalid = 1'b0; rready = 1'b1;
      while (!rvalid) @(negedge clk);
      rd_val = rdata;
      @(negedge clk); rready = 1'b0;
    end
  endtask

  initial begin
    $readmemh("nv_d.hex",  d_v);
    $readmemh("nv_z.hex",  z_v);
    $readmemh("nv_ek.hex", ek_g);

    awvalid=0; wvalid=0; bready=0; arvalid=0; rready=0;
    wstrb=4'hF; awaddr=0; araddr=0; wdata=0;
    repeat (8) @(posedge clk); rst_n = 1; repeat (4) @(posedge clk);

    // ---- 1. probe that the core is present ----
    axi_read(REG_ID);
    $display("[TB] ID = %08h (expect 4D4B454D)", rd_val);
    if (rd_val !== 32'h4D4B454D) begin
      $display("  FAIL -- core did not identify itself"); $finish;
    end

    // ---- 2. soft reset ----
    axi_write(REG_CTRL, 32'h0000_0008);
    repeat (24) @(posedge clk);

    // ---- 3. stage d into SEED, z at byte offset 3100 in MEM ----
    for (i = 0; i < 32; i = i + 4)
      axi_write(SEED_BASE + i[15:0], {d_v[i+3],d_v[i+2],d_v[i+1],d_v[i+0]});
    for (i = 0; i < 32; i = i + 4)
      axi_write(MEM_BASE + 16'd3100 + i[15:0],
                {z_v[i+3],z_v[i+2],z_v[i+1],z_v[i+0]});

    // ---- 4. read back, proving the AXI read path works ----
    axi_read(SEED_BASE);
    if (rd_val !== {d_v[3],d_v[2],d_v[1],d_v[0]}) begin
      $display("[TB] seed readback %08h, expected %02h%02h%02h%02h",
               rd_val, d_v[3],d_v[2],d_v[1],d_v[0]);
      $display("  FAIL -- AXI read path"); $finish;
    end
    $display("[TB] seed readback OK");

    // ---- 5. start KeyGen: op=0 in [1:0], start = bit 2 ----
    axi_write(REG_CTRL, 32'h0000_0004);

    // ---- 6. poll the STICKY done bit, exactly as software would ----
    guard = 0; rd_val = 0;
    while (rd_val[1] !== 1'b1 && guard < 40000) begin
      axi_read(REG_STAT);
      guard = guard + 1;
    end
    if (rd_val[1] !== 1'b1) begin
      $display("  FAIL -- done never set (busy=%0d)", rd_val[0]); $finish;
    end
    $display("[TB] STATUS: done=1 busy=%0d reject=%0d err=%0d",
             rd_val[0], rd_val[2], rd_val[3]);

    // ---- 7. read ek back over AXI and compare with NIST ----
    for (i = 0; i < 800; i = i + 4) begin
      axi_read(MEM_BASE + 16'd2048 + i[15:0]);
      got[i+0] = rd_val[7:0];   got[i+1] = rd_val[15:8];
      got[i+2] = rd_val[23:16]; got[i+3] = rd_val[31:24];
    end
    e = 0;
    for (i = 0; i < 800; i = i + 1)
      if (got[i] !== ek_g[i]) begin
        if (e < 4) $display("[TB] ek[%0d] got %02h want %02h",
                            i, got[i], ek_g[i]);
        e = e + 1;
      end

    axi_read(REG_CYC);
    $display("============================================================");
    $display("[TB] KeyGen over AXI4-Lite: %0d cycles = %0d us @ 100 MHz",
             rd_val, rd_val/100);
    if (e == 0)
      $display("  PASS -- ek 800/800 bytes match the NIST ACVP vector");
    else
      $display("  FAIL -- %0d byte(s) differ", e);
    $display("============================================================");
    $finish;
  end

  initial begin #600_000_000; $display("TIMEOUT"); $finish; end
endmodule
