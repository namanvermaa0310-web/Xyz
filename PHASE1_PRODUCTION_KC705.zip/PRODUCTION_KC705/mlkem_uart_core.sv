// =============================================================================
// mlkem_uart_core.sv -- UART command bridge for the ML-KEM NTT engine
// -----------------------------------------------------------------------------
// This is the board-INDEPENDENT half of the design: plain single-ended clock,
// plain reset, one UART RX pin and one UART TX pin. Everything KC705-specific
// (differential clock buffer, MMCM, pin names) lives in kc705_mlkem_top.sv.
// Splitting it this way means this module -- where all the real logic is --
// can be fully simulated in Icarus, which the board wrapper cannot be
// (it instantiates Xilinx UNISIM primitives).
//
// COMMAND PROTOCOL (host -> FPGA), all bytes, LSB-first 8N1:
//
//   0xA5                          PING          -> replies 0x5A
//   0x01 <addr> <d_lo> <d_hi>     WRITE COEFF   -> replies 0x01 (ack)
//   0x02                          START NTT     -> replies 0x02 (ack)
//   0x03                          START INTT    -> replies 0x03 (ack)
//   0x04 <addr>                   READ COEFF    -> replies <d_lo> <d_hi>
//   0x05                          STATUS        -> replies {6'b0, done, busy}
//
// Coefficients are 16-bit little-endian (low byte first), matching the
// golden .hex convention used by the Phase 1/3 testbenches.
//
// Typical host sequence to run a forward NTT:
//   1. PING to confirm the link
//   2. 256x WRITE COEFF (addr 0..255)
//   3. START NTT
//   4. poll STATUS until busy=0 and done=1   (NTT takes 2688 clocks)
//   5. 256x READ COEFF
// =============================================================================
module mlkem_uart_core #(
  parameter integer CLKS_PER_BIT = 868   // 100 MHz / 115200 baud
)(
  input  wire clk,
  input  wire rst_n,
  input  wire uart_rx_i,
  output wire uart_tx_o
);

  // ---------------------------------------------------------------------------
  // UART physical layer
  // ---------------------------------------------------------------------------
  wire [7:0] rx_data;
  wire       rx_valid;

  uart_rx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_rx (
    .clk(clk), .rst_n(rst_n), .rx(uart_rx_i),
    .data(rx_data), .valid(rx_valid)
  );

  reg        tx_send;
  reg  [7:0] tx_data;
  wire       tx_busy;

  uart_tx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_tx (
    .clk(clk), .rst_n(rst_n), .send(tx_send), .data(tx_data),
    .tx(uart_tx_o), .busy(tx_busy)
  );

  // ---------------------------------------------------------------------------
  // NTT engine under test
  // ---------------------------------------------------------------------------
  reg         ntt_start;
  reg         ntt_mode;
  reg  [7:0]  ntt_wr_addr;
  reg  [15:0] ntt_wr_data;
  reg         ntt_wr_en;
  reg  [7:0]  ntt_rd_addr;
  wire [15:0] ntt_rd_data;
  wire        ntt_busy, ntt_done;

  ntt_engine u_ntt (
    .clk(clk), .rst_n(rst_n),
    .start(ntt_start), .mode(ntt_mode),
    .done(ntt_done), .busy(ntt_busy),
    .wr_addr(ntt_wr_addr), .wr_data(ntt_wr_data), .wr_en(ntt_wr_en),
    .rd_addr(ntt_rd_addr), .rd_data(ntt_rd_data)
  );

  // ---------------------------------------------------------------------------
  // Command FSM
  // ---------------------------------------------------------------------------
  localparam [7:0] CMD_WRITE  = 8'h01;
  localparam [7:0] CMD_NTT    = 8'h02;
  localparam [7:0] CMD_INTT   = 8'h03;
  localparam [7:0] CMD_READ   = 8'h04;
  localparam [7:0] CMD_STATUS = 8'h05;
  localparam [7:0] CMD_PING   = 8'hA5;
  localparam [7:0] PING_REPLY = 8'h5A;

  localparam ST_CMD      = 4'd0;   // waiting for a command byte
  localparam ST_W_ADDR   = 4'd1;   // WRITE: collecting addr
  localparam ST_W_LO     = 4'd2;   // WRITE: collecting data low byte
  localparam ST_W_HI     = 4'd3;   // WRITE: collecting data high byte, commit
  localparam ST_R_ADDR   = 4'd4;   // READ: collecting addr
  localparam ST_R_WAIT   = 4'd5;   // READ: one cycle for rd_data to settle
  localparam ST_R_LO     = 4'd6;   // READ: send low byte
  localparam ST_R_HI     = 4'd7;   // READ: send high byte
  localparam ST_REPLY    = 4'd8;   // send a single queued reply byte
  localparam ST_TX_WAIT  = 4'd9;   // wait for tx to accept / finish

  reg [3:0] state;
  reg [3:0] next_after_tx;
  reg [7:0] addr_reg;
  reg [7:0] lo_reg;
  reg [7:0] pending_tx;

  // Latch the read value so the UART byte pair is coherent even if a
  // concurrent NTT run were to alter memory between the two bytes.
  reg [15:0] rd_latch;

  always @(posedge clk) begin
    if (!rst_n) begin
      state       <= ST_CMD;
      next_after_tx <= ST_CMD;
      tx_send     <= 1'b0;
      tx_data     <= 8'd0;
      addr_reg    <= 8'd0;
      lo_reg      <= 8'd0;
      pending_tx  <= 8'd0;
      rd_latch    <= 16'd0;
      ntt_start   <= 1'b0;
      ntt_mode    <= 1'b0;
      ntt_wr_addr <= 8'd0;
      ntt_wr_data <= 16'd0;
      ntt_wr_en   <= 1'b0;
      ntt_rd_addr <= 8'd0;
    end else begin
      // single-cycle pulses
      tx_send   <= 1'b0;
      ntt_wr_en <= 1'b0;
      ntt_start <= 1'b0;

      case (state)
        // -------------------------------------------------------------------
        ST_CMD: begin
          if (rx_valid) begin
            case (rx_data)
              CMD_WRITE: state <= ST_W_ADDR;
              CMD_READ:  state <= ST_R_ADDR;

              CMD_NTT: begin
                ntt_mode  <= 1'b0;
                ntt_start <= 1'b1;
                pending_tx <= CMD_NTT;
                state <= ST_REPLY;
              end

              CMD_INTT: begin
                ntt_mode  <= 1'b1;
                ntt_start <= 1'b1;
                pending_tx <= CMD_INTT;
                state <= ST_REPLY;
              end

              CMD_STATUS: begin
                pending_tx <= {6'd0, ntt_done, ntt_busy};
                state <= ST_REPLY;
              end

              CMD_PING: begin
                pending_tx <= PING_REPLY;
                state <= ST_REPLY;
              end

              default: state <= ST_CMD;   // unknown byte: ignore, resync
            endcase
          end
        end

        // ---- WRITE COEFF --------------------------------------------------
        ST_W_ADDR: if (rx_valid) begin addr_reg <= rx_data; state <= ST_W_LO; end
        ST_W_LO:   if (rx_valid) begin lo_reg   <= rx_data; state <= ST_W_HI; end
        ST_W_HI: if (rx_valid) begin
          ntt_wr_addr <= addr_reg;
          ntt_wr_data <= {rx_data, lo_reg};   // little-endian: {hi, lo}
          ntt_wr_en   <= 1'b1;
          pending_tx  <= CMD_WRITE;
          state <= ST_REPLY;
        end

        // ---- READ COEFF ---------------------------------------------------
        ST_R_ADDR: if (rx_valid) begin
          ntt_rd_addr <= rx_data;
          state <= ST_R_WAIT;
        end
        ST_R_WAIT: begin
          rd_latch <= ntt_rd_data;            // rd_data is combinational
          state <= ST_R_LO;
        end
        ST_R_LO: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[7:0];
          tx_send <= 1'b1;
          next_after_tx <= ST_R_HI;
          state <= ST_TX_WAIT;
        end
        ST_R_HI: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[15:8];
          tx_send <= 1'b1;
          next_after_tx <= ST_CMD;
          state <= ST_TX_WAIT;
        end

        // ---- single-byte reply --------------------------------------------
        ST_REPLY: if (!tx_busy && !tx_send) begin
          tx_data <= pending_tx;
          tx_send <= 1'b1;
          next_after_tx <= ST_CMD;
          state <= ST_TX_WAIT;
        end

        // ---- wait for the transmitter to finish this byte -----------------
        ST_TX_WAIT: begin
          // tx_busy rises the cycle after tx_send; wait for it to fall again
          if (tx_busy) state <= ST_TX_WAIT;
          else if (!tx_send) state <= next_after_tx;
        end

        default: state <= ST_CMD;
      endcase
    end
  end
endmodule : mlkem_uart_core
