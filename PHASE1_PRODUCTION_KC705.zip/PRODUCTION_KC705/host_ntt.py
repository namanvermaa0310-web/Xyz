#!/usr/bin/env python3
"""
host_ntt.py -- host-side driver for the KC705 ML-KEM NTT accelerator.

Talks the byte protocol implemented in mlkem_uart_core.sv over the KC705's
USB-UART bridge, loads a polynomial, runs the hardware NTT, reads the result
back, and checks it against the FIPS 203 reference computed in Python.

This is the bench test that actually proves the FPGA is doing the right
math -- the Icarus testbench proves the RTL is right, this proves the
silicon is.

Usage:
    pip install pyserial
    python3 host_ntt.py /dev/ttyUSB0          # Linux
    python3 host_ntt.py COM3                  # Windows

The KC705 typically enumerates as /dev/ttyUSB0 (Linux) or a COM port
(Windows). If there are two ports, the UART is usually the second one --
the first is the JTAG interface.
"""

import sys
import time

try:
    import serial
except ImportError:
    sys.exit("pyserial not installed.  Run:  pip install pyserial")

BAUD = 115200
Q = 3329

CMD_WRITE  = 0x01
CMD_NTT    = 0x02
CMD_INTT   = 0x03
CMD_READ   = 0x04
CMD_STATUS = 0x05
CMD_PING   = 0xA5
PING_REPLY = 0x5A


# -----------------------------------------------------------------------------
# FIPS 203 reference model (same code as gen_golden.py -- kept here so this
# script is self-contained on the bench machine)
# -----------------------------------------------------------------------------
def br7(i):
    return int(f"{i:07b}"[::-1], 2)


ZETAS = [pow(17, br7(i), Q) for i in range(128)]


def ref_ntt(f):
    """FIPS 203 Algorithm 9."""
    f = list(f)
    i = 1
    length = 128
    while length >= 2:
        for start in range(0, 256, 2 * length):
            z = ZETAS[i]
            i += 1
            for j in range(start, start + length):
                t = (z * f[j + length]) % Q
                f[j + length] = (f[j] - t) % Q
                f[j] = (f[j] + t) % Q
        length //= 2
    return f


# -----------------------------------------------------------------------------
# Protocol helpers
# -----------------------------------------------------------------------------
class Accel:
    def __init__(self, port):
        self.ser = serial.Serial(port, BAUD, timeout=2.0)
        time.sleep(0.1)
        self.ser.reset_input_buffer()

    def _expect(self, want, what):
        got = self.ser.read(1)
        if not got:
            raise TimeoutError(f"{what}: no reply (timeout)")
        if got[0] != want:
            raise ValueError(f"{what}: got 0x{got[0]:02X}, expected 0x{want:02X}")

    def ping(self):
        self.ser.write(bytes([CMD_PING]))
        self._expect(PING_REPLY, "PING")

    def write_coeff(self, addr, value):
        assert 0 <= addr < 256
        assert 0 <= value < 65536
        self.ser.write(bytes([CMD_WRITE, addr, value & 0xFF, (value >> 8) & 0xFF]))
        self._expect(CMD_WRITE, f"WRITE[{addr}]")

    def read_coeff(self, addr):
        self.ser.write(bytes([CMD_READ, addr]))
        b = self.ser.read(2)
        if len(b) != 2:
            raise TimeoutError(f"READ[{addr}]: short reply")
        return b[0] | (b[1] << 8)

    def status(self):
        self.ser.write(bytes([CMD_STATUS]))
        b = self.ser.read(1)
        if not b:
            raise TimeoutError("STATUS: no reply")
        return {"busy": bool(b[0] & 0x01), "done": bool(b[0] & 0x02)}

    def start_ntt(self, inverse=False):
        cmd = CMD_INTT if inverse else CMD_NTT
        self.ser.write(bytes([cmd]))
        self._expect(cmd, "START")

    def wait_done(self, timeout_s=5.0):
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            st = self.status()
            if not st["busy"] and st["done"]:
                return
        raise TimeoutError("engine never reported done")


# -----------------------------------------------------------------------------
def main():
    if len(sys.argv) != 2:
        sys.exit(f"usage: {sys.argv[0]} <serial-port>")
    port = sys.argv[1]

    print(f"Opening {port} at {BAUD} baud...")
    acc = Accel(port)

    print("PING...", end=" ", flush=True)
    acc.ping()
    print("ok, link alive")

    st = acc.status()
    print(f"STATUS: busy={st['busy']} done={st['done']}")

    # A deterministic, non-trivial test polynomial. Using a fixed pattern
    # rather than random input means a failure is reproducible on the bench.
    poly = [(i * 7 + 13) % Q for i in range(256)]

    print("Loading 256 coefficients...", end=" ", flush=True)
    for i, v in enumerate(poly):
        acc.write_coeff(i, v)
    print("done")

    # Read back before transforming, to separate "UART/memory is broken"
    # from "the NTT math is broken" if something fails.
    print("Verifying load (read-back before NTT)...", end=" ", flush=True)
    loopback_errs = 0
    for i, v in enumerate(poly):
        got = acc.read_coeff(i)
        if got != v:
            if loopback_errs < 5:
                print(f"\n  load mismatch at {i}: got {got}, wrote {v}")
            loopback_errs += 1
    if loopback_errs:
        print(f"\nFAIL: {loopback_errs} load errors -- UART or memory path is broken.")
        print("The NTT result below is meaningless until this is fixed.")
        return 1
    print("ok, 256/256")

    print("Running forward NTT on hardware...", end=" ", flush=True)
    t0 = time.time()
    acc.start_ntt(inverse=False)
    acc.wait_done()
    elapsed = time.time() - t0
    print(f"done ({elapsed*1000:.1f} ms wall clock, incl. UART polling)")

    print("Reading result and comparing to FIPS 203 reference...", end=" ", flush=True)
    expected = ref_ntt(poly)
    errs = 0
    for i in range(256):
        got = acc.read_coeff(i)
        if got != expected[i]:
            if errs < 10:
                print(f"\n  s_hat[{i}]: got {got}, expected {expected[i]}")
            errs += 1

    if errs == 0:
        print("ok")
        print()
        print("=" * 60)
        print("  PASS -- hardware NTT matches FIPS 203 Algorithm 9")
        print("  256/256 coefficients correct on real silicon")
        print("=" * 60)
        return 0
    else:
        print()
        print("=" * 60)
        print(f"  FAIL -- {errs}/256 coefficients wrong")
        print("=" * 60)
        print("The load read-back passed, so the UART path is fine and the")
        print("fault is in the NTT datapath itself. Check the post-")
        print("implementation timing report first: a negative WNS on the")
        print("butterfly path produces exactly this signature (correct data")
        print("in, wrong data out, simulation passing).")
        return 1


if __name__ == "__main__":
    sys.exit(main())
