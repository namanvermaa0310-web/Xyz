`timescale 1ns/1ps
// =============================================================================
// tb_mlkem_uart_core.sv -- end-to-end board-path test
// -----------------------------------------------------------------------------
// Drives ACTUAL serial waveforms into uart_rx_i and decodes ACTUAL serial
// waveforms out of uart_tx_o -- no backdoor pokes into internal memory.
// This exercises exactly the path the KC705 will use over USB-UART.
//
// Sequence (mirrors what the host Python script will do):
//   1. PING                       -> expect 0x5A
//   2. STATUS                     -> expect busy=0
//   3. 256x WRITE COEFF with s    (from golden_s.hex)
//   4. START NTT                  -> ack 0x02
//   5. poll STATUS until done
//   6. 256x READ COEFF            -> compare against golden_shat.hex
//
// golden_s.hex / golden_shat.hex are the same FIPS 203 reference vectors
// already used by the Phase 3 testbench, so a pass here means the UART
// bridge preserves the verified NTT result bit-for-bit.
// =============================================================================
module tb_mlkem_uart_core;

  localparam integer CPB = 16;   // short bit period so the sim runs fast

  reg clk = 0, rst_n = 0;
  reg  host_tx = 1'b1;           // host -> FPGA line
  wire fpga_tx;                  // FPGA -> host line

  mlkem_uart_core #(.CLKS_PER_BIT(CPB)) dut (
    .clk(clk), .rst_n(rst_n),
    .uart_rx_i(host_tx),
    .uart_tx_o(fpga_tx)
  );

  always #5 clk = ~clk;

  reg [15:0] golden_s    [0:255];
  reg [15:0] golden_shat [0:255];

  integer errors = 0;
  integer k;
  reg [7:0]  got;
  reg [15:0] got16;

  // ---------------------------------------------------------------------------
  // Host-side UART transmit: bit-bang a byte onto host_tx
  // ---------------------------------------------------------------------------
  task host_send(input [7:0] b);
    integer i;
    begin
      host_tx = 1'b0;                                  // start bit
      repeat (CPB) @(posedge clk);
      for (i = 0; i < 8; i = i + 1) begin              // LSB first
        host_tx = b[i];
        repeat (CPB) @(posedge clk);
      end
      host_tx = 1'b1;                                  // stop bit
      repeat (CPB) @(posedge clk);
    end
  endtask

  // ---------------------------------------------------------------------------
  // Host-side UART receive -- runs as a BACKGROUND monitor.
  // This must be free-running, not called on demand: the FPGA begins its
  // reply roughly half a bit-time before host_send() returns (uart_rx flags
  // valid at the middle of the stop bit), so an on-demand receiver would
  // arm too late and miss the start bit.
  // ---------------------------------------------------------------------------
  reg [7:0] rxq [0:4095];
  integer rxq_wr = 0;
  integer rxq_rd = 0;

  initial begin : uart_monitor
    reg [7:0] b;
    integer i;
    forever begin
      @(negedge fpga_tx);                            // start bit
      repeat (CPB + CPB/2) @(posedge clk);           // to middle of bit 0
      for (i = 0; i < 8; i = i + 1) begin
        b[i] = fpga_tx;
        if (i < 7) repeat (CPB) @(posedge clk);
      end
      rxq[rxq_wr] = b;
      rxq_wr = rxq_wr + 1;
      repeat (CPB) @(posedge clk);                   // ride out the stop bit
    end
  end

  task host_recv(output [7:0] b);
    begin
      while (rxq_rd == rxq_wr) @(posedge clk);
      b = rxq[rxq_rd];
      rxq_rd = rxq_rd + 1;
    end
  endtask

  task expect_byte(input [7:0] want, input [127:0] label);
    reg [7:0] r;
    begin
      host_recv(r);
      if (r !== want) begin
        $display("[TB] FAIL %0s: got %02h, want %02h", label, r, want);
        errors = errors + 1;
      end
    end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $readmemh("golden_s.hex",    golden_s);
    $readmemh("golden_shat.hex", golden_shat);

    $display("============================================================");
    $display("  UART board-path test: host <-> mlkem_uart_core <-> NTT");
    $display("============================================================");

    rst_n = 0;
    repeat (10) @(posedge clk);
    rst_n = 1;
    repeat (10) @(posedge clk);

    // ---- 1. PING ----
    host_send(8'hA5);
    expect_byte(8'h5A, "PING");
    if (errors == 0) $display("[TB] PING ok (link alive)");

    // ---- 2. STATUS before any work ----
    host_send(8'h05);
    host_recv(got);
    if (got[0] !== 1'b0) begin
      $display("[TB] FAIL: engine reports busy before start (status=%02h)", got);
      errors = errors + 1;
    end else $display("[TB] STATUS ok (idle)");

    // ---- 3. load s, 256 coefficients ----
    for (k = 0; k < 256; k = k + 1) begin
      host_send(8'h01);                    // CMD_WRITE
      host_send(k[7:0]);                   // addr
      host_send(golden_s[k][7:0]);         // data low
      host_send(golden_s[k][15:8]);        // data high
      expect_byte(8'h01, "WRITE ack");
    end
    $display("[TB] loaded 256 coefficients of s over UART");

    // ---- 4. start forward NTT ----
    host_send(8'h02);
    expect_byte(8'h02, "NTT ack");
    $display("[TB] forward NTT started");

    // ---- 5. poll STATUS until done ----
    got = 8'h01;
    k = 0;
    while (got[0] === 1'b1 && k < 200) begin
      host_send(8'h05);
      host_recv(got);
      k = k + 1;
    end
    if (got[1] !== 1'b1) begin
      $display("[TB] FAIL: NTT never reported done (status=%02h after %0d polls)",
               got, k);
      errors = errors + 1;
    end else
      $display("[TB] NTT completed (done flag seen after %0d status polls)", k);

    // ---- 6. read back and compare against s_hat ----
    for (k = 0; k < 256; k = k + 1) begin
      host_send(8'h04);                    // CMD_READ
      host_send(k[7:0]);                   // addr
      host_recv(got16[7:0]);
      host_recv(got16[15:8]);
      if (got16 !== golden_shat[k]) begin
        $display("[TB] FAIL s_hat[%0d]: got %0d, want %0d",
                 k, got16, golden_shat[k]);
        errors = errors + 1;
      end
    end

    if (errors == 0) begin
      $display("[TB] read back 256/256 coefficients, all match s_hat");
      $display("============================================================");
      $display("  PASS -- full UART command path verified end to end");
      $display("  (PING, STATUS, WRITE, START, POLL, READ all correct)");
      $display("============================================================");
    end else begin
      $display("============================================================");
      $display("  FAIL -- %0d error(s)", errors);
      $display("============================================================");
    end
    $finish;
  end

  initial begin
    #500_000_000;
    $display("[TB] TIMEOUT -- core state=%0d", dut.state);
    $finish;
  end
endmodule
