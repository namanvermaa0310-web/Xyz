# KC705 Production Bring-Up: UART-Bridged ML-KEM NTT Accelerator

Replaces the earlier approach of pin-mapping `ntt_engine`'s 55 raw ports.
That approach was wrong: `ntt_engine` has 48 bits of coefficient address/data
bus, and KC705 has 8 LEDs and 4 DIP switches. Even with a bitstream generated,
there was no way to drive a 16-bit coefficient from the board, so it would
have proven nothing beyond "the tool flow completes."

This design talks over the KC705's USB-UART bridge instead, which is what a
real bring-up uses. Four board pins total, all verified.

## Verification status
The whole command path is tested in Icarus by driving REAL serial waveforms
into `uart_rx_i` and decoding real waveforms out of `uart_tx_o` -- no backdoor
writes into memory:

    [TB] PING ok (link alive)
    [TB] STATUS ok (idle)
    [TB] loaded 256 coefficients of s over UART
    [TB] forward NTT started
    [TB] NTT completed (done flag seen after 10 status polls)
    [TB] read back 256/256 coefficients, all match s_hat
    PASS -- full UART command path verified end to end

Run it:

    iverilog -g2012 -o uart.vvp \
      mlkem_pkg.sv twiddle_rom.sv ntt_engine.sv \
      uart_rx.sv uart_tx.sv mlkem_uart_core.sv tb_mlkem_uart_core.sv
    vvp uart.vvp        # needs golden_s.hex and golden_shat.hex in the cwd

The vectors are the same FIPS 203 golden files from Phase 3, so a pass means
the UART bridge preserves the already-verified NTT result bit-for-bit.

## Files
| File | Role | Simulated? |
|---|---|---|
| `uart_rx.sv` | 8N1 receiver, 2-flop input synchronizer | yes |
| `uart_tx.sv` | 8N1 transmitter | yes |
| `mlkem_uart_core.sv` | command FSM + ntt_engine, board-independent | yes |
| `kc705_mlkem_top.sv` | IBUFDS + MMCM + reset sync (UNISIMs) | no -- Vivado only |
| `tb_mlkem_uart_core.sv` | end-to-end serial testbench | -- |
| `kc705_mlkem.xdc` | 4 verified pins + timing exceptions | -- |
| `host_ntt.py` | PC-side driver and bench test | -- |

The split matters: all the logic is in `mlkem_uart_core`, which Icarus can
simulate. `kc705_mlkem_top` is only primitive glue, which it cannot.

## Command protocol
| Bytes (host -> FPGA) | Meaning | Reply |
|---|---|---|
| `A5` | ping | `5A` |
| `01 addr lo hi` | write coefficient | `01` |
| `02` | start forward NTT | `02` |
| `03` | start inverse NTT | `03` |
| `04 addr` | read coefficient | `lo hi` |
| `05` | status | `{6'b0, done, busy}` |

Coefficients are 16-bit little-endian, matching the golden `.hex` convention.

## Vivado setup
1. New project, part `xc7k325tffg900-2`.
2. Add design sources: `mlkem_pkg.sv`, `twiddle_rom.sv`, `ntt_engine.sv`,
   `uart_rx.sv`, `uart_tx.sv`, `mlkem_uart_core.sv`, `kc705_mlkem_top.sv`.
3. Add constraint: `kc705_mlkem.xdc`.
4. Set `kc705_mlkem_top` as top.
5. Synthesis -> Implementation -> Generate Bitstream. This should now complete
   without the DRC NSTD-1 / UCIO-1 errors, because every top-level port has a
   real PACKAGE_PIN and IOSTANDARD.
6. **Read the timing report before going to hardware** (see below).

## Bench test
    pip install pyserial
    python3 host_ntt.py /dev/ttyUSB0

The script pings, loads a fixed polynomial, reads it back *before*
transforming (so a UART fault is distinguishable from a math fault), runs
the NTT, and compares all 256 outputs against a Python FIPS 203 reference.

## Four things to confirm on the bench -- do not assume these
1. **CPU_RESET polarity.** The wrapper assumes active high. If the design
   never leaves reset, invert `async_rst` in `kc705_mlkem_top.sv`.
2. **SYSCLK IOSTANDARD.** Bank 33 is 1.5 V. UG810 says `LVDS`; some Vivado
   versions require `DIFF_SSTL15`. Both are in the XDC, one commented.
3. **UART pin swap.** Xilinx AR 45934 documents that UG810's `K24`/`M19` do
   not match Vivado's `part0_pins.xml`. If the port does not respond, swap
   them first.
4. **Timing closure.** `ntt_engine`'s butterfly is one long combinational
   path: 16x16 multiply, Barrett reduction, conditional subtract, all in a
   single cycle. At 100 MHz it will probably close; confirm WNS is positive.
   If it is negative, pipeline the butterfly -- do not just lower the clock
   and hope.

A negative-WNS design typically passes simulation and fails on hardware with
exactly the signature `host_ntt.py` is built to catch: correct data loads and
reads back, wrong data after the transform.

## What this is and is not
It is a verified bring-up harness for the NTT engine on real hardware.

It is not ML-KEM. KeyGen, Encaps, Decaps, the basecase multiplier, encoding
and compression are still unbuilt (Phase 4). The samplers from Phase 3 are
not wired into this wrapper either -- extending the command set to reach
them is straightforward once the NTT path is confirmed on silicon.
